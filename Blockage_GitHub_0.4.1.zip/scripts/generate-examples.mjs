import { writeFile, mkdir } from 'node:fs/promises';
import path from 'node:path';
import { BoxGeometry } from 'three';
import { emptyWorld, simulationTest, waterTest, terrainTest, engineTest, characterTest } from '../src/engine/demo.js';
import { createEntity } from '../src/engine/document.js';
import { createPrefab } from '../src/engine/prefab.js';

const root = path.resolve(import.meta.dirname, '..'), examples = path.join(root, 'examples');
await mkdir(path.join(examples,'assets'),{recursive:true});
await writeFile(path.join(examples,'SimulationTest.blockage'),JSON.stringify(simulationTest(),null,2));
for(const kind of ['cloth','fluid','particles']){const d=simulationTest();d.name=kind[0].toUpperCase()+kind.slice(1)+' Test';d.entities=d.entities.filter(e=>['plane','directionalLight',kind].includes(e.kind)||(kind==='cloth'&&e.kind==='sphere'));await writeFile(path.join(examples,kind[0].toUpperCase()+kind.slice(1)+'Test.blockage'),JSON.stringify(d,null,2));}
await writeFile(path.join(examples,'StarterWorld.blockage'),JSON.stringify(emptyWorld(),null,2));
for(const [name,make] of [['WaterTest',waterTest],['TerrainTest',terrainTest],['EngineTest',engineTest],['CharacterTest',characterTest]])await writeFile(path.join(examples,name+'.blockage'),JSON.stringify(make(),null,2));
const w=waterTest();await writeFile(path.join(examples,'FloatingCube.blockageprefab'),JSON.stringify(createPrefab(w,w.entities.find(e=>e.name==='Floating Cube').id),null,2));
const physics = emptyWorld(); physics.name = 'Physics Test';physics.entities=physics.entities.filter(e=>e.kind!=='box');
for(let i=0;i<4;i++){
  const e=createEntity(i%2?'sphere':'box',{name:`Drop Body ${i+1}`,transform:{position:[i*2-3,3+i*1.5,0],rotation:[0,0,0],scale:[1,1,1]},behaviors:{rigidbody:{restitution:.15+i*.2,floor:0}}});
  e.material.color=['#8d8d8d','#727272','#999999','#b1b1b1'][i]; physics.entities.push(e);
}
physics.camera={position:[9,6,11],target:[0,2,0]};
await writeFile(path.join(examples,'PhysicsPlayground.blockage'),JSON.stringify(physics,null,2));

// An original, uncompressed, self-contained GLB example. No external art or network dependencies.
const chunks=[],bufferViews=[],accessors=[],meshes=[],nodes=[];
let byteOffset=0;
const append=(array,target)=>{const bytes=Buffer.from(array.buffer,array.byteOffset,array.byteLength);const padded=Buffer.alloc(Math.ceil(bytes.length/4)*4);bytes.copy(padded);const index=bufferViews.length;bufferViews.push({buffer:0,byteOffset,byteLength:bytes.length,target});chunks.push(padded);byteOffset+=padded.length;return index;};
const attribute=(attr,target,minmax=false)=>{const array=attr.array,info={bufferView:append(array,target),componentType:array instanceof Float32Array?5126:array instanceof Uint32Array?5125:5123,count:attr.count,type:attr.itemSize===3?'VEC3':attr.itemSize===2?'VEC2':'SCALAR'};
  if(minmax){info.min=[Infinity,Infinity,Infinity];info.max=[-Infinity,-Infinity,-Infinity];for(let i=0;i<array.length;i+=3)for(let axis=0;axis<3;axis++){info.min[axis]=Math.min(info.min[axis],array[i+axis]);info.max[axis]=Math.max(info.max[axis],array[i+axis]);}}
  const index=accessors.length;accessors.push(info);return index;};
const material=[{name:'Default',pbrMetallicRoughness:{baseColorFactor:[.6,.6,.6,1],metallicFactor:0,roughnessFactor:.6}}];
const addMesh=(geometry,name,translation,scale,mat)=>{
  const primitive={attributes:{POSITION:attribute(geometry.attributes.position,34962,true),NORMAL:attribute(geometry.attributes.normal,34962),TEXCOORD_0:attribute(geometry.attributes.uv,34962)},indices:attribute(geometry.index,34963),material:mat};
  const mesh=meshes.length;meshes.push({name,primitives:[primitive]});nodes.push({name,mesh,translation,scale});geometry.dispose();};
addMesh(new BoxGeometry(),'Cube',[0,.5,0],[1,1,1],0);
const json={asset:{version:'2.0',generator:'Blockage Example Generator'},scene:0,scenes:[{nodes:nodes.map((_,i)=>i)}],nodes,meshes,materials:material,buffers:[{byteLength:byteOffset}],bufferViews,accessors};
const jsonBytes=Buffer.from(JSON.stringify(json)),jsonPadded=Buffer.alloc(Math.ceil(jsonBytes.length/4)*4,32);jsonBytes.copy(jsonPadded);
const bin=Buffer.concat(chunks),total=12+8+jsonPadded.length+8+bin.length,glb=Buffer.alloc(total);
glb.writeUInt32LE(0x46546c67,0);glb.writeUInt32LE(2,4);glb.writeUInt32LE(total,8);glb.writeUInt32LE(jsonPadded.length,12);glb.writeUInt32LE(0x4e4f534a,16);jsonPadded.copy(glb,20);
const start=20+jsonPadded.length;glb.writeUInt32LE(bin.length,start);glb.writeUInt32LE(0x004e4942,start+4);bin.copy(glb,start+8);
await writeFile(path.join(examples,'assets','Cube.glb'),glb);

const input=accessors.length;accessors.push({bufferView:append(new Float32Array([0,1,2])),componentType:5126,count:3,type:'SCALAR',min:[0],max:[2]});
const output=accessors.length;accessors.push({bufferView:append(new Float32Array([0,.5,0,0,2,0,0,.5,0])),componentType:5126,count:3,type:'VEC3'});
json.animations=[{name:'Lift',samplers:[{input,output,interpolation:'LINEAR'}],channels:[{sampler:0,target:{node:0,path:'translation'}}]}];json.buffers[0].byteLength=byteOffset;
const animatedJson=Buffer.from(JSON.stringify(json)),padded=Buffer.alloc(Math.ceil(animatedJson.length/4)*4,32);animatedJson.copy(padded);const animatedBin=Buffer.concat(chunks),animated=Buffer.alloc(28+padded.length+animatedBin.length);animated.writeUInt32LE(0x46546c67,0);animated.writeUInt32LE(2,4);animated.writeUInt32LE(animated.length,8);animated.writeUInt32LE(padded.length,12);animated.writeUInt32LE(0x4e4f534a,16);padded.copy(animated,20);animated.writeUInt32LE(animatedBin.length,20+padded.length);animated.writeUInt32LE(0x004e4942,24+padded.length);animatedBin.copy(animated,28+padded.length);await writeFile(path.join(examples,'assets','AnimatedCube.glb'),animated);

// A short original PCM tone for audio and trigger examples; no external media.
const rate=22050,length=Math.floor(rate*.65),wav=Buffer.alloc(44+length*2);wav.write('RIFF');wav.writeUInt32LE(wav.length-8,4);wav.write('WAVE',8);wav.write('fmt ',12);wav.writeUInt32LE(16,16);wav.writeUInt16LE(1,20);wav.writeUInt16LE(1,22);wav.writeUInt32LE(rate,24);wav.writeUInt32LE(rate*2,28);wav.writeUInt16LE(2,32);wav.writeUInt16LE(16,34);wav.write('data',36);wav.writeUInt32LE(length*2,40);
for(let i=0;i<length;i++){const t=i/rate,envelope=Math.min(1,t/.02)*Math.max(0,1-t/.65);wav.writeInt16LE(Math.round(Math.sin(t*2*Math.PI*440)*Math.exp(-t*3)*envelope*6500),44+i*2);}await writeFile(path.join(examples,'assets','Tone.wav'),wav);
const audio=emptyWorld();audio.name='Audio and Trigger Test';const source=createEntity('audio',{name:'Tone',transform:{position:[0,1,0],rotation:[0,0,0],scale:[1,1,1]}}),asset={id:crypto.randomUUID(),name:'Tone.wav',type:'audio',mime:'audio/wav',data:wav.toString('base64'),bytes:wav.length};source.audio.asset=asset.id;source.audio.autoplay=false;source.audio.loop=false;
const trigger=createEntity('trigger',{name:'Play Tone Zone',transform:{position:[0,1,3],rotation:[0,0,0],scale:[1,1,1]}});trigger.trigger.target=source.id;trigger.trigger.once=false;
const camera=createEntity('camera',{name:'Player Camera',transform:{position:[0,1.7,6],rotation:[0,0,0],scale:[1,1,1]}});audio.assets.push(asset);audio.entities.push(source,trigger,camera);await writeFile(path.join(examples,'AudioTest.blockage'),JSON.stringify(audio,null,2));
console.log('Example scenes, prefab, static/animated GLB and audio generated.');
