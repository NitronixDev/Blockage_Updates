import http from 'node:http';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
const root=path.resolve(import.meta.dirname,'..'), port=Number(process.env.BLOCKAGE_PREVIEW_PORT || 4173);
const types={'.html':'text/html','.js':'text/javascript','.css':'text/css','.svg':'image/svg+xml','.png':'image/png','.json':'application/json'};
const server=http.createServer(async(req,res)=>{
  try { const url=new URL(req.url,'http://localhost'),relative=decodeURIComponent(url.pathname === '/' ? '/src/index.html' : url.pathname).replace(/^\/+/,''),file=path.resolve(root,relative),safe=path.relative(root,file);
    if(safe.startsWith('..')||path.isAbsolute(safe)||![`src${path.sep}`,`assets${path.sep}`,`node_modules${path.sep}three${path.sep}`].some(p=>safe.startsWith(p))) throw new Error('Invalid resource');
    res.writeHead(200,{'Content-Type':types[path.extname(file)]||'application/octet-stream'});res.end(await readFile(file));
  }catch{res.writeHead(404);res.end('Not found');}
});
server.listen(port,'127.0.0.1',()=>console.log(`Blockage local preview: http://127.0.0.1:${port}\nUse Electron for native file dialogs and GPU diagnostics.`));
