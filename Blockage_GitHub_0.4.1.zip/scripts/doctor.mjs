import { existsSync, readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { spawnSync } from 'node:child_process';
import path from 'node:path';
const root = path.resolve(import.meta.dirname,'..'), require = createRequire(import.meta.url);
console.log('Blockage '+JSON.parse(readFileSync(path.join(root,'package.json'),'utf8')).version+' environment check\n');
console.log('Platform:',process.platform,process.arch,'\nNode.js:',process.version,'\nExpected Node.js: 26.11.1 (portable development runtime)');
for(const name of ['electron','three']) { try { const p=path.join(root,'node_modules',name,'package.json');console.log(`${name}:`,JSON.parse(readFileSync(p,'utf8')).version); } catch { console.log(`${name}: missing — run npm ci`); process.exitCode=1; } }
try {const electron=require('electron');console.log('Electron binary:',existsSync(electron)?'present':'missing');if(!existsSync(electron))process.exitCode=1;}catch(e){console.log('Electron:',e.message);process.exitCode=1;}
const portable=path.join(root,'runtime','node',process.platform==='win32'?'node.exe':'bin/node');console.log('Portable Node/npm:',existsSync(portable)?'present':'not bundled for this platform');
console.log('\nStart: npm start\nVulkan profile: npm run start:vulkan\nCompatibility: npm run start:compat\nGPU details: Help → Graphics Diagnostics');
console.log('\nElectron ships its own embedded Node version. It is independent of the development Node runtime.');
