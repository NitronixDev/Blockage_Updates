import { readdir } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import path from 'node:path';
const root = path.resolve(import.meta.dirname,'..');
let failures = 0, count = 0;
async function walk(dir) { for (const entry of await readdir(dir,{withFileTypes:true})) { const p=path.join(dir,entry.name); if(entry.isDirectory()) await walk(p); else if(/\.(js|cjs|mjs)$/.test(entry.name)) { const result=spawnSync(process.execPath,['--check',p],{stdio:'pipe',encoding:'utf8'}); count++; if(result.status!==0){failures++;console.error(result.stderr);} } } }
for(const dir of ['electron','src','scripts','tests']) await walk(path.join(root,dir));
console.log(`Syntax check: ${count} files, ${failures} errors.`);process.exitCode=failures?1:0;
