"""Trusted GLB exporter; loaded .blend Python scripts are disabled by the caller."""
import argparse
import sys
import bpy

parser = argparse.ArgumentParser()
parser.add_argument('--output', required=True)
args = parser.parse_args(sys.argv[sys.argv.index('--') + 1:])
bpy.ops.export_scene.gltf(filepath=args.output, export_format='GLB',
    export_animations=True, export_skins=True, export_morph=True, export_apply=False)
