const {randomUUID}=require('node:crypto');
const {sceneBytes}=require('../src/engine/asset-limits.json');
const CHUNK_CHARS=1024*1024,INLINE_CHARS=4*1024*1024;

/** Private, owner-scoped JSON transfers; IPC messages stay small in both directions. */
class PayloadTransfers {
  constructor({maxBytes=sceneBytes+8*1024*1024,chunkChars=CHUNK_CHARS,inlineChars=INLINE_CHARS,ttl=300000,now=Date.now}={}){this.maxBytes=maxBytes;this.chunkChars=chunkChars;this.inlineChars=inlineChars;this.ttl=ttl;this.now=now;this.records=new Map();}
  prune(){const time=this.now();for(const [id,r] of this.records)if(r.expires<=time)this.records.delete(id);}
  create(owner,record){this.prune();if(this.records.size>=4||[...this.records.values()].reduce((n,r)=>n+r.reserved,0)+record.reserved>this.maxBytes*2)throw new Error('Too many large transfers. Wait for the current import or save.');const id=randomUUID();this.records.set(id,{...record,owner,expires:this.now()+this.ttl});return id;}
  get(owner,id,direction){this.prune();if(typeof id!=='string')throw new Error('Invalid transfer token.');const r=this.records.get(id);if(!r||r.owner!==owner||direction&&r.direction!==direction)throw new Error('Transfer is unavailable or expired.');r.expires=this.now()+this.ttl;return r;}
  wrap(owner,value){if(value===undefined)return value;const text=JSON.stringify(value);if(text.length<=this.inlineChars)return value;const bytes=Buffer.byteLength(text);if(bytes>this.maxBytes)throw new Error('Response exceeds the large transfer limit.');const id=this.create(owner,{direction:'outgoing',text,reserved:bytes});return{ok:true,__blockageTransfer:{id,length:text.length}};}
  read(owner,id,offset){const r=this.get(owner,id,'outgoing');if(!Number.isInteger(offset)||offset<0||offset>=r.text.length)throw new Error('Invalid transfer offset.');return{ok:true,data:r.text.slice(offset,offset+this.chunkChars)};}
  begin(owner,length){if(!Number.isInteger(length)||length<1||length>this.maxBytes)throw new Error('Invalid large request size.');return{ok:true,id:this.create(owner,{direction:'incoming',length,parts:[],received:0,bytes:0,reserved:length})};}
  append(owner,id,offset,text){const r=this.get(owner,id,'incoming');if(typeof text!=='string'||!text.length||text.length>this.chunkChars||offset!==r.received||r.received+text.length>r.length)throw new Error('Invalid large request chunk.');const bytes=Buffer.byteLength(text);if(r.bytes+bytes>this.maxBytes){this.records.delete(id);throw new Error('Request exceeds the large transfer limit.');}r.parts.push(text);r.received+=text.length;r.bytes+=bytes;return{ok:true};}
  consume(owner,id){const r=this.get(owner,id,'incoming');if(r.received!==r.length)throw new Error('Large request is incomplete.');this.records.delete(id);const args=JSON.parse(r.parts.join(''));if(!Array.isArray(args))throw new Error('Invalid large request arguments.');return args;}
  drop(owner,id){const r=this.records.get(id);if(r&&r.owner!==owner)throw new Error('Transfer belongs to another window.');this.records.delete(id);return{ok:true};}
  clearOwner(owner){for(const [id,r] of this.records)if(r.owner===owner)this.records.delete(id);}
}
module.exports={PayloadTransfers,CHUNK_CHARS,INLINE_CHARS};
