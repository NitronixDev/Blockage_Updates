const { contextBridge, ipcRenderer } = require('electron');
const channels=Object.freeze({info:'info',openScene:'open',saveScene:'save',importAssets:'import',preferences:'preferences',savePreferences:'preferences-save',chooseBlender:'choose-blender',checkUpdates:'update-check',installUpdate:'update-install',openUpdateFolder:'update-open',restartUpdated:'update-restart',savePrefab:'prefab-save',openPrefab:'prefab-open',autosave:'autosave',recover:'recover',clearRecovery:'clear-recovery',resetScenePath:'reset-path',closeWithRecovery:'close-recovery'});
const subscribe=(channel,callback)=>{const listener=(_event,value)=>callback(value);ipcRenderer.on(channel,listener);return()=>ipcRenderer.removeListener(channel,listener);};
// Only small transport messages cross contextBridge. The renderer assembles large JSON.
contextBridge.exposeInMainWorld('blockageDesktopTransport',Object.freeze({
  invoke:(method,args=[])=>{if(!Object.hasOwn(channels,method)||!Array.isArray(args))return Promise.resolve({ok:false,error:'Unknown desktop command.'});return ipcRenderer.invoke('blockage:'+channels[method],...args);},
  begin:length=>ipcRenderer.invoke('blockage:payload-begin',length),
  append:(id,offset,text)=>ipcRenderer.invoke('blockage:payload-append',id,offset,text),
  read:(id,offset)=>ipcRenderer.invoke('blockage:payload-read',id,offset),
  drop:id=>ipcRenderer.invoke('blockage:payload-drop',id),
  markDirty:dirty=>ipcRenderer.send('blockage:dirty',Boolean(dirty)),
  windowAction:action=>{if(['minimize','maximize','close','devtools'].includes(action))ipcRenderer.send('blockage:window',action);},
  onMenu:callback=>subscribe('blockage:menu',callback),
  onUpdateProgress:callback=>subscribe('blockage:update-progress',callback),
  onImportProgress:callback=>subscribe('blockage:import-progress',callback)
}));
