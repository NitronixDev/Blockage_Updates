# Blockage 0.4.1

Desktop 3D engine/editor built with Electron, Node.js and Three.js. The compact interface is in English; the original orange cube logo is included.

This is the source repository used to build the application and its GitHub releases.

## Run from source

Use Node.js 26.11.1 and npm 12.2.0, then run:

```sh
npm ci
npm test
npm run check
npm run examples
npm start
```

`npm run start:compat` requests WebGL 2. `npm run start:vulkan` requests the Vulkan graphics profile. GPU diagnostics are available in the editor. `npm run examples` generates the example scenes, Cube/Lift GLBs and audio fixture; the small `examples/assets/Cube.glb` committed here is also required by the unit tests.

## Features

- Multiple/folder import for GLB, GLTF, OBJ/MTL, FBX, STL, PLY, DAE and 3MF. BLEND converts through an installed Blender executable configured in Edit → Preferences.
- Source skeletons and clips, initial chain/humanoid skin generation, bone gizmos, interpolated pose keys, undo and portable prefabs.
- Original playable mannequin with Idle/Walk/Run/Jump clips, acceleration, smooth turning, grounded jump, primitive/terrain collisions, crossfades and first/third-person camera.
- Water waves/ripples, terrain, primitive rigid bodies/buoyancy/joints, cloth, particle fluid, emitters, object animation, audio/triggers and PBR maps.
- Public GitHub release checking, SHA-256 verification and separate Windows update installations.

Version 0.4.1 accepts **200 MiB per model bundle**, **300 MiB of embedded assets per scene**, and **450 MiB scene/prefab files**. Standalone textures/audio remain at 50 MiB. Large desktop imports, saving, reopening, recovery and prefabs use bounded IPC chunks. Scene format 5 keeps large model data in Base64 chunks and reads formats 1–4. Newly saved scenes require Blockage 0.4.1 or later. Size settings are shared in `src/engine/asset-limits.json`; the existing vertex/bone/simulation budgets still apply.

Try File → New Scene → Character Test, then Play → Game, click the viewport and use WASD/ZQSD, Shift, Space and RMB drag. For format/rig limits, see `docs/IMPORTS_AND_CHARACTERS.md`.

## Put these files on GitHub

Extract the repository archive and put its **contents at the repository root**, including `.github/workflows/release.yml` and `.gitignore`. Keep `package.json` beside the `src`, `electron`, `scripts`, `tests` and `assets` directories. Commit the source files themselves, rather than the source ZIP.

The release workflow installs the dependencies and prepares the portable Windows runtime. See `docs/GITHUB_UPDATES.md` for the release layout and client configuration.

To publish this version with Git:

```sh
git add .
git commit -m "Blockage 0.4.1"
git push
git tag v0.4.1
git push origin v0.4.1
```

GitHub Actions builds `Blockage_0.4.1_Windows_x64.zip` and `SHA256SUMS.json`. Set the application's update repository to your `owner/repository` in Edit → Preferences. A tag must match the version in `package.json` and `package-lock.json`; use a new stable version for each subsequent release.

## Verification and scope

78 unit tests pass. Desktop integration tested importing and displaying a 200 MiB GLB, saving/reopening its scene, recovery, and prefab export/import with no page/renderer errors. Graphics verification used Linux Electron with SwiftShader/WebGL 2. The GitHub Windows workflow has not been run in your repository.

The engine components are prototypes: generated weights are approximate; weight painting, IK, retargeting, arbitrary mesh character physics and a full animation graph are not implemented.

MIT license. Dependency versions and archive integrity are pinned through the lockfile and release workflow.
