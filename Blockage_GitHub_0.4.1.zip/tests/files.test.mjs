import test from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { mkdtemp, readFile, readdir, rm } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
const require = createRequire(import.meta.url);
const { resolveAppPath, inspectAsset, atomicWrite } = require('../electron/files.cjs');

test('renderer resource route serves only approved application paths',()=>{
  const root=path.resolve('/tmp/blockage');
  assert.equal(resolveAppPath(root,'blockage://app/src/editor/app.js'),path.join(root,'src/editor/app.js'));
  assert.equal(resolveAppPath(root,'blockage://app/node_modules/three/build/three.core.js'),path.join(root,'node_modules/three/build/three.core.js'));
  for(const url of ['blockage://other/src/index.html','https://app/src/index.html','blockage://app/electron/main.cjs','blockage://app/src/%2e%2e%2f%2e%2e%2fetc/passwd','blockage://app/src/%5c..%5celectron/main.cjs']) assert.throws(()=>resolveAppPath(root,url));
});
function glb(json){const text=JSON.stringify(json),length=Math.ceil(Buffer.byteLength(text)/4)*4,bytes=Buffer.alloc(20+length,32);bytes.writeUInt32LE(0x46546c67,0);bytes.writeUInt32LE(2,4);bytes.writeUInt32LE(bytes.length,8);bytes.writeUInt32LE(length,12);bytes.writeUInt32LE(0x4e4f534a,16);bytes.write(text,20);return bytes;}
test('GLB imports check their headers, lengths, and embedded resources',()=>{
  const asset=inspectAsset(glb({asset:{version:'2.0'}}),'mesh.glb');assert.equal(asset.type,'model');assert.equal(asset.mime,'model/gltf-binary');
  assert.throws(()=>inspectAsset(Buffer.from('not glb'),'mesh.glb'),/Invalid GLB/);
  assert.throws(()=>inspectAsset(glb({images:[{uri:'https://example.com/image.png'}]}),'mesh.glb'),/self-contained/);
  assert.throws(()=>inspectAsset(glb({extensionsRequired:['KHR_draco_mesh_compression']}),'mesh.glb'),/decoder/);
});
test('asset extensions must agree with their image signatures',()=>{
  const png=Buffer.from([137,80,78,71,13,10,26,10]);assert.equal(inspectAsset(png,'tiny.png').mime,'image/png');
  assert.throws(()=>inspectAsset(png,'not-a-model.glb'));assert.throws(()=>inspectAsset(Buffer.from('hello'),'image.png'));assert.throws(()=>inspectAsset(Buffer.from('code'),'script.js'));
});
test('scene writes atomically replace an existing file without leftover temporary files',async()=>{
  const dir=await mkdtemp(path.join(os.tmpdir(),'blockage-test-'));const filename=path.join(dir,'world.blockage');
  try {await atomicWrite(filename,'first');await atomicWrite(filename,'second');assert.equal(await readFile(filename,'utf8'),'second');assert.deepEqual(await readdir(dir),['world.blockage']);}finally{await rm(dir,{recursive:true,force:true});}
});
