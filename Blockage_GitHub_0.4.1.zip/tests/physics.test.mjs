import test from 'node:test';
import assert from 'node:assert/strict';
import {ClothSolver,FluidSolver,ParticleSolver} from '../src/engine/physics.js';
import {createEntity,validateDocument,createDocument,VERSION} from '../src/engine/document.js';
import {Simulation} from '../src/engine/simulation.js';
import {Vector3,Euler} from 'three';
const finite=p=>assert([...p].every(Number.isFinite));
const meanY=p=>{let n=0;for(let i=1;i<p.length;i+=3)n+=p[i];return n/(p.length/3);};

test('cloth anchors stay fixed while unpinned vertices deform under wind',()=>{
  const s=new ClothSolver({segments:10,wind:3});const original=new Float32Array(s.positions);
  for(let i=0;i<120;i++)s.step(1/60);finite(s.positions);
  for(let id=0;id<s.count;id++)if(!s.weights[id])assert.deepEqual(s.positions.slice(id*3,id*3+3),original.slice(id*3,id*3+3));
  assert(s.positions.some((v,i)=>i%3===2&&Math.abs(v)>.1));
  for(const q of s.constraints){const a=q.a*3,b=q.b*3,d=Math.hypot(s.positions[a]-s.positions[b],s.positions[a+1]-s.positions[b+1],s.positions[a+2]-s.positions[b+2]);assert(d<q.length*2.3);}
  s.reset();assert.deepEqual(s.positions,original);
});
test('cloth pin modes and floor projection behave independently',()=>{
  const edge=new ClothSolver({segments:8,pin:'edge'});assert.equal([...edge.weights].filter(v=>!v).length,9);
  const free=new ClothSolver({segments:8,pin:'none',wind:0});const initial=meanY(free.positions);for(let i=0;i<90;i++)free.step(1/60);assert(meanY(free.positions)<initial-.3);
  for(let i=1;i<free.positions.length;i+=3)assert(free.positions[i]>=.0249);
});
test('cloth vertices are projected outside a sphere collider',()=>{
  const s=new ClothSolver({segments:12,wind:0}),c={type:'sphere',center:[0,1.5,.05],radius:.65};for(let i=0;i<90;i++)s.step(1/60,[c]);
  finite(s.positions);for(let id=0;id<s.count;id++){if(!s.weights[id])continue;const i=id*3;assert(Math.hypot(s.positions[i],s.positions[i+1]-1.5,s.positions[i+2]-.05)>=.6748);}
});
test('fluid responds to gravity, stays in bounds and resets deterministically',()=>{
  const s=new FluidSolver({count:64,width:2,height:3,depth:2,radius:.1}),original=new Float32Array(s.positions),y=meanY(s.positions);
  for(let i=0;i<120;i++)s.step(1/60);finite(s.positions);assert(meanY(s.positions)<y-.4);
  for(let i=0;i<s.positions.length;i+=3){assert(Math.abs(s.positions[i])<=.9001);assert(Math.abs(s.positions[i+2])<=.9001);assert(s.positions[i+1]>=.0999&&s.positions[i+1]<=2.9001);}
  s.reset();assert.deepEqual(s.positions,original);assert(s.velocity.every(v=>v===0));
});
test('fluid projection separates compressed particles and respects primitive obstacles',()=>{
  const s=new FluidSolver({count:64,width:2,height:3,depth:2,radius:.1});const c={type:'sphere',center:[0,.45,0],radius:.25};
  for(let i=0;i<120;i++)s.step(1/60,[c]);finite(s.positions);
  for(let i=0;i<s.positions.length;i+=3)assert(Math.hypot(s.positions[i],s.positions[i+1]-.45,s.positions[i+2])>=.3497);
  assert(s.densities.some(x=>x>0));assert(s.positions.some((v,i)=>i%3===0&&Math.abs(v-s.rest[i])>.15));
});
test('viscosity changes the fluid velocity field without introducing invalid values',()=>{
  const a=new FluidSolver({count:64,viscosity:0}),b=new FluidSolver({count:64,viscosity:.8});
  for(let i=0;i<a.velocity.length;i+=3){a.velocity[i]=b.velocity[i]=i%2?3:-3;}
  for(let i=0;i<12;i++){a.step(1/60);b.step(1/60);}finite(a.positions);finite(b.positions);assert.notDeepEqual(a.velocity,b.velocity);
});
test('emission, capacity, lifetime, gravity and reset are deterministic',()=>{
  const a=new ParticleSolver({count:32,rate:16,lifetime:1}),b=new ParticleSolver({count:32,rate:16,lifetime:1});
  for(let i=0;i<60;i++){a.step(1/60);b.step(1/60);}assert([...a.ages].filter(x=>x>=0).length>=15);assert.deepEqual(a.positions,b.positions);finite(a.positions);
  for(let i=0;i<180;i++)a.step(1/60);assert([...a.ages].filter(x=>x>=0).length<=32);a.reset();assert(a.ages.every(x=>x===-1));assert(a.positions.every(x=>x===0));
});
test('legacy scenes migrate without changing their authored transforms',()=>{
  const doc=createDocument(),e=createEntity('box');doc.entities.push(e);doc.version=1;delete e.collider;const transformed=JSON.stringify(e.transform);const migrated=validateDocument(doc);assert.equal(migrated.version,VERSION);assert.equal(migrated.entities[0].collider,true);assert.equal(JSON.stringify(migrated.entities[0].transform),transformed);
});
test('invalid simulation allocation and incompatible motion components are rejected',()=>{
  const doc=createDocument();doc.entities.push(createEntity('fluid'));doc.entities[0].simulation.count=10_000;assert.throws(()=>validateDocument(doc),/particle count/);
  doc.entities[0]=createEntity('cloth');doc.entities[0].simulation.segments=14.5;assert.throws(()=>validateDocument(doc),/integer/);
  doc.entities[0]=createEntity('box',{behaviors:{spring:{stiffness:8,damping:1,x:0,y:3,z:0},velocity:{x:1,y:0,z:0}}});assert.throws(()=>validateDocument(doc),/Spring owns/);
});
test('new motion behaviors advance and Stop restores position, rotation and scale',()=>{
  for(const behaviors of [{velocity:{x:2,y:0,z:-1}},{oscillate:{axis:'X',amplitude:2,speed:.4}},{pulse:{amplitude:.2,speed:.4}},{spring:{stiffness:8,damping:1,x:0,y:3,z:0}},{spin:{axis:'Z',speed:30}}]){
    const e=createEntity('box',{behaviors}),o={position:new Vector3(0,2,0),rotation:new Euler(),scale:new Vector3(1,1,1)},s=new Simulation();s.start([e],new Map([[e.id,o]]));for(let i=0;i<20;i++)s.update(1/60);assert(!o.position.equals(new Vector3(0,2,0))||!o.scale.equals(new Vector3(1,1,1))||o.rotation.z!==0);s.stop();assert.deepEqual(o.position.toArray(),[0,2,0]);assert.deepEqual(o.scale.toArray(),[1,1,1]);assert.equal(o.rotation.z,0);
  }
});
