let gameAssets=null;
export function setGameAssetRoot(url){if(url.protocol!==location.protocol||url.host!==location.host)throw Error('Invalid asset address');gameAssets=url;}
export function assetUrl(asset) {
  if (asset.storage) return gameAssets?new URL(asset.storage.hash+'.bin',gameAssets).href:'blockage://app/model-assets/' + asset.storage.hash;
  if (asset.data !== undefined) return `data:${asset.mime};base64,${asset.data}`;
  throw new Error('This asset needs the Blockage desktop application.');
}
export async function assetBytes(asset) {
  if (asset.storage) {
    const response = await fetch(assetUrl(asset));
    if (!response.ok) throw new Error('Model binary unavailable. Open the scene with its .assets folder in Blockage desktop.');
    const buffer = await response.arrayBuffer();
    if (buffer.byteLength !== asset.storage.bytes) throw new Error('Model binary has an invalid size.');
    return new Uint8Array(buffer);
  }
  const parts = asset.dataChunks || [asset.data];
  const length = parts.reduce((n, p) => n + p.length * .75 - (p.endsWith('==') ? 2 : p.endsWith('=') ? 1 : 0), 0);
  const bytes = new Uint8Array(length); let offset = 0;
  for (const part of parts) { const binary = atob(part); for (let i = 0; i < binary.length; i++) bytes[offset++] = binary.charCodeAt(i); }
  return bytes;
}
