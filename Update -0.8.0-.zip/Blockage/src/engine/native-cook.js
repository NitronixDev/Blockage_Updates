import { Matrix4, Euler, Quaternion, Vector3 } from 'three';
import { validateDocument } from './document.js';
const kinds = ['box', 'sphere', 'cylinder', 'plane'];
const utf8 = new TextEncoder();
const table = Uint32Array.from({ length: 256 }, (_, i) => {
  for (let k = 0; k < 8; k++) i = (i >>> 1) ^ (i & 1 ? 0xedb88320 : 0);
  return i >>> 0;
});
/** Cook Studio world transforms into BNS1. No implicit substitution or external downloads. */
export function cookNativeScene(input) {
  const doc = validateDocument(input),
    entities = new Map(doc.entities.map((e) => [e.id, e])),
    cached = new Map(),
    rows = [],
    errors = [];
  if(doc.scripts.some(s=>s.type!=='module'&&s.enabled))throw Error('The native BNS1 SDK cannot run Studio scripts. Use Export Windows Game (.exe).');
  const warnings = new Set([
    'Native v1 uses opaque vertex lighting. Studio lighting, camera and post-processing are not baked.',
  ]);
  function world(e) {
    if (cached.has(e.id)) return cached.get(e.id);
    const t = e.transform,
      radians = t.rotation.map((n) => (n * Math.PI) / 180);
    const matrix = new Matrix4().compose(
      new Vector3(...t.position),
      new Quaternion().setFromEuler(new Euler(...radians, 'XYZ')),
      new Vector3(...t.scale),
    );
    const parent = e.parent === null ? null : world(entities.get(e.parent));
    if (parent) matrix.premultiply(parent.matrix);
    const value = { matrix, visible: e.visible && (!parent || parent.visible) };
    cached.set(e.id, value);
    return value;
  }
  for (const e of doc.entities) {
    const fail = (reason) => errors.push(e.name + ' [' + e.id + ']: ' + reason);
    if (Object.keys(e.behaviors || {}).length || e.animation?.keys?.length) {
      fail('port behaviours and animation tracks to C++');
      continue;
    }
    if (e.kind === 'group') {
      warnings.add('Groups are flattened; renderable IDs are preserved.');
      continue;
    }
    const kind = kinds.indexOf(e.kind);
    if (kind < 0) {
      fail('unsupported native object: ' + e.kind);
      continue;
    }
    const m = e.material;
    if (
      m.opacity !== 1 ||
      (m.emissiveIntensity > 0 && m.emissive !== '#000000') ||
      Object.entries(m).some(([k, v]) => /texture$/i.test(k) && v)
    ) {
      fail('textured, transparent and emissive materials are not supported');
      continue;
    }
    const state = world(e),
      p = new Vector3(),
      q = new Quaternion(),
      s = new Vector3();
    state.matrix.decompose(p, q, s);
    if (
      new Matrix4()
        .compose(p, q, s)
        .elements.some(
          (v, i) =>
            Math.abs(v - state.matrix.elements[i]) >
            1e-5 * Math.max(1, Math.abs(v)),
        )
    ) {
      fail('hierarchy introduces shear');
      continue;
    }
    const rot = new Euler()
      .setFromQuaternion(q, 'XYZ')
      .toArray()
      .slice(0, 3)
      .map((v) => (Math.abs(v) < 1e-6 ? 0 : v));
    if (e.collider && (kind !== 0 || rot.some((v) => v !== 0))) {
      fail('native v1 collider must be an unrotated box');
      continue;
    }
    if (
      s.toArray().some((v) => v <= 0 || v > 10000) ||
      p.toArray().some((v) => Math.abs(v) > 100000)
    ) {
      fail('world transform exceeds native bounds');
      continue;
    }
    const id = utf8.encode(e.id),
      name = utf8.encode(e.name);
    if (
      id.length > 800 ||
      name.length > 800 ||
      id.includes(0) ||
      name.includes(0)
    ) {
      fail('invalid UTF-8 identity length or NUL');
      continue;
    }
    rows.push({
      id,
      name,
      kind,
      flags: Number(state.visible) | (Number(e.collider) << 1),
      rgb: parseInt(m.color.slice(1), 16),
      floats: [...p.toArray(), ...rot, ...s.toArray()],
    });
  }
  if (errors.length)
    throw new Error(
      'Native export blocked:\n' +
        errors.slice(0, 50).join('\n') +
        (errors.length > 50 ? '\n… ' + (errors.length - 50) + ' more' : ''),
    );
  const length =
    16 + rows.reduce((n, r) => n + 48 + r.id.length + r.name.length, 0);
  if (length > 8 * 1024 * 1024) throw new Error('Native scene exceeds 8 MiB.');
  const bytes = new Uint8Array(length),
    v = new DataView(bytes.buffer);
  bytes.set([66, 78, 83, 49]);
  v.setUint32(4, 1, true);
  v.setUint32(8, rows.length, true);
  let at = 16;
  for (const r of rows) {
    v.setUint16(at, r.id.length, true);
    v.setUint16(at + 2, r.name.length, true);
    at += 4;
    bytes.set(r.id, at);
    at += r.id.length;
    bytes.set(r.name, at);
    at += r.name.length;
    bytes[at++] = r.kind;
    bytes[at++] = r.flags;
    at += 2;
    v.setUint32(at, r.rgb, true);
    at += 4;
    for (const f of r.floats) {
      v.setFloat32(at, f, true);
      at += 4;
    }
  }
  let crc = 0xffffffff;
  for (const b of bytes.subarray(16))
    crc = table[(crc ^ b) & 255] ^ (crc >>> 8);
  v.setUint32(12, (crc ^ 0xffffffff) >>> 0, true);
  return { bytes, count: rows.length, warnings: [...warnings] };
}

/** Validate a file exported by Studio before copying it into a distribution. */
export function validateNativeBytes(bytes) {
  if (
    !(bytes instanceof Uint8Array) ||
    bytes.length < 16 ||
    bytes.length > 8 * 1024 ** 2
  )
    throw new Error('Invalid BNS1 size.');
  const v = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength),
    count = v.getUint32(8, true);
  if (
    v.getUint32(0, false) !== 0x424e5331 ||
    v.getUint32(4, true) !== 1 ||
    count > 20000 ||
    count > (bytes.length - 16) / 50
  )
    throw new Error('Invalid BNS1 header.');
  let crc = 0xffffffff;
  for (const b of bytes.subarray(16))
    crc = table[(crc ^ b) & 255] ^ (crc >>> 8);
  if ((crc ^ 0xffffffff) >>> 0 !== v.getUint32(12, true))
    throw new Error('BNS1 CRC mismatch.');
  const decoder = new TextDecoder('utf-8', { fatal: true }),
    ids = new Set();
  let at = 16;
  for (let i = 0; i < count; i++) {
    if (at + 4 > bytes.length) throw new Error('Truncated BNS1 identity.');
    const a = v.getUint16(at, true),
      n = v.getUint16(at + 2, true);
    at += 4;
    if (!a || !n || a > 800 || n > 800 || at + a + n + 44 > bytes.length)
      throw new Error('Invalid BNS1 record length.');
    const id = decoder.decode(bytes.subarray(at, at + a)),
      name = decoder.decode(bytes.subarray(at + a, at + a + n));
    at += a + n;
    if (ids.has(id) || id.includes('\0') || name.includes('\0'))
      throw new Error('Invalid or duplicate BNS1 ID.');
    ids.add(id);
    const mesh = bytes[at],
      flags = bytes[at + 1];
    if (
      mesh > 3 ||
      flags > 3 ||
      v.getUint16(at + 2, true) ||
      v.getUint32(at + 4, true) > 0xffffff
    )
      throw new Error('Invalid BNS1 surface.');
    at += 8;
    for (let j = 0; j < 9; j++) {
      const x = v.getFloat32(at, true);
      at += 4;
      if (
        !Number.isFinite(x) ||
        Math.abs(x) > 100000 ||
        (j >= 6 && (x <= 0 || x > 10000)) ||
        (flags & 2 && (mesh !== 0 || (j >= 3 && j < 6 && x !== 0)))
      )
        throw new Error('Invalid BNS1 transform or collider.');
    }
  }
  if (at !== bytes.length) throw new Error('Trailing BNS1 data.');
  return {
    bytes,
    count,
    warnings: ['Cooked BNS1: opaque native rendering profile.'],
  };
}
