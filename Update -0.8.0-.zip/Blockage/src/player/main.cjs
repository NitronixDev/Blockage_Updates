const {app,BrowserWindow,protocol,session}=require('electron');
const path=require('node:path'),{serve}=require('./serve.cjs');
const root=path.join(__dirname,'public');
protocol.registerSchemesAsPrivileged([{scheme:'blockage',privileges:{standard:true,secure:true,supportFetchAPI:true,stream:true}}]);
app.whenReady().then(async()=>{
  session.defaultSession.setPermissionRequestHandler((_w,_p,respond)=>respond(false));
  protocol.handle('blockage',req=>req.method==='GET'?serve(root,req.url,req.headers.get('range')):new Response(null,{status:405}));
  const w=new BrowserWindow({width:1280,height:800,autoHideMenuBar:true,backgroundColor:'#13212b',webPreferences:{nodeIntegration:false,contextIsolation:true,sandbox:true,webSecurity:true,devTools:false}});
  w.removeMenu();w.webContents.setWindowOpenHandler(()=>({action:'deny'}));w.webContents.on('will-navigate',ev=>ev.preventDefault());
  await w.loadURL('blockage://app/index.html'+(process.argv.includes('--compat')?'?compat':''));
}).catch(err=>{console.error(err);app.quit();});
app.on('window-all-closed',()=>app.quit());
