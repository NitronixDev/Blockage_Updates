import { MODEL_MIMES } from '../engine/model-formats.js';
import { validateDocument, LIMITS, uid } from '../engine/document.js';
import { instantiatePrefab } from '../engine/prefab.js';
import { createDocument } from '../engine/document.js';

const download = (filename, data) => {
  const url = URL.createObjectURL(new Blob([data], { type: 'application/json' })); const a = document.createElement('a'); a.href = url; a.download = filename; a.click(); setTimeout(() => URL.revokeObjectURL(url), 5000);
};
function pickFiles(input) {
  return new Promise(resolve => {
    input.value = '';
    const finish = value => { input.removeEventListener('change', changed); input.removeEventListener('cancel', canceled); resolve(value); };
    const changed = () => finish([...input.files]); const canceled = () => finish([]);
    input.addEventListener('change', changed, { once: true }); input.addEventListener('cancel', canceled, { once: true }); input.click();
  });
}
const previewBridge = {
  async info() { return { ok: true, platform: 'browser', electron: 'Browser preview', node: 'Not in browser', chrome: navigator.userAgent.match(/Chrome\/([\d.]+)/)?.[1] || 'Browser', vulkanRequested: false, compatibility: new URLSearchParams(location.search).has('compat'), player: new URLSearchParams(location.search).has('player'), graphics: {} }; },
  async openScene() { try { const [file] = await pickFiles(document.querySelector('#browser-scene-input')); if (!file) return { ok: true, canceled: true }; if (file.size > LIMITS.sceneBytes) throw new Error(`Scene exceeds ${LIMITS.sceneBytes/1048576} MiB.`); return { ok: true, scene: validateDocument(JSON.parse(await file.text())), name: file.name }; } catch (e) { return { ok: false, error: e.message }; } },
  async saveScene(text) { try { const doc = validateDocument(JSON.parse(text)); download(doc.name.replace(/[^a-z0-9_-]/gi, '_') + '.blockage', text); return { ok: true, name: `${doc.name}.blockage` }; } catch(e) { return { ok: false, error: e.message }; } },
  async importAssets(folder=false) {
    try {
      if(folder)throw new Error('Use the desktop application to import a model folder.');
      const files=await pickFiles(document.querySelector('#browser-assets-input')),assets=[],read=async file=>new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result.split(',')[1]);reader.onerror=()=>reject(new Error('Could not read '+file.name));reader.readAsDataURL(file);}),models=new Set(Object.keys(MODEL_MIMES));
      const mimes={png:'image/png',jpg:'image/jpeg',jpeg:'image/jpeg',webp:'image/webp',bmp:'image/bmp',tga:'image/x-tga',dds:'image/vnd-ms.dds',mtl:'text/x-wavefront-mtl',bin:'application/octet-stream',wav:'audio/wav',mp3:'audio/mpeg',ogg:'audio/ogg'},resources=[];
      const companions=['mtl','bin','png','jpg','jpeg','webp','bmp','tga','dds'],hasModels=files.some(f=>models.has(f.name.split('.').pop().toLowerCase()));let total=0;if(files.length>200)throw new Error('Select up to 200 files.');for(const file of files){const ext=file.name.split('.').pop().toLowerCase(),maximum=models.has(ext)||hasModels&&companions.includes(ext)?LIMITS.browserModelBytes:LIMITS.assetBytes;if(!file.size||file.size>maximum)throw new Error(`Assets must be between 1 byte and ${maximum/1048576} MiB.`);total+=file.size;if(total>LIMITS.embeddedBytes)throw new Error(`Import batch exceeds ${LIMITS.embeddedBytes/1048576} MiB.`);if(ext==='blend')throw new Error('Import BLEND in the desktop app; the converter is detected automatically.');const data=await read(file);if(['mtl','bin','png','jpg','jpeg','webp','bmp','tga','dds'].includes(ext))resources.push({name:file.name,mime:mimes[ext],data});if(!models.has(ext)&&!['png','jpg','jpeg','webp','bmp','wav','mp3','ogg'].includes(ext))continue;if(!models.has(ext)&&file.size>LIMITS.assetBytes)continue;const type=models.has(ext)?'model':['wav','mp3','ogg'].includes(ext)?'audio':'texture';assets.push({id:uid(),name:file.name,type,mime:MODEL_MIMES[ext]||mimes[ext],data,bytes:file.size,...(type==='model'?{sourceFormat:ext}: {})});}
      const split=value=>{if(value.data.length>8*1048576){value.dataChunks=[];for(let offset=0;offset<value.data.length;offset+=1048576)value.dataChunks.push(value.data.slice(offset,offset+1048576));delete value.data;}};for(const r of resources)split(r);for(const asset of assets)if(asset.type==='model'){asset.resources=resources;split(asset);}
      return{ok:true,canceled:!files.length,assets};
    }catch(e){return{ok:false,error:e.message};}
  },
  async preferences(){return{ok:false,error:'Preferences are available in the desktop application.'};},
  async savePreferences(){return{ok:false,error:'Preferences are available in the desktop application.'};},
  async checkUpdates(){return{ok:false,error:'GitHub updates are available in the Windows desktop application.'};},
  async installUpdateZip(){return{ok:false,error:'ZIP updates are available in the Windows desktop application.'};},
  onUpdateProgress(){return()=>{};},onImportProgress(){return()=>{};},
  async savePrefab(text,name){try{const prefab=JSON.parse(text);instantiatePrefab(createDocument(),prefab);const filename=name.replace(/[^a-z0-9_-]/gi,'_')+'.blockageprefab';download(filename,text);return{ok:true,name:filename};}catch(e){return{ok:false,error:e.message};}},
  async openPrefab(){try{const [file]=await pickFiles(document.querySelector('#browser-prefab-input'));if(!file)return{ok:true,canceled:true};if(file.size>LIMITS.sceneBytes)throw new Error(`Prefab exceeds ${LIMITS.sceneBytes/1048576} MiB.`);const prefab=JSON.parse(await file.text());instantiatePrefab(createDocument(),prefab);return{ok:true,prefab};}catch(e){return{ok:false,error:e.message};}},
  async autosave(text) { try { localStorage.setItem('blockage-recovery', text); return { ok: true }; } catch { return { ok: false, error: 'Preview recovery storage is full.' }; } },
  async recover() { try { const text = localStorage.getItem('blockage-recovery'); return { ok: true, scene: text ? validateDocument(JSON.parse(text)) : null }; } catch { return { ok: true, scene: null }; } },
  async clearRecovery() { localStorage.removeItem('blockage-recovery'); return { ok: true }; },
  async resetScenePath() { return { ok: true }; },
  async closeWithRecovery(text) { return this.autosave(text); },
  markDirty() {}, windowAction() {}, onMenu() { return () => {}; }
};
function desktopBridge(transport){
  const chunkChars=1048576,inlineChars=4*1048576;
  async function decode(result){const transfer=result?.__blockageTransfer;if(!transfer)return result;if(typeof transfer.id!=='string'||!Number.isInteger(transfer.length)||transfer.length<1||transfer.length>LIMITS.sceneBytes+8*1048576)throw new Error('Invalid response transfer.');const parts=[];let offset=0;try{while(offset<transfer.length){const chunk=await transport.read(transfer.id,offset);if(!chunk.ok)throw new Error(chunk.error);if(typeof chunk.data!=='string'||!chunk.data.length||chunk.data.length>chunkChars||offset+chunk.data.length>transfer.length)throw new Error('Invalid response chunk.');parts.push(chunk.data);offset+=chunk.data.length;}return JSON.parse(parts.join(''));}finally{await transport.drop(transfer.id).catch(()=>{});}}
  function encodeArgs(args){return '['+args.map(value=>{if(typeof value!=='string'||value.length<=inlineChars)return JSON.stringify(value);const pieces=[];for(let offset=0;offset<value.length;offset+=chunkChars)pieces.push(JSON.stringify(value.slice(offset,offset+chunkChars)).slice(1,-1));return '"'+pieces.join('')+'"';}).join(',')+']';}
  async function request(method,args){let id=null;try{if(args.some(value=>typeof value==='string'&&value.length>inlineChars)){const text=encodeArgs(args),begin=await transport.begin(text.length);if(!begin.ok)throw new Error(begin.error);id=begin.id;for(let offset=0;offset<text.length;offset+=chunkChars){const result=await transport.append(id,offset,text.slice(offset,offset+chunkChars));if(!result.ok)throw new Error(result.error);}return await decode(await transport.invoke(method,[{__blockageArgsTransfer:id}]));}return await decode(await transport.invoke(method,args));}catch(error){return{ok:false,error:error.message};}finally{if(id)await transport.drop(id).catch(()=>{});}}
  const api={};for(const method of ['exportGame','info','openScene','saveScene','preferences','savePreferences','checkUpdates','installUpdate','installUpdateZip','openUpdateFolder','restartUpdated','savePrefab','openPrefab','autosave','recover','clearRecovery','resetScenePath','closeWithRecovery'])api[method]=(...args)=>request(method,args);
  api.importAssets=(folder=false)=>request('importAssets',[Boolean(folder)]);
  for(const method of ['markDirty','windowAction','onMenu','onUpdateProgress','onImportProgress'])api[method]=(...args)=>transport[method](...args);
  return Object.freeze(api);
}
export const bridge=window.blockageDesktopTransport?desktopBridge(window.blockageDesktopTransport):previewBridge;
if(window.blockageDesktopTransport)window.blockageDesktop=bridge;
