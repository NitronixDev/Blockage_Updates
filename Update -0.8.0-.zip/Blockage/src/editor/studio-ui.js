import { QUALITY_PROFILES, applyQualityProfile } from '../engine/render-settings.js';
import { kindLabel } from '../engine/object-names.js';
import { auditScene } from '../engine/scene-audit.js';
import { bridge } from './bridge.js';

const $ = selector => document.querySelector(selector);
const escape = text => String(text ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
const number = value => Number.isFinite(value) ? value.toLocaleString('en-US', { maximumFractionDigits: 1 }) : '—';

export function installStudioUI(Editor) {
  const original = Object.fromEntries(['installEvents', 'action', 'renderAll', 'renderInspector', 'updateStats', 'addMenu', 'menu'].map(name => [name, Editor.prototype[name]]));
  Object.assign(Editor.prototype, {
    installEvents() {
      original.installEvents.call(this);
      const toolbar = document.createElement('div'); toolbar.className = 'quality-toolbar';
      toolbar.innerHTML = `<label for="quality-profile">Quality</label><select id="quality-profile" aria-label="Graphics quality profile"><option value="custom">Custom</option>${Object.entries(QUALITY_PROFILES).map(([key, p]) => `<option value="${key}">${p.label}</option>`).join('')}</select><button class="small-tool" data-action="profiler">Profiler</button>`;
      $('.main-toolbar').insertBefore(toolbar, $('#render-view'));
      $('#quality-profile').addEventListener('change', async event => {
        const name = event.target.value; if (name === 'custom') return;
        await this.mutate('Graphics profile: ' + QUALITY_PROFILES[name].label, () => { applyQualityProfile(this.doc.settings, name); this.engine.applySettings(); }, false);
        this.updateQualityLabel();
      });
      const tabs = $('.content-tabs'), tab = document.createElement('button');
      tab.className = 'content-tab'; tab.dataset.contentTab = 'profiler'; tab.textContent = 'Profiler'; tabs.insertBefore(tab, tabs.querySelector('.tab-fill'));
      const audit = document.createElement('button'); audit.className = 'small-button'; audit.dataset.action = 'audit'; audit.textContent = 'Scene Audit'; tabs.insertBefore(audit, tabs.querySelector('[data-action="import"]'));
      const panel = document.createElement('div'); panel.id = 'profiler-panel'; panel.className = 'profiler-panel'; panel.hidden = true; $('#content-panel').append(panel);
      document.addEventListener('click', event => {
        const contentTab = event.target.closest('[data-content-tab]'); if (!contentTab) return;
        panel.hidden = contentTab.dataset.contentTab !== 'profiler'; if (!panel.hidden) this.renderProfiler();
      });
      const resolution = document.createElement('span'); resolution.id = 'resolution-status'; $('#backend-status').before(resolution);
      const subtitle = document.createElement('span'); subtitle.className = 'studio-badge'; subtitle.textContent = 'STUDIO WORKSPACE'; $('.brand').after(subtitle);
      $('.outliner .panel-heading > span').textContent = 'Scene Hierarchy';
      $('[data-content-tab="assets"]').textContent = 'Content Browser';
      $('[data-content-tab="animation"]').textContent = 'Sequencer';
      $('[data-content-tab="console"]').firstChild.textContent = 'Output Log ';
      $('#outliner-search').placeholder = 'Search objects…';
    },
    updateQualityLabel() {
      const control = $('#quality-profile'); if (!control) return;
      control.value = Object.keys(QUALITY_PROFILES).find(key => Object.entries(QUALITY_PROFILES[key]).every(([field, value]) => field === 'label' || this.doc.settings[field] === value)) || 'custom';
      control.disabled = this.playing || this.busy;
    },
    renderAll() { original.renderAll.call(this); this.updateQualityLabel(); },
    renderInspector() {
      original.renderInspector.call(this);
      $('#inspector-heading').textContent = this.settingsView ? 'World Settings' : 'Inspector';
      if (!this.settingsView && this.selected) {
        const label = document.createElement('span'); label.className = 'component-type'; label.textContent = kindLabel(this.selected.kind); $('.entity-title')?.append(label);
        if (this.selected.kind === 'spotLight') {
          const e = this.selected, section = $('[data-property-group="light"] section');
          section?.insertAdjacentHTML('beforeend', this.numberField('Range (m)', 'light.distance', e.light.distance, 0, 1000, 1) + this.numberField('Half Cone (°)', 'spot.angle', e.spot.angle, 1, 89, 1) + this.rangeField('Penumbra', 'spot.penumbra', e.spot.penumbra) + '<p class="small-note">Rotate the light to aim its local −Z axis. Intensity is in candela.</p>');
        }
      }
      this.updateQualityLabel();
    },
    renderSettings() {
      const s = this.doc.settings;
      const nf = (label, key, min, max, step = .05) => this.numberField(label, 'settings.' + key, s[key], min, max, step);
      const rf = (label, key, min, max, step = .05) => this.rangeField(label, 'settings.' + key, s[key], min, max, step);
      const check = (label, key) => this.checkField(label, 'settings.' + key, s[key]);
      const choice = (label, key, options) => this.selectField(label, 'settings.' + key, s[key], options);
      const section = (title, body) => `<section class="inspector-section"><div class="section-title">${title}</div>${body}</section>`;
      $('#inspector-content').innerHTML = `<div class="entity-header"><div class="entity-title"><input aria-label="Scene name" data-prop="world.name" value="${escape(this.doc.name)}" maxlength="200"><span class="component-type">Scene · render settings</span></div></div><div class="${this.playing ? 'inspector-disabled' : ''}">` +
        section('Environment & Lighting', this.colorField('Background', 'settings.background', s.background) + nf('Fog Density', 'fog', 0, .2, .001) + rf('Hemisphere Fill', 'ambient', 0, 5) + rf('Environment IBL', 'environmentIntensity', 0, 5) + '<p class="small-note">IBL uses the built-in studio environment, not real-time global illumination.</p>') +
        section('Color & Post Processing', choice('Tone Mapping', 'toneMapping', [['agx', 'AgX'], ['aces', 'ACES Filmic'], ['neutral', 'Neutral']]) + rf('Exposure', 'exposure', .1, 5) + check('Bloom', 'bloom') + rf('Bloom Strength', 'bloomStrength', 0, 2, .01) + nf('Bloom Threshold', 'bloomThreshold', 0, 10) + rf('Bloom Radius', 'bloomRadius', 0, 1)) +
        section('Ambient Occlusion', check('Screen-space GTAO', 'ambientOcclusion') + nf('Radius (m)', 'aoRadius', .05, 5) + rf('Strength', 'aoStrength', 0, 2) + '<p class="small-note">Half-resolution, denoised contact occlusion for indirect lighting. Adds a normal/depth prepass; off in Performance and Balanced.</p>') +
        section('Shadows', check('Enabled', 'shadows') + choice('Map Quality', 'shadowQuality', [['low', 'Low · 512'], ['medium', 'Medium · 1024'], ['high', 'High · 2048']]) + nf('Max Shadow Lights', 'maxShadowLights', 0, 64, 1) + choice('Updates', 'shadowUpdate', [['automatic', 'Cache while editing'], ['realtime', 'Every frame']]) + '<p class="small-note">Budget follows scene order. Point maps are 256 / 512 / 512 per face. Simulation refreshes shadows every frame.</p>') +
        section('Scalability', rf('Render Scale', 'renderScale', .5, 1.5) + nf('Pixel Ratio Cap', 'maxPixelRatio', 1, 2, .1) + check('Adaptive Resolution', 'dynamicResolution') + rf('Minimum Scale', 'minRenderScale', .5, 1) + nf('Target FPS', 'targetFPS', 30, 144, 1) + '<p class="small-note">Adaptive resolution trades pixel detail for frame time. It is not an FPS guarantee or a CPU optimization.</p>') +
        section('Viewport & Sequencer', check('Grid', 'grid') + this.numberField('Duration (s)', 'timeline.duration', this.doc.timeline.duration, .1, 600) + this.numberField('Timeline FPS', 'timeline.fps', this.doc.timeline.fps, 1, 120, 1) + this.checkField('Loop Timeline', 'timeline.loop', this.doc.timeline.loop)) + '</div>';
    },
    updateStats(stats) {
      original.updateStats.call(this, stats);
      $('#resolution-status').textContent = `${stats.width} × ${stats.height} · ${Math.round(stats.scale * 100)}%`;
      $('#frame-status').title = `Frame interval p95: ${number(stats.p95)} ms. CPU update: ${number(stats.updateMs)} ms; submission: ${number(stats.submitMs)} ms. Not GPU execution time.`;
      if (!$('#profiler-panel').hidden) this.renderProfiler();
      this.updateQualityLabel();
    },
    renderProfiler() {
      const s = this.stats, panel = $('#profiler-panel');
      if (!s?.samples) { panel.innerHTML = '<p class="small-note">Collecting frame samples…</p>'; return; }
      const target = 1000 / this.doc.settings.targetFPS, max = Math.max(33.4, target * 1.5, ...s.history);
      const points = s.history.map((ms, i) => `${(i * 400 / Math.max(1, s.history.length - 1)).toFixed(1)},${(60 - Math.min(ms, max) / max * 58).toFixed(1)}`).join(' ');
      const metrics = [['FPS', number(s.fps)], ['Frame p50 / p95', `${number(s.p50)} / ${number(s.p95)} ms`], ['CPU update', `${number(s.updateMs)} ms`], ['CPU submit', `${number(s.submitMs)} ms`], ['Draw submissions', number(s.calls)], ['Triangles submitted', number(s.triangles)], ['Static instances / batches', `${s.instances} / ${s.batches}`], ['Shadow lights', s.shadowLights], ['Textures / geometries', `${s.textures} / ${s.geometries}`], ['Render buffer', `${s.width} × ${s.height}`]];
      metrics.splice(2, 0, ['Frame p99', `${number(s.p99)} ms`], ['Frames over budget', `${s.overBudget} / ${s.samples} (${number(s.overBudgetPercent)}%)`]);
      panel.innerHTML = `<div class="profiler-chart"><div class="profiler-chart-title">FRAME TIME <span>${s.samples} recent samples · ${number(target)} ms target</span></div><svg viewBox="0 0 400 64" role="img" aria-label="Recent frame intervals in milliseconds"><path d="M0 ${(60 - target / max * 58).toFixed(1)} H400" class="budget-line"/><polyline points="${points}"/></svg><p>CPU submission ≠ GPU time. Draws include shadow and post passes; resource counts are not VRAM usage.</p><div class="profiler-actions"><button class="small-button" data-action="resetProfiler">Reset Samples</button><button class="small-button" data-action="exportProfiler">Export JSON</button></div></div><div class="profiler-metrics">${metrics.map(([label, value]) => `<div><span>${label}</span><strong>${escape(value)}</strong></div>`).join('')}</div>`;
    },
    showAudit() {
      const issues = auditScene(this.doc, this.stats);
      this.showModal('Scene Audit', `<p>Read-only diagnostics. Your objects, materials and settings are unchanged.</p><div class="audit-list">${issues.map(i => `<div class="audit-item ${i.level}"><strong>${i.level.toUpperCase()}</strong><p>${escape(i.message)}</p></div>`).join('')}</div>`, [{ label: 'Close', primary: true, action: () => this.closeModal() }]);
    },
    addMenu(anchor) { original.addMenu.call(this, anchor); this.showDropdown(anchor, [...this.dropdownEntries, { label: 'Spot Light', icon: 'light', action: () => this.addEntity('spotLight') }]); },
    menu(name, anchor) {
      original.menu.call(this, name, anchor);
      if (name === 'help') this.showDropdown(anchor, [...this.dropdownEntries, { label: 'Install Update ZIP…', icon: 'package', action: () => this.action('updateZip') }]);
      if (name === 'view' || name === 'file') {
        const entries = name === 'view' ? [{ label: 'Performance Profiler', icon: 'bolt', action: () => this.action('profiler') }, { label: 'Scene Audit', icon: 'check', action: () => this.showAudit() }] : [];
        if (name === 'file') entries.push({ label: 'Export Native Scene (.bns)…', icon: 'package', action: () => this.action('exportNative') });
        this.showDropdown(anchor, [...this.dropdownEntries, { separator: true }, ...entries]);
      }
    },
    async action(action, anchor) {
      if (action === 'exportNative') {
        if(this.playing||this.busy){this.toast('Stop simulation and finish the current operation first.');return;}
        try {
          const {cookNativeScene}=await import('../engine/native-cook.js');
          const {bytes,count,warnings}=cookNativeScene(this.doc);
          this.showModal('Export Native Scene','<p>'+count+' native primitives. Your Studio scene is unchanged.</p><p>'+warnings.map(escape).join('<br>')+'</p>',[
            {label:'Cancel',action:()=>this.closeModal()},
            {label:'Export .bns',primary:true,action:()=>{const url=URL.createObjectURL(new Blob([bytes],{type:'application/octet-stream'})),link=document.createElement('a');link.href=url;link.download='level.bns';link.click();setTimeout(()=>URL.revokeObjectURL(url),5000);this.closeModal();}}
          ]);
        } catch(error) { this.showModal('Native export blocked','<pre class="release-notes">'+escape(error.message)+'</pre>',[{label:'Close',action:()=>this.closeModal()}]); }
        return;
      }
      if (action === 'updateZip') {
        this.showModal('Prepare local update', '<p id="update-stage">Choose a trusted Update -VERSION-.zip file…</p><progress id="update-progress" max="100" value="0"></progress>');
        const result = await bridge.installUpdateZip();
        if (result.canceled) { this.closeModal(); return; }
        if (!result.ok) { this.showModal('Update not installed', `<p>${escape(result.error)}</p>`, [{ label: 'Close', action: () => this.closeModal() }]); return; }
        this.showModal('Update ' + result.version + ' ready', '<p>The ZIP has been extracted and verified. Your running engine is unchanged. Save and restart to replace only the listed engine folders; projects remain outside those folders.</p>', [{ label: 'Later', action: () => this.closeModal() }, { label: 'Save & Restart', primary: true, action: async () => { this.stop(); if (this.dirty && !await this.save()) return; const r = await bridge.restartUpdated(); if (!r.ok) this.toast(r.error, true); } }]);
        return;
      }
      if (action === 'profiler') { $('[data-content-tab="profiler"]').click(); return; }
      if (action === 'audit') return this.showAudit();
      if (action === 'resetProfiler') { this.engine.profiler.reset(); this.stats = null; this.renderProfiler(); return; }
      if (action === 'exportProfiler') {
        if (!this.stats?.samples) return;
        const report = { format: 'blockage.profile', version: 1, engine: '0.8.0', timestamp: new Date().toISOString(), scene: this.doc.name, settings: this.doc.settings, metrics: this.stats, notes: ['CPU submit is not GPU execution time.', 'Draw calls and triangles include all passes.', 'No VRAM measurement is available.'] };
        const url = URL.createObjectURL(new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' })), a = document.createElement('a');
        a.href = url; a.download = 'Blockage_Profile.json'; a.click(); setTimeout(() => URL.revokeObjectURL(url), 5000); return;
      }
      return original.action.call(this, action, anchor);
    }
  });
}
