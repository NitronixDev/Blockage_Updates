import {API} from './toolchain/shared.js';
export const sdk=`#pragma once
extern "C" { int bg_self(); int bg_find(const char*); int bg_key(int); float bg_axis(int,int); void bg_move(int,float,float,float); void bg_rotate(int,float,float,float); void bg_emit(int,int); void bg_ripple(int,float,float,float); void bg_show(int,int); void bg_hud(const char*); }
namespace bg {using Entity=int; inline int self(){return bg_self();} inline int find(const char* n){return bg_find(n);} inline bool key(int k){return bg_key(k)!=0;} inline float x(int id){return bg_axis(id,0);} inline float y(int id){return bg_axis(id,1);} inline float z(int id){return bg_axis(id,2);} inline void move(int id,float x,float y,float z){bg_move(id,x,y,z);} inline void rotate(int id,float x,float y,float z){bg_rotate(id,x,y,z);} inline void emit(int id,int n){bg_emit(id,n);} inline void ripple(int id,float x,float z,float a){bg_ripple(id,x,z,a);} inline void show(int id,bool v){bg_show(id,v);} inline void hud(const char* text){bg_hud(text);} }
#define BG_START extern "C" void on_start()
#define BG_UPDATE extern "C" void on_update(float dt)
#define BG_TRIGGER extern "C" void on_trigger(int sensor,int actor)
`;
const cache=new Map();
export async function compileCpp(source,headers=[],read=async n=>{const r=await fetch(new URL('./toolchain/'+n+'.wasm',import.meta.url));if(!r.ok)throw Error('Missing compiler: '+n);return r.arrayBuffer();}){
 const module=n=>{if(!cache.has(n))cache.set(n,Promise.resolve(read(n)).then(WebAssembly.compile).catch(e=>{cache.delete(n);throw e;}));return cache.get(n);};let log='';const api=new API({noSysroot:true,memfs:'memfs',compileStreaming:module,hostWrite:s=>{log=(log+s).slice(-16000);}}),enc=new TextEncoder();
 try{await api.ready;const names=new Set(['blockage']);api.memfs.addFile('blockage.hpp',enc.encode(sdk));for(const h of headers){if(!/^[A-Za-z_][A-Za-z0-9_]{0,47}$/.test(h.name)||names.has(h.name)||h.source.length>65536)throw Error('Invalid header');names.add(h.name);api.memfs.addFile(h.name+'.hpp',enc.encode(h.source));}if(typeof source!=='string'||source.length>65536)throw Error('Invalid source');api.memfs.addFile('Script.cpp',enc.encode(source));
 await api.run(await module('clang'),'clang','-cc1','-triple','wasm32-unknown-unknown','-emit-obj','-x','c++','-std=c++17','-ffreestanding','-ferror-limit','8','-I','.','-O1','-o','Script.o','Script.cpp');
 await api.run(await module('lld'),'wasm-ld','--no-entry','--allow-undefined','--export-all','--strip-all','--initial-memory=131072','--max-memory=2097152','-z','stack-size=32768','Script.o','-o','Script.wasm');const bytes=api.memfs.getFileContents('Script.wasm').slice();if(bytes.length>524288)throw Error('Script exceeds 512 KiB');const m=await WebAssembly.compile(bytes);
 if(!WebAssembly.Module.exports(m).some(x=>x.kind==='function'&&['on_start','on_update','on_trigger'].includes(x.name)))throw Error('Define BG_START, BG_UPDATE or BG_TRIGGER.');
 for(const x of WebAssembly.Module.imports(m))if(x.module!=='env'||x.kind!=='function'||!/^bg_(self|find|key|axis|move|rotate|emit|ripple|show|hud)$/.test(x.name))throw Error('Unavailable capability: '+x.name);return bytes;
 }catch(e){throw Error(log.replace(/\x1b\[[0-9;]*m/g,'').trim()+'\n'+e.message);}
}
