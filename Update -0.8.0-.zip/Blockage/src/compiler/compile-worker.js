import {compileCpp} from './compiler.js';
self.onmessage=async({data:m})=>{try{const bytes=await compileCpp(m.source,m.headers);self.postMessage({bytes},[bytes.buffer]);}catch(e){self.postMessage({error:e.message});}};
