# Blockage Studio 0.8.0 — de la scène vide au jeu Windows

## 1. Installer et partir de zéro

Depuis Studio **0.7.0**, utilise **Help → Install Update ZIP…** avec `Update -0.8.0-.zip` intact, puis accepte le redémarrage. Pour diffuser la mise à jour, c’est ce même ZIP, sans le renommer ni l’extraire, qu’il faut mettre à la racine de `NitronixDev/Blockage_Updates`. Si tu es encore en 0.6.1, installe d’abord le correctif 0.7.0. Les projets et leurs dossiers `.assets` ne sont pas des composants de mise à jour. Sauvegarde néanmoins une copie de tes scènes avant de les ouvrir avec le nouveau format (v8).

**File → New Scene** ouvre une scène sans objet, sans éclairage placé et sans galerie. La grille est un repère de l’éditeur. L’explorateur de scène ne montre que tes entités ; le panneau Assets ne montre que tes imports. **Add** sert à créer une primitive, un groupe, une caméra ou une lumière ; les simulations sont dans **Properties → Behaviors → Add Behavior**. Le moteur ne supprime pas les fichiers d’exemple que tu aurais déjà téléchargés ou modifiés. Les imports de maillage et les animations de squelette existantes restent pris en charge.

Pour une première scène, ajoute une **Scene Camera**, une **Directional Light** et un mesh ou un modèle importé. Renomme le projet dans **Scene Settings** : ce nom servira aussi au fichier Windows. Sauvegarde le projet en `.blockage` pour continuer à l’éditer. Le fichier exécutable est un export distinct.

## 2. Construire une eau qui laisse voir le fond

1. Ajoute un **Scene Group** vide. Sélectionne-le et choisis **Add Behavior → Water Surface**. Place un objet coloré un peu sous la surface et une lumière au-dessus : tu auras un témoin pour régler la transparence.
2. Dans **Water Surface**, commence avec **Refraction · quality**, **Clarity 0,91**, **Surface roughness 0,095**, **Fine ripples 0,19**. En qualité, le matériau utilise la transmission, la réfraction (indice 1,333), l’environnement de la scène et la normale de la surface simulée.
3. Pour une piscine claire, augmente la **distance d’absorption** (ex. 15 m), choisis une teinte peu saturée et une faible épaisseur optique. Pour une eau de lac, rapproche la distance d’absorption de 3–5 m et donne une teinte vert-bleu. **Optical thickness** est une épaisseur de matériau réglée par toi : ce n’est pas une mesure du relief du fond.
4. Les grosses vagues, la pluie et les impacts modifient un champ de hauteurs à pas fixe ; **Fine ripples** ajoute le relief fin pour les reflets. Essaie de déplacer ou laisser tomber un collider primitif dans la surface en Play : aucun bouton Ripple n’est nécessaire. En C++, `bg::ripple(eau,x,z,force)` prend les coordonnées locales à la surface.
5. **Alpha · fast** évite la passe de réfraction. Garde cette option pour de l’eau éloignée ou une machine plus lente. Le coût de la résolution de simulation et celui de la réfraction sont distincts. Pas de caustiques tracées ni de reconstruction du fond océanique dans cette version.

## 3. Un vêtement sur ton propre modèle

**Import → modèle → sélectionner son instance → Add Behavior → Garment Cloth · select vertices**. Choisis le sous-maillage dans la liste. Cadre et oriente le modèle avant d’ouvrir le sélecteur. Dessine un rectangle : les points cyan sont simulés. **Shift** ajoute ; **Alt** retire et rend les sommets rigides. La sélection traverse le sous-maillage, dos compris. Change de sous-maillage pour travailler indépendamment, puis clique **Apply**.

Pour une cape, laisse la rangée des épaules hors sélection. Elle suit le modèle ou le squelette ; le bas réagit à la gravité et au vent, en temps réel. **Stop** retire la copie d’affichage et restaure le mesh d’origine. Le masque est un ensemble d’indices, pas une animation bake. Un changement de topologie peut obliger à repeindre. Choisis un maillage suffisamment subdivisé. Collisions prises en charge : sphères et boîtes primitives proches ; pas d’autocollision, de déchirure ou de collision triangulaire complète du corps.

**Add Behavior → Weld · attach to target** : choisis l’objet entier ou une partie du modèle, puis un autre modèle, un objet ou un groupe. **Solid only** soude la partie rigide et laisse la sélection de tissu libre. **All vertices** fixe aussi le tissu au mouvement de la cible. La distance et l’orientation relatives sont conservées à la liaison. Les cycles de weld et de parenté sont refusés. Les budgets par scène sont de 16 384 sommets de vêtement simulés et de 32 768 particules ; ce sont des garde-fous, pas des promesses de FPS.

## 4. Un effet d’explosion que ton code déclenche

Sur un groupe appelé par exemple **Impact**, ajoute **Particle Emitter**. Ce sont des particules avec une position dans le monde, une vitesse, une durée de vie, de la gravité et de la traînée. Déplacer l’émetteur ne déplace pas celles déjà parties. Les quads sont instanciés et tournés vers la caméra ; les particules alpha d’un même émetteur sont triées en profondeur. Pour un effet entièrement à toi, superpose plusieurs groupes au même endroit :

| Couche | Mélange et forme | Point de départ |
| --- | --- | --- |
| Flash de feu | Additive, sphère | 30 à 60 particules, 0,12–0,35 s ; jaune pâle vers orange, petite taille finale |
| Étincelles | Additive, cône large | 50 à 120 particules, vitesse 8–20, gravité −9,8, fin de vie courte |
| Fumée | Alpha, cône vertical | 20 à 40 particules, gris vers gris foncé, vitesse 0,5–2, taille croissante, 1–3 s |

Pour contrôler le départ, règle **Rate / s = 0** et désactive **Burst on Play**. Sur l’objet de l’émetteur, ajoute **Object Script · C++** et remplace son contenu :

```cpp
#include "blockage.hpp"

BG_UPDATE {
    static bool espaceAvant = false;
    const bool espace = bg::key(32);
    if (espace && !espaceAvant)
        bg::emit(bg::self(), 90);
    espaceAvant = espace;
}
```

**Build** (Ctrl+Entrée) compile ; **F5** lance le jeu. Clique dans la vue 3D pour lui donner le focus, puis appuie sur Espace. Pour plusieurs couches, utilise des noms uniques et appelle aussi `bg::emit(bg::find("Fumee"), 28)`, etc. Les émetteurs fournissent les briques de l’effet, pas une séquence empruntée à un jeu commercial.

## 5. Écrire le gameplay en C++

Le bouton **</> C++** ouvre l’éditeur avec coloration, recherche, numéros de lignes et diagnostics de compilation. Le **World Script** orchestre la scène, l’**Object Script** connaît son propriétaire via `bg::self()`, le **Header Module** s’inclut par son nom (par exemple `#include "Shared.hpp"`). Les trois sont sauvegardés dans le projet. Les modules activés sont compilés avec un véritable Clang C++17 local. Il n’y a ni service de compilation distant à configurer ni chemin à renseigner.

| Point d’entrée | Appel |
| --- | --- |
| `BG_START` | Une fois au démarrage du script |
| `BG_UPDATE` | Mise à jour à pas fixe ; `dt` en secondes |
| `BG_TRIGGER` | Entrée dans un Trigger en Game View ; `sensor` et `actor` identifient la zone et le joueur ou la caméra |

API : `bg::self`, `find`, `key`, `x/y/z`, `move` (déplacement dans le monde), `rotate` (degrés locaux), `show`, `emit`, `ripple`, `hud`. Les noms d’entités utilisés par `find` devraient être uniques. Le script d’objet est le bon choix pour `self` ; un script global recherche sa cible par nom. Les scripts sont isolés dans un worker ; leurs commandes aboutissent à une étape de simulation suivante, pas de façon synchrone dans la frame d’affichage. Les corps rigides et les joueurs contrôlés ne sont pas déplacés en contournant leur contrôleur avec `move`.

La cible des scripts Studio est **WebAssembly freestanding** : pas de bibliothèque standard complète, de Win32, de fichiers ou de bibliothèques DLL en script. Boucles, fonctions, types, classes et templates C++ restent disponibles. Pour un binaire sans Electron, le **SDK natif C++20/D3D11** du dossier `src/native` est une filière séparée. Son export BNS1 ne convertit pas les scripts, l’eau ou les VFX de Studio.

## 6. Exporter en .exe sous Windows x64

1. Vérifie la scène en **Play**, puis clique **Stop**. Enregistre ton projet (Ctrl+S).
2. Dans la version **bureau Windows x64**, utilise **File → Export Windows Game (.exe)…**. Choisis **le dossier parent** de ta livraison, pas le fichier .exe de Studio. Un sous-dossier existant du même nom n’est jamais écrasé.
3. Ouvre le sous-dossier créé et double-clique **NomDuJeu.exe**, puis **Play**. Envoie ou compresse **tout le dossier** : l’exécutable, les DLL, `locales` et `resources`. Ne copie pas uniquement le .exe. Le joueur n’a besoin ni de npm, ni de Studio, ni d’un accès réseau.

Le jeu embarque le runtime Windows de Studio et les modules de gameplay déjà compilés, pas le compilateur, l’éditeur ou les scripts C++ en clair. Les GLB externes sont recopiés depuis leurs fichiers vérifiés et restent lisibles par plages, même pour un gros modèle. L’export n’est ni un installeur signé ni une publication Steam. Sur une machine où WebGPU pose problème, lance `"NomDuJeu.exe" --compat` pour utiliser WebGL 2.

Depuis les sources : `npm run dist` fabrique l’installeur de **l’éditeur**, pas le jeu courant. Pour automatiser l’export d’une scène : `node scripts/export-windows.mjs MonJeu.blockage DossierParent` après installation des dépendances Windows. Le troisième argument optionnel accepte le chemin de l’exécutable d’un runtime Electron Windows x64 compatible (version indiquée par `package.json`).
