# Bundled C++ tools and notices

The Studio compiler runs locally. The shipped Clang/LLD/memfs and shared runtime come from [binji/wasm-clang, pinned revision](https://github.com/binji/wasm-clang/tree/648c4a89997a351eef75cdaec3ef5b89d4937dec). The upstream files are named clang, lld and memfs without suffix. Their SHA-256 values in this distribution:

| File | SHA-256 |
| --- | --- |
| clang.wasm | 2a466f0e990329d3230b869d04fc20803eae96a7feb3a3f6c93e25a77b8aed1d |
| lld.wasm | 36419ed202011765222098d7701218378b67f634d50f0a4625059ae2c9860f48 |
| memfs.wasm | 2c72ee42bd9430029dda8c6bafc9f37143f6fe88d5f1ea950a70259ab748bcfe |

The local shared.js adds ESM export and the noSysroot option; this edition supplies its own blockage.hpp and named project headers. Upstream notices are next to the binaries. The current compiler is not a bundled Windows SDK or libc++ distribution.

CodeMirror 6.0.2, @codemirror/lang-cpp 6.0.3, dependencies and accompanying licenses are bundled in src/vendor/cpp-editor. Bundler: esbuild 0.25.12. The exact authoring dependency lock and entry point live in scripts/vendor. To reproduce from that directory, run npm ci and then npm run bundle. Game exports include neither the editor nor the compiler.
