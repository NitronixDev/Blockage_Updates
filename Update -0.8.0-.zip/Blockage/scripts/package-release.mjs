import fs from 'node:fs/promises';
import { createReadStream } from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { Transform, Writable } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { createDeflateRaw } from 'node:zlib';
import { createRequire } from 'node:module';
const require=createRequire(import.meta.url),{crc32}=require('../electron/zip-reader.cjs');
const root=path.resolve(import.meta.dirname,'..'),pkg=JSON.parse(await fs.readFile(path.join(root,'package.json'),'utf8'));
const args=process.argv.slice(2),option=(key,fallback)=>{const i=args.indexOf(key);return i>=0?path.resolve(args[i+1]):fallback;};
const output=option('--output',path.join(root,'release')),runtime=option('--runtime',path.join(root,'runtime')),dependencies=option('--dependencies',path.join(root,'node_modules'));
if(output===root||root.startsWith(output+path.sep))throw new Error('Choose a separate release directory.');
for(const file of [path.join(runtime,'node/node.exe'),path.join(dependencies,'electron/dist/electron.exe')]){const handle=await fs.open(file,'r'),signature=Buffer.alloc(2);await handle.read(signature,0,2,0);await handle.close();if(signature.toString()!=='MZ')throw new Error('Packaging requires Windows x64 Node and Electron: '+file);}
await fs.mkdir(output,{recursive:true});const stage=await fs.mkdtemp(path.join(output,'stage-')),appRoot=path.join(stage,'Blockage');await fs.mkdir(appRoot);
try{
  for(const entry of await fs.readdir(root,{withFileTypes:true})){if(entry.isSymbolicLink())continue;if(entry.isDirectory()&&!['src','electron','assets','scripts','tests','docs','.github'].includes(entry.name))continue;if(entry.isFile()&&!/\.(md|bat|cmd|json|sh)$/.test(entry.name)&&!['LICENSE','.gitignore'].includes(entry.name))continue;await fs.cp(path.join(root,entry.name),path.join(appRoot,entry.name),{recursive:true});}
  await fs.cp(runtime,path.join(appRoot,'runtime'),{recursive:true});await fs.cp(dependencies,path.join(appRoot,'node_modules'),{recursive:true});
  const files=[];async function walk(directory){for(const entry of (await fs.readdir(directory,{withFileTypes:true})).sort((a,b)=>a.name.localeCompare(b.name))){const file=path.join(directory,entry.name);if(entry.isDirectory())await walk(file);else if(entry.isFile())files.push(file);else throw new Error('Unsupported release entry: '+file);}}await walk(appRoot);
  const name=`Blockage_${pkg.version}_Windows_x64.zip`,archive=path.join(output,name),temporary=archive+'.'+crypto.randomUUID()+'.tmp',file=await fs.open(temporary,'wx');let offset=0;const central=[];
  async function write(buffer){let done=0;while(done<buffer.length){const result=await file.write(buffer,done,buffer.length-done,null);if(!result.bytesWritten)throw new Error('ZIP write stopped.');done+=result.bytesWritten;}offset+=buffer.length;if(offset>0xffffffff)throw new Error('Release exceeds ZIP32.');}
  try{for(const source of files){const filename=Buffer.from('Blockage/'+path.relative(appRoot,source).split(path.sep).join('/')),start=offset,header=Buffer.alloc(30);header.writeUInt32LE(0x04034b50,0);header.writeUInt16LE(20,4);header.writeUInt16LE(0x0808,6);header.writeUInt16LE(8,8);header.writeUInt16LE(33,12);header.writeUInt16LE(filename.length,26);await write(header);await write(filename);let bytes=0,compressed=0,crc=0;
    const tracker=new Transform({transform(chunk,_encoding,callback){bytes+=chunk.length;crc=crc32(chunk,crc);callback(null,chunk);}}),sink=new Writable({write(chunk,_encoding,callback){compressed+=chunk.length;write(chunk).then(()=>callback(),callback);}});await pipeline(createReadStream(source),tracker,createDeflateRaw({level:6}),sink);
    const descriptor=Buffer.alloc(16);descriptor.writeUInt32LE(0x08074b50,0);descriptor.writeUInt32LE(crc,4);descriptor.writeUInt32LE(compressed,8);descriptor.writeUInt32LE(bytes,12);await write(descriptor);
    const record=Buffer.alloc(46);record.writeUInt32LE(0x02014b50,0);record.writeUInt16LE(20,4);record.writeUInt16LE(20,6);record.writeUInt16LE(0x0808,8);record.writeUInt16LE(8,10);record.writeUInt16LE(33,14);record.writeUInt32LE(crc,16);record.writeUInt32LE(compressed,20);record.writeUInt32LE(bytes,24);record.writeUInt16LE(filename.length,28);record.writeUInt32LE(start,42);central.push(record,filename);
  }const centralStart=offset;for(const buffer of central)await write(buffer);const end=Buffer.alloc(22);end.writeUInt32LE(0x06054b50,0);end.writeUInt16LE(files.length,8);end.writeUInt16LE(files.length,10);end.writeUInt32LE(offset-centralStart,12);end.writeUInt32LE(centralStart,16);await write(end);await file.close();await fs.rename(temporary,archive);
  }catch(error){await file.close().catch(()=>{});await fs.unlink(temporary).catch(()=>{});throw error;}
  const hash=crypto.createHash('sha256');for await(const chunk of createReadStream(archive))hash.update(chunk);const digest=hash.digest('hex');await fs.writeFile(path.join(output,'SHA256SUMS.json'),JSON.stringify({[name]:digest},null,2)+'\n');console.log(JSON.stringify({archive,bytes:offset,files:files.length,sha256:digest}));
}finally{await fs.rm(stage,{recursive:true,force:true});}
