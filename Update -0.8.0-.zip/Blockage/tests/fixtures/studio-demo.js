import { createDocument, createEntity } from '../../src/engine/document.js';

/** Original procedural scene: no third-party assets, download or baked lighting. */
export function studioLightingLab() {
  const doc = createDocument('Studio Lighting Lab');
  Object.assign(doc.settings, { background: '#101b2d', ambient: .18, environmentIntensity: .55, exposure: 1.05, bloom: true, bloomStrength: .22, bloomThreshold: 1.6, grid: false, shadowQuality: 'high', maxShadowLights: 4 });
  doc.camera = { position: [9, 5.2, 12.5], target: [0, 1.8, -.7] };
  function mesh(kind, name, position, scale, color, metalness = 0, roughness = .65, rotation = [0, 0, 0]) {
    const e = createEntity(kind, { name, transform: { position, rotation, scale } });
    Object.assign(e.material, { color, metalness, roughness }); doc.entities.push(e); return e;
  }
  mesh('box', 'SM_GalleryFloor', [0, -.22, 0], [15, .4, 17], '#303a46', .25, .32);
  mesh('box', 'SM_BackWall', [0, 3, -7], [15, 6, .35], '#303c49');
  mesh('box', 'SM_BackWallInset', [0, 3.2, -6.78], [6.4, 3.5, .16], '#111c28', .15, .5);
  for (let i = 0; i < 6; i++) for (const side of [-1, 1]) {
    const x = side * 5.7, z = 4.6 - i * 2;
    mesh('box', `SM_Column_${side < 0 ? 'L' : 'R'}_${i + 1}`, [x, 2.65, z], [.34, 5.3, .55], '#66717b', .6, .3);
    mesh('box', `SM_RoofBeam_${side < 0 ? 'L' : 'R'}_${i + 1}`, [side * 3.3, 5.25, z], [5.1, .18, .55], '#344250', .55, .35);
    const strip = mesh('box', `FX_LightStrip_${side}_${i}`, [x - side * .2, 2.65, z + .29], [.045, 4.6, .025], '#ffe4b6');
    Object.assign(strip.material, { emissive: '#ffcc88', emissiveIntensity: 3 }); strip.castShadow = false;
  }
  for (const [i, x, color, metallic, roughness] of [[1, -3, '#c9d9e7', 1, .16], [2, 0, '#a26b2d', .95, .24], [3, 3, '#467f95', .15, .28]]) {
    mesh('cylinder', `SM_Plinth_${i}`, [x, .4, -.5], [1.8, .8, 1.8], '#222c38', .35, .42);
    if (i === 2) for (let j = 0; j < 3; j++) mesh('torus', `SM_SculptureRing_${j + 1}`, [x, 2, -.5], [1.65, 1.65, 1.65], color, metallic, roughness, [j * 55, j * 60, j * 25]);
    else mesh('sphere', `SM_MaterialSample_${i}`, [x, 1.65, -.5], [1.7, 1.7, 1.7], color, metallic, roughness);
  }
  for (const side of [-1, 1]) {
    const e = mesh('box', `FX_FloorGuide_${side}`, [side * 4.2, .001, 0], [.025, .01, 14], '#b7dff3');
    Object.assign(e.material, { emissive: '#8dc8ee', emissiveIntensity: 2 }); e.castShadow = false;
  }
  const key = createEntity('directionalLight', { name: 'LGT_Key_Daylight', transform: { position: [4, 9, 3], rotation: [0, 0, 0], scale: [1, 1, 1] } });
  key.light.color = '#d6e8ff'; key.light.intensity = 2.4; doc.entities.push(key);
  for (const [name, x, color] of [['Warm', -3, '#ffcf91'], ['Sculpture', 0, '#ffe5bd'], ['Cool', 3, '#8dcfff']]) {
    const light = createEntity('spotLight', { name: 'LGT_Display_' + name, transform: { position: [x, 4.7, 2], rotation: [-53, 0, 0], scale: [1, 1, 1] } });
    Object.assign(light.light, { color, intensity: 130, distance: 13 }); Object.assign(light.spot, { angle: 29, penumbra: .65 }); doc.entities.push(light);
  }
  return doc;
}
