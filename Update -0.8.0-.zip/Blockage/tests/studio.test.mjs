import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three/webgpu';
import { createDocument, createEntity, validateDocument, clone } from '../src/engine/document.js';
import { RENDER_DEFAULTS, applyQualityProfile, AdaptiveResolution, shadowMapSize } from '../src/engine/render-settings.js';
import { FrameProfiler } from '../src/engine/frame-profiler.js';
import { StaticBatches } from '../src/engine/static-batches.js';
import { uniqueObjectName, kindLabel } from '../src/engine/object-names.js';
import { auditScene } from '../src/engine/scene-audit.js';
import { studioLightingLab } from './fixtures/studio-demo.js';
import { createPrefab, instantiatePrefab } from '../src/engine/prefab.js';

test('v6 scenes migrate without changing authored lighting, names or transforms', () => {
  const old = createDocument('Old'); old.version = 6;
  old.entities.push(createEntity('box', { name: 'My Old Cube' }));
  for (const key of Object.keys(RENDER_DEFAULTS)) delete old.settings[key];
  Object.assign(old.settings, { exposure: .1, ambient: 2.1, background: '#fff475' });
  const before = clone(old), migrated = validateDocument(old);
  assert.deepEqual(old, before); assert.equal(migrated.version, 8);
  assert.deepEqual(migrated.entities, old.entities);
  for (const [key, value] of Object.entries(old.settings)) assert.equal(migrated.settings[key], value);
  assert.equal(migrated.settings.maxShadowLights, 64);
  assert.equal(migrated.settings.toneMapping, 'agx');
});

test('render settings reject bad values and incomplete v7 documents', () => {
  for (const [key, value] of [['renderScale', 2], ['minRenderScale', .1], ['toneMapping', 'magic'], ['maxShadowLights', 2.2], ['targetFPS', NaN], ['shadowUpdate', 'never'], ['shadowQuality', 'ultra'], ['dynamicResolution', 'yes'], ['environmentIntensity', -1]]) {
    const doc = createDocument(); doc.settings[key] = value; assert.throws(() => validateDocument(doc), /Invalid|integers/);
  }
  const doc = createDocument(); doc.settings.renderScale = .5; doc.settings.minRenderScale = .7; assert.throws(() => validateDocument(doc), /Minimum/);
  delete doc.settings.renderScale; assert.throws(() => validateDocument(doc), /renderScale/);
});

test('quality profiles change scalability without destroying artistic settings', () => {
  const doc = createDocument(); Object.assign(doc.settings, { exposure: 1.4, ambient: .22, environmentIntensity: 2, bloomThreshold: 2.3 });
  for (const name of ['performance', 'balanced', 'cinematic']) {
    applyQualityProfile(doc.settings, name); assert.doesNotThrow(() => validateDocument(doc));
    assert.equal(doc.settings.exposure, 1.4); assert.equal(doc.settings.ambient, .22); assert.equal(doc.settings.bloomThreshold, 2.3);
  }
  assert.throws(() => applyQualityProfile(doc.settings, '__proto__'), /Unknown|Cannot|read only/);
  assert.equal(shadowMapSize('high'), 2048); assert.equal(shadowMapSize('high', true), 512);
});

test('adaptive resolution lowers scale with hysteresis and honors lower/upper bounds', () => {
  const controller = new AdaptiveResolution(), settings = { ...RENDER_DEFAULTS, dynamicResolution: true, minRenderScale: .65 };
  controller.configure(settings);
  for (let i = 0; i < 600; i++) controller.update(25, 2);
  assert.equal(controller.scale, .65);
  for (let i = 0; i < 2000; i++) controller.update(16.667, 2);
  assert.equal(controller.scale, 1);
  for (let i = 0; i < 50; i++) controller.update(16.667, 2);
  assert.equal(controller.scale, 1);
});

test('adaptive resolution ignores CPU-bound spikes and disabled mode', () => {
  const c = new AdaptiveResolution(); c.configure({ ...RENDER_DEFAULTS, dynamicResolution: true });
  for (let i = 0; i < 300; i++) c.update(30, 25);
  assert.equal(c.scale, 1); c.update(NaN, 0); c.update(1000, 0); assert.equal(c.scale, 1);
  c.configure({ ...RENDER_DEFAULTS, renderScale: .85 });
  for (let i = 0; i < 200; i++) c.update(40, 1);
  assert.equal(c.scale, .85);
});

test('profiler keeps chronological bounded samples and includes long visible stalls', () => {
  const p = new FrameProfiler(4);
  [10, 20, 30, 40, 500].forEach(ms => p.record(ms, 2, 3));
  p.record(NaN, 0, 0); p.record(10, -1, 0);
  const s = p.snapshot(); assert.deepEqual(s.history, [20, 30, 40, 500]);
  assert.equal(s.p50, 30); assert.equal(s.p95, 500); assert.equal(s.frameMs, 147.5);
  assert.equal(s.updateMs, 2); assert.equal(s.submitMs, 3); assert.equal(s.samples, 4);
  p.reset(); assert.equal(p.snapshot().samples, 0);
});

test('frame pacing uses the selected target and excludes overwritten samples', () => {
  const p = new FrameProfiler(4); [1000, 8, 9, 10, 16].forEach(ms => p.record(ms, 1, 2));
  assert.equal(p.snapshot(60).overBudget, 0); const high = p.snapshot(120);
  assert.equal(high.overBudget, 3); assert.equal(high.overBudgetPercent, 75); assert.equal(high.p99, 16);
  assert.equal(p.snapshot(100).overBudget, 1); assert.equal(p.snapshot(NaN).budgetMs, 1000 / 60);
  p.reset(); assert.equal(p.snapshot(120).overBudgetPercent, 0);
});

test('spot lights round-trip, validate and export as prefabs', () => {
  const doc = createDocument(), spot = createEntity('spotLight'); doc.entities.push(spot);
  assert.deepEqual(validateDocument(doc), doc);
  const target = createDocument(); instantiatePrefab(target, createPrefab(doc, spot.id));
  assert.equal(target.entities[0].kind, 'spotLight'); assert.deepEqual(target.entities[0].spot, spot.spot);
  spot.spot.angle = 90; assert.throws(() => validateDocument(doc), /cone/);
  spot.spot.angle = 30; spot.spot.penumbra = -1; assert.throws(() => validateDocument(doc), /penumbra/);
});

function models(count = 8) {
  const content = new THREE.Group(), geometry = new THREE.BoxGeometry(), material = new THREE.MeshStandardMaterial();
  const entities = [], objects = new Map();
  for (let i = 0; i < count; i++) {
    const e = createEntity('model', { assetId: 'shared' }), root = new THREE.Group(), mesh = new THREE.Mesh(geometry, material);
    e.modelAnimation.enabled = false; root.add(mesh); root.position.set(i * 2, 0, 0); mesh.position.y = 1;
    root.userData.entityId = mesh.userData.entityId = e.id; content.add(root); entities.push(e); objects.set(e.id, root);
  }
  return { content, entities, objects, geometry, material, batches: new StaticBatches(content) };
}

test('static imported meshes batch with correct world matrices and picking IDs', () => {
  const f = models(); f.batches.build(f.entities, f.objects, new Set());
  assert.equal(f.batches.count, 8); assert.equal(f.batches.root.children.length, 1);
  const batch = f.batches.root.children[0], matrix = new THREE.Matrix4();
  batch.getMatrixAt(4, matrix); assert.equal(matrix.elements[12], 8); assert.equal(matrix.elements[13], 1);
  assert.deepEqual(batch.userData.instanceEntities, f.entities.map(e => e.id));
  for (const root of f.objects.values()) assert.equal(root.children[0].layers.mask, 1 << 31);
  f.batches.clear(); for (const root of f.objects.values()) assert.equal(root.children[0].layers.mask, 1);
  assert.equal(f.batches.count, 0); assert.equal(f.batches.root.parent, null);
});

test('model batching excludes selection, dynamic, transparent, morph and mirrored meshes', () => {
  const f = models(12), roots = [...f.objects.values()];
  roots[2].children[0].material = f.material.clone(); roots[2].children[0].material.transparent = true;
  roots[3].children[0].morphTargetInfluences = [0]; roots[4].scale.x = -1; roots[5].visible = false;
  roots[6].children[0].layers.set(2);
  f.batches.build(f.entities, f.objects, new Set([f.entities[0].id]), new Set([f.entities[1].id]));
  assert.equal(f.batches.count, 5);
  for (let i = 0; i < 6; i++) assert.equal(roots[i].children[0].layers.mask, 1);
  assert.equal(roots[6].children[0].layers.mask, 4);
});

test('static batches partition space for frustum culling and restore after rebuild', () => {
  const f = models(8); [...f.objects.values()].slice(4).forEach(o => o.position.x += 64);
  f.batches.build(f.entities, f.objects, new Set()); assert.equal(f.batches.root.children.length, 2);
  f.batches.build(f.entities, f.objects, new Set(f.entities.map(e => e.id))); assert.equal(f.batches.count, 0);
  for (const root of f.objects.values()) assert.equal(root.children[0].layers.mask, 1);
});

test('generated names are readable, unique and never rename existing objects', () => {
  const entities = [{ name: 'Cube' }, { name: 'Cube_001' }, { name: 'cube_002' }], before = clone(entities);
  assert.equal(uniqueObjectName(entities, 'Cube'), 'Cube_003'); assert.deepEqual(entities, before);
  assert.equal(kindLabel('player'), 'Character Controller'); assert.equal(kindLabel('spotLight'), 'Spot Light');
});

test('scene audit reports lighting and budget risks without mutating the scene', () => {
  const doc = createDocument(); doc.settings.exposure = .1; doc.settings.ambient = 3; doc.settings.maxShadowLights = 0;
  doc.entities.push(createEntity('pointLight')); const before = clone(doc);
  const issues = auditScene(doc, { calls: 1300, updateMs: 20, submitMs: 2 });
  assert(issues.some(i => /Exposure/.test(i.message))); assert(issues.some(i => /shadow lights/.test(i.message)));
  assert(issues.some(i => /CPU/.test(i.message))); assert.deepEqual(doc, before);
});

test('original studio lighting scene is valid, uniquely named and self-contained', () => {
  const doc = studioLightingLab(); assert.deepEqual(validateDocument(doc), doc);
  assert.equal(doc.assets.length, 0); assert.equal(new Set(doc.entities.map(e => e.name)).size, doc.entities.length);
  assert.equal(doc.entities.filter(e => e.kind === 'spotLight').length, 3);
});
