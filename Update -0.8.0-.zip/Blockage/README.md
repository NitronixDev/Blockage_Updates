# Blockage Studio 0.8.0 — créer, simuler, exporter en .exe

**File → New Scene** crée une scène vide. Pas de galerie de simulations ni de modèles imposés : ajoute tes meshes et compose leurs comportements. L’éditeur C++17 compile localement vers WebAssembly ; l’export bureau Windows x64 conserve les scripts compilés, les maillages, l’eau réfractive, les vêtements simulés et les émetteurs.

| Ce que tu veux faire | Où aller |
| --- | --- |
| Écrire du C++ | **</> C++** ou **Add Behavior → Object Script · C++** |
| Peindre une zone de vêtement, la fixer | **Add Behavior → Garment Cloth / Weld** |
| Créer une eau transparente ou des particules | **Add Behavior → Water Surface / Particle Emitter** |
| Distribuer ton jeu Windows sans l’éditeur | **File → Export Windows Game (.exe)…**. Distribue le dossier entier. |
| Construire l’installateur de Studio | `npm run dist` sous Windows |
| Installer sur Studio 0.7.0 | `Update -0.8.0-.zip` intact à la racine de NitronixDev/Blockage_Updates ou **Help → Install Update ZIP…** |

[Guide : premier jeu, eau, cloth, C++ et export Windows](docs/PREMIER_JEU_0.8.md). Les fichiers de régression des anciennes démos sont dans les tests, jamais dans les menus de création de Studio. Les scènes existantes migrent au format v8 à l’ouverture ; conserve ta version précédente avant de réenregistrer. Le SDK natif C++20 est **distinct** du Player Studio.

## SDK natif séparé : compiler l’exemple de développement Beacon Run

Prérequis développeur : Visual Studio 2022 ou Build Tools avec **Développement Desktop en C++**, SDK Windows et CMake ≥ 3.20. Les fichiers du niveau sont fournis : aucun téléchargement de dépendance par CMake.

```powershell
cmake -S src/native -B build/native -A x64
cmake --build build/native --config Release --parallel
ctest --test-dir build/native -C Release --output-on-failure
.\build\native\Release\BlockageGame.exe
```

Dans Beacon Run, déplace le bloc orange avec les flèches, ZQSD ou WASD. Récupère les trois balises turquoise et rejoins la sortie rose. **R** recommence, **Échap** quitte. Le titre affiche le compteur et le record. Le record reste dans le profil utilisateur, hors de l’installation.

## Exporter le jeu

Sur un poste de développement avec les dépendances de Studio installées (ou en utilisant `.\npm.cmd` fourni sous Windows) :

```powershell
.\npm.cmd run native:export -- --binary build/native/Release/BlockageGame.exe --scene src/native/sample/beacon-run.blockage --out native-out/beacon
```

Le dossier **native-out/beacon/content/** est le jeu à distribuer. Lance `BlockageGame.exe` à sa racine. Contrairement au jeu, le générateur utilise Node sur la machine de développement. Choisis un nouveau dossier pour chaque export. Pour générer les fichiers SteamPipe, ajoute `--app-id TON_APPID --depot-id TON_DEPOTID`, remplacés par tes **vrais** identifiants numériques.

L’éditeur et le jeu natif n’ont pas encore la même couverture : les matériaux PBR, l’eau, le tissu et les rigs de Studio ne sont pas portés dans le lecteur natif. Le générateur refuse les objets incompatibles par nom au lieu de les effacer du jeu.

**Documentation :** [architecture, API C++, configuration et SteamPipe](docs/ARCHITECTURE_NATIVE_0.7.md) · [mises à jour GitHub](docs/GITHUB_UPDATES.md) · [imports et personnages Studio](docs/IMPORTS_AND_CHARACTERS.md) · [référence de la génération Studio 0.6.1](docs/STUDIO_0.6.1.md).
