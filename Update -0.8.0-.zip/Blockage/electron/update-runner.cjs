const fs=require('node:fs/promises');
const path=require('node:path');
const {spawn}=require('node:child_process');
const {applyPatch}=require('./update-apply.cjs');
const delay=ms=>new Promise(resolve=>setTimeout(resolve,ms));
function launchPlan(plan,platform=process.platform){
  const flags=Array.isArray(plan.flags)?plan.flags.filter(f=>['--blockage-webgl','--blockage-vulkan','--blockage-player'].includes(f)):[];
  if(plan.relaunch?.mode==='packaged'){
    const folder=path.resolve(plan.installationRoot,'..','..'),expected=path.join(folder,platform==='win32'?'Blockage.exe':'blockage');
    if(path.basename(plan.installationRoot)!=='app'||path.basename(path.dirname(plan.installationRoot))!=='resources'||path.resolve(plan.relaunch.executable)!==expected)throw new Error('Invalid installed application restart target.');
    return{executable:expected,args:flags,cwd:folder};
  }
  if(plan.relaunch&&plan.relaunch.mode!=='source')throw new Error('Unknown update restart mode.');
  return{executable:path.join(plan.installationRoot,'node_modules','electron','dist',platform==='win32'?'electron.exe':'electron'),args:[plan.installationRoot,...flags],cwd:plan.installationRoot};
}
async function main() {
  const planFile=process.argv[2],plan=JSON.parse(await fs.readFile(planFile,'utf8'));
  if(!Number.isSafeInteger(plan.parentPid)||plan.parentPid<1)throw new Error('Invalid updater process.');
  const launch=launchPlan(plan);await fs.access(launch.executable);
  for(let attempt=0;attempt<200;attempt++) {
    try { process.kill(plan.parentPid,0); } catch(error) { if(error.code==='ESRCH')break;throw error; }
    if(attempt===199)throw new Error('Blockage did not close. The update was left unapplied.');await delay(300);
  }
  const result=await applyPatch(plan);
  await fs.writeFile(path.join(path.dirname(planFile),'result.json'),JSON.stringify(result));
  const env={...process.env};delete env.ELECTRON_RUN_AS_NODE;
  const child=spawn(launch.executable,launch.args,{cwd:launch.cwd,env,detached:true,stdio:'ignore',shell:false});
  await new Promise((resolve,reject)=>{child.once('spawn',resolve);child.once('error',reject);});child.unref();
}
module.exports={launchPlan};
if(require.main===module)main().catch(async error=>{const file=process.argv[2];if(file)await fs.writeFile(path.join(path.dirname(file),'result.json'),JSON.stringify({ok:false,error:error.message})).catch(()=>{});console.error(error.message);process.exitCode=1;});
