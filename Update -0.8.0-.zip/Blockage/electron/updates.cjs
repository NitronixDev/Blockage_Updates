const fs=require('node:fs/promises'),path=require('node:path'),crypto=require('node:crypto');
const {extractZip}=require('./zip-reader.cjs');
const {REPOSITORY,version,newer,updateName,validatePatch}=require('./update-manifest.cjs');
const MAX_ZIP_BYTES=1073741824;
function parseRepository(value){if(value===REPOSITORY||value==='https://github.com/'+REPOSITORY)return REPOSITORY;throw new Error('The Blockage update repository is fixed in the engine.');}
function allowedUrl(value){const u=new URL(value),h=u.hostname;if(u.protocol!=='https:'||u.username||u.password||u.port||!(['api.github.com','github.com'].includes(h)||h.endsWith('.githubusercontent.com')||/^github-production-release-asset-[a-z0-9-]+\.s3\.amazonaws\.com$/.test(h)))throw new Error('Update URL is outside GitHub.');return u.href;}
class UpdateService {
  constructor({fetchImpl=fetch,directory,installationRoot=path.resolve(__dirname,'..'),currentVersion,packaged=false,onProgress=()=>{}}){this.fetch=fetchImpl;this.directory=directory;this.installationRoot=installationRoot;this.currentVersion=currentVersion;this.packaged=packaged;this.onProgress=onProgress;this.available=null;this.ready=null;this.busy=false;this.lastProgress='';}
  progress(stage,percent){const value=Math.round(percent),signature=stage+value;if(signature===this.lastProgress)return;this.lastProgress=signature;this.onProgress({stage,percent:value});}
  async response(url,accept='application/vnd.github+json'){
    for(let n=0;n<6;n++){
      const response=await this.fetch(allowedUrl(url),{headers:{Accept:accept,'User-Agent':'Blockage/'+this.currentVersion,'X-GitHub-Api-Version':'2022-11-28'},redirect:'manual',signal:AbortSignal.timeout(15*60*1000)});
      if([301,302,303,307,308].includes(response.status)){await response.body?.cancel();const location=response.headers.get('location');if(!location)throw new Error('Missing GitHub redirect.');url=new URL(location,url).href;continue;}
      if(!response.ok){await response.body?.cancel();const error=new Error(response.status===404?'The public repository '+REPOSITORY+' or its update ZIP is unavailable.':`GitHub returned HTTP ${response.status}.`);error.status=response.status;throw error;}
      return response;
    }throw new Error('Too many GitHub redirects.');
  }
  async json(url,accept){const response=await this.response(url,accept),chunks=[];let size=0;for await(const chunk of response.body){size+=chunk.length;if(size>2*1048576)throw new Error('GitHub response is too large.');chunks.push(Buffer.from(chunk));}return JSON.parse(Buffer.concat(chunks).toString());}
  async check(){
    if(this.busy)throw new Error('An update is already downloading.');this.available=null;
    const base=`https://api.github.com/repos/${REPOSITORY}`;let inaccessible=false;
    try{
      const files=await this.json(base+'/contents');
      if(!Array.isArray(files))throw new Error('Invalid repository file list.');
      const candidates=files.filter(file=>file.type==='file'&&/^Update -(\d+\.\d+\.\d+)-\.zip$/.test(file.name||''))
        .map(file=>({...file,version:file.name.match(/^Update -(.*)-\.zip$/)[1]})).filter(file=>{try{return newer(file.version,this.currentVersion);}catch{return false;}})
        .sort((a,b)=>newer(a.version,b.version)?1:newer(b.version,a.version)?-1:0);
      if(candidates.length){const file=candidates[0];if(!Number.isSafeInteger(file.size)||file.size<1||file.size>MAX_ZIP_BYTES||!/^[a-f0-9]{40}$/.test(file.sha||''))throw new Error('Invalid repository update ZIP.');
        this.available={repository:REPOSITORY,version:file.version,name:file.name,size:file.size,gitBlob:file.sha,url:base+'/contents/'+encodeURIComponent(file.name),notes:'Replace only the engine folders included in this update. Existing projects and model files are preserved.'};
        return{ok:true,available:true,...this.available};}
    }catch(error){if(error.status!==404)throw error;inaccessible=true;}
    let release;try{const releases=await this.json(base+'/releases?per_page=100');if(!Array.isArray(releases))throw new Error('Invalid GitHub release list.');release=releases.filter(r=>!r.draft&&!r.prerelease&&(()=>{try{return newer(r.tag_name,this.currentVersion);}catch{return false;}})()).sort((a,b)=>newer(a.tag_name,b.tag_name)?1:newer(b.tag_name,a.tag_name)?-1:0)[0];if(!release)return{ok:true,available:false,currentVersion:this.currentVersion,repository:REPOSITORY};}catch(error){if(error.status===404&&!inaccessible)return{ok:true,available:false,currentVersion:this.currentVersion,repository:REPOSITORY};throw error;}
    if(release.draft||release.prerelease)throw new Error('Only stable published releases are supported.');version(release.tag_name);
    if(!newer(release.tag_name,this.currentVersion))return{ok:true,available:false,currentVersion:this.currentVersion,repository:REPOSITORY};
    const latest=release.tag_name.replace(/^v/,''),name=updateName(latest),asset=release.assets?.find(a=>a.name===name);
    if(!asset||!Number.isSafeInteger(asset.id)||asset.id<1||!Number.isSafeInteger(asset.size)||asset.size<1||asset.size>MAX_ZIP_BYTES)throw new Error(`The release needs ${name} (up to 1 GiB).`);
    let hash=/^sha256:([a-f0-9]{64})$/i.exec(asset.digest||'')?.[1];
    if(!hash){const sums=release.assets.find(a=>a.name==='SHA256SUMS.json');if(!sums||!Number.isSafeInteger(sums.id))throw new Error('GitHub must provide a SHA-256 digest, or attach SHA256SUMS.json.');hash=(await this.json(base+'/releases/assets/'+sums.id,'application/octet-stream'))[name];}
    if(!/^[a-f0-9]{64}$/i.test(hash||''))throw new Error('Invalid release SHA-256 checksum.');
    this.available={repository:REPOSITORY,version:latest,name,size:asset.size,hash:hash.toLowerCase(),url:base+'/releases/assets/'+asset.id,notes:String(release.body||'').slice(0,16000)};
    return{ok:true,available:true,...this.available};
  }
  async install(){
    if(this.busy)throw new Error('An update is already downloading.');if(!this.available)throw new Error('Check for an update first.');
    this.busy=true;const release={...this.available},base=path.join(this.directory,'updates',crypto.randomUUID()),archive=path.join(base,release.name);
    try{
      await fs.mkdir(base,{recursive:true});this.progress('Downloading',0);
      const response=await this.response(release.url,release.gitBlob?'application/vnd.github.raw+json':'application/octet-stream'),hash=crypto.createHash('sha256'),git=crypto.createHash('sha1').update('blob '+release.size+'\0'),file=await fs.open(archive,'wx');let bytes=0;
      try{for await(const chunk of response.body){bytes+=chunk.length;if(bytes>release.size)throw new Error('Download exceeds the announced ZIP size.');hash.update(chunk);git.update(chunk);await file.writeFile(chunk);this.progress('Downloading',bytes/release.size*65);}}finally{await file.close();}
      if(bytes!==release.size||release.hash&&hash.digest('hex')!==release.hash||release.gitBlob&&git.digest('hex')!==release.gitBlob)throw new Error('Update download checksum verification failed.');
      this.progress('Extracting',65);const stagedRoot=await extractZip(archive,path.join(base,'staged'),p=>this.progress('Extracting',65+p*25));
      this.progress('Verifying engine files',90);await this.validateStaged(stagedRoot,release.version);
      await fs.unlink(archive);this.ready={version:release.version,path:this.installationRoot,stagedRoot,base};this.progress('Ready to restart',100);
      return{ok:true,version:release.version,path:this.installationRoot};
    }catch(error){await fs.rm(base,{recursive:true,force:true});throw error;}finally{this.busy=false;}
  }
  async validateStaged(stagedRoot,expectedVersion){
    const manifest=await validatePatch(stagedRoot,{expectedVersion,currentVersion:this.currentVersion,installationRoot:this.installationRoot});
    // An installed app owns its Electron binary outside resources/app. Component
    // ZIPs must not pretend to replace that runtime or its packaged dependencies.
    if(this.packaged&&manifest.components.some(c=>['runtime','node_modules'].includes(c)))throw new Error('This ZIP changes runtime/dependencies. Install the new Blockage Setup.exe instead.');
    return manifest;
  }
  async installLocal(filename){
    if(this.busy)throw new Error('An update is already being prepared.');
    if(typeof filename!=='string'||!path.isAbsolute(filename))throw new Error('Select a local update ZIP.');
    const match=/^Update -(\d+\.\d+\.\d+)-\.zip$/.exec(path.basename(filename));
    if(!match)throw new Error('Choose Update -VERSION-.zip, not the full GitHub source archive.');
    version(match[1]);
    this.busy=true;const base=path.join(this.directory,'updates',crypto.randomUUID()),archive=path.join(base,path.basename(filename));
    try{
      const info=await fs.lstat(filename);
      if(!info.isFile()||info.isSymbolicLink()||info.size<1||info.size>MAX_ZIP_BYTES)throw new Error('Update ZIP must be a regular file up to 1 GiB.');
      await fs.mkdir(base,{recursive:true});this.progress('Copying local ZIP',0);await fs.copyFile(filename,archive);
      if((await fs.stat(archive)).size!==info.size)throw new Error('The ZIP changed while it was being copied.');
      this.progress('Extracting',20);const stagedRoot=await extractZip(archive,path.join(base,'staged'),p=>this.progress('Extracting',20+p*65));
      this.progress('Verifying engine files',90);await this.validateStaged(stagedRoot,match[1]);
      await fs.unlink(archive);this.ready={version:match[1],path:this.installationRoot,stagedRoot,base};this.progress('Ready to restart',100);
      return{ok:true,version:match[1],path:this.installationRoot,source:'local'};
    }catch(error){await fs.rm(base,{recursive:true,force:true});throw error;}finally{this.busy=false;}
  }
  async prepareRestart(parentPid,flags=[],portableNode,relaunch){
    if(this.busy)throw new Error('Wait for the update verification to finish.');
    if(!this.ready)throw new Error('No update is ready.');
    await this.validateStaged(this.ready.stagedRoot,this.ready.version);
    if(this.packaged&&relaunch?.mode!=='packaged')throw new Error('Missing installed application restart target.');
    await fs.access(this.installationRoot,require('node:fs').constants.W_OK);
    const directory=path.join(this.ready.base,'runner');await fs.mkdir(directory,{recursive:true});
    for(const name of ['update-runner.cjs','update-apply.cjs','update-manifest.cjs']){
      const fresh=path.join(this.ready.stagedRoot,'electron',name),source=(await fs.stat(fresh).catch(()=>null))?.isFile()?fresh:path.join(__dirname,name);
      await fs.copyFile(source,path.join(directory,name));
    }
    const nodeSource=portableNode||path.join(this.installationRoot,'runtime','node','node.exe'),executable=path.join(directory,process.platform==='win32'?'node.exe':'node');
    await fs.copyFile(nodeSource,executable);if(process.platform!=='win32')await fs.chmod(executable,0o755);
    const planFile=path.join(directory,'plan.json');await fs.writeFile(planFile,JSON.stringify({parentPid,flags,stagedRoot:this.ready.stagedRoot,installationRoot:this.installationRoot,currentVersion:this.currentVersion,expectedVersion:this.ready.version,...(relaunch?{relaunch}:{})},null,2));
    const env={...process.env};delete env.ELECTRON_RUN_AS_NODE;
    return{executable,args:[path.join(directory,'update-runner.cjs'),planFile],directory,env};
  }
}
module.exports={UpdateService,REPOSITORY,parseRepository,version,newer,allowedUrl,updateName};
