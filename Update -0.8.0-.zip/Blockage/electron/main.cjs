const { app, BrowserWindow, protocol, ipcMain, dialog, Menu, nativeTheme, net, shell } = require('electron');
const fs = require('node:fs/promises');
const path = require('node:path');
const { resolveAppPath, inspectAsset, atomicWrite, MAX_SCENE_BYTES, MAX_EMBEDDED_BYTES } = require('./files.cjs');
const { spawn }=require('node:child_process');
const { importModelFile, listModelFiles, IMPORT_EXTENSIONS, findBlender }=require('./model-import.cjs');
const { UpdateService,REPOSITORY }=require('./updates.cjs');
const {recoverInterrupted}=require('./update-apply.cjs');
const { Preferences }=require('./preferences.cjs');
const {PayloadTransfers}=require('./payload-transfer.cjs');
const {AssetStore}=require('./asset-store.cjs');
const {Converter}=require('./converter.cjs');
const transfers=new PayloadTransfers(),limits=require('../src/engine/asset-limits.json');
const currentVersion=require('../package.json').version;
const explicitProfile=process.argv.find(a=>a.startsWith('--user-data-dir='));if(explicitProfile)app.setPath('userData',explicitProfile.slice(16));
let preferences,updater,assetStore,converter;
const root = path.resolve(__dirname, '..');
const vulkanRequested = process.argv.includes('--blockage-vulkan');
const compatibility = process.argv.includes('--blockage-webgl');
const player = process.argv.includes('--blockage-player');

// Secure standard origin is necessary for WebGPU and ES modules. No HTTP server or open port in the desktop app.
protocol.registerSchemesAsPrivileged([{ scheme: 'blockage', privileges: { standard: true, secure: true, supportFetchAPI: true, corsEnabled: true, stream: true } }]);
app.setName('Blockage');
const primaryInstance=app.requestSingleInstanceLock();
if(!primaryInstance)app.quit();
else app.on('second-instance',()=>{if(window){if(window.isMinimized())window.restore();window.show();window.focus();}});
if (vulkanRequested && process.platform !== 'darwin') {
  app.commandLine.appendSwitch('enable-features', 'Vulkan');
  app.commandLine.appendSwitch('use-angle', 'vulkan');
  // Requests Chromium's Vulkan graphics path. On Windows WebGPU may still use D3D12; diagnostics never label a request as proof.
}
nativeTheme.themeSource = 'dark';
let window, scenePath = null, dirty = false;
let validate;
async function validatedPrefab(text){
  if(typeof text!=='string'||Buffer.byteLength(text)>MAX_SCENE_BYTES)throw new Error(`Prefab exceeds ${MAX_SCENE_BYTES/1048576} MiB.`);
  const data=JSON.parse(text),{instantiatePrefab}=await import('../src/engine/prefab.js'),{createDocument}=await import('../src/engine/document.js');instantiatePrefab(createDocument(),data);return data;
}
const recoveryPath = () => path.join(app.getPath('userData'), 'recovery.blockage');
const mime = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.wasm':'application/wasm', '.svg': 'image/svg+xml', '.png': 'image/png' };
const guarded = (handler,chunkResponse=true) => async (event, ...args) => {
  try {
    if (event.sender !== window?.webContents || !event.senderFrame?.url.startsWith('blockage://app/')) throw new Error('Untrusted sender.');
    const owner=event.sender.id;if(args.length===1&&args[0]?.__blockageArgsTransfer)args=transfers.consume(owner,args[0].__blockageArgsTransfer);const result=await handler(...args);return chunkResponse?transfers.wrap(owner,result):result;
  } catch (error) { return { ok: false, error: error.message }; }
};
async function validatedText(text) {
  if (typeof text !== 'string' || Buffer.byteLength(text, 'utf8') > MAX_SCENE_BYTES) throw new Error(`Scene exceeds ${MAX_SCENE_BYTES/1048576} MiB.`);
  validate ||= (await import('../src/engine/document.js')).validateDocument;
  const content=JSON.stringify(validate(JSON.parse(text)),null,2);if(Buffer.byteLength(content)>MAX_SCENE_BYTES)throw new Error(`Formatted scene exceeds ${MAX_SCENE_BYTES/1048576} MiB.`);return content;
}
async function readScene(filename) {
  const stat = await fs.stat(filename);
  if (!stat.isFile() || stat.size > MAX_SCENE_BYTES) throw new Error(`Scene exceeds ${MAX_SCENE_BYTES/1048576} MiB.`);
  return assetStore.restore(filename,JSON.parse(await validatedText(await fs.readFile(filename, 'utf8'))));
}
function installIPC() {
  ipcMain.handle('blockage:payload-begin',guarded(length=>transfers.begin(window.webContents.id,length),false));
  ipcMain.handle('blockage:payload-append',guarded((id,offset,text)=>transfers.append(window.webContents.id,id,offset,text),false));
  ipcMain.handle('blockage:payload-read',guarded((id,offset)=>transfers.read(window.webContents.id,id,offset),false));
  ipcMain.handle('blockage:payload-drop',guarded(id=>transfers.drop(window.webContents.id,id),false));
  ipcMain.handle('blockage:info', guarded(async () => ({ ok: true, electron: process.versions.electron, node: process.versions.node, chrome: process.versions.chrome, platform: process.platform, packaged:app.isPackaged, vulkanRequested, compatibility, player, version:currentVersion,repository:REPOSITORY,limits,preferences:preferences.value, graphics: app.getGPUFeatureStatus(), gpu: await app.getGPUInfo('complete').catch(() => ({})) })));
  ipcMain.handle('blockage:open', guarded(async () => {
    const picked = await dialog.showOpenDialog(window, { title: 'Open Blockage Scene', properties: ['openFile'], filters: [{ name: 'Blockage Scene', extensions: ['blockage', 'json'] }] });
    if (picked.canceled) return { ok: true, canceled: true };
    const scene = await readScene(picked.filePaths[0]); scenePath = picked.filePaths[0];
    return { ok: true, scene, name: path.basename(scenePath), path: scenePath };
  }));
  ipcMain.handle('blockage:save', guarded(async (text, saveAs) => {
    const content = await validatedText(text);
    let filename = scenePath;
    if (!filename || saveAs) {
      const result = await dialog.showSaveDialog(window, { title: 'Save Blockage Scene', defaultPath: filename || 'MyWorld.blockage', filters: [{ name: 'Blockage Scene', extensions: ['blockage'] }] });
      if (result.canceled) return { ok: true, canceled: true };
      filename = result.filePath;
    }
    await assetStore.save(filename,JSON.parse(content),content); scenePath = filename; dirty = false; window.setDocumentEdited(false);
    await fs.rm(recoveryPath(), { force: true }).catch(() => {});
    return { ok: true, name: path.basename(filename), path: filename };
  }));
  ipcMain.handle('blockage:import',guarded(async folder=>{
    if(typeof folder!=='boolean')throw new Error('Invalid import mode.');
    const selected=await dialog.showOpenDialog(window,{title:folder?'Import Model Folder (1 GiB per model)':'Import Assets (1 GiB per model)',properties:folder?['openDirectory']:['openFile','multiSelections'],filters:folder?[]:[{name:'Models, Textures & Audio',extensions:IMPORT_EXTENSIONS}]});if(selected.canceled)return{ok:true,canceled:true};
    const files=folder?await listModelFiles(selected.filePaths[0]):selected.filePaths;if(files.length>100)throw new Error('Import up to 100 assets at once.');const assets=[];let bytes=0;
    for(let index=0;index<files.length;index++){const filename=files[index];window.webContents.send('blockage:import-progress',{name:path.basename(filename),index:index+1,total:files.length});const asset=await importModelFile(filename,{assetStore,converter,root,resourceRoot:folder?selected.filePaths[0]:undefined});bytes+=asset.bytes;if(bytes>limits.projectBytes)throw new Error(`Import batch exceeds ${limits.projectBytes/1073741824} GiB.`);assets.push(asset);}return{ok:true,assets};
  }));
  ipcMain.handle('blockage:preferences',guarded(async()=>({ok:true,preferences:preferences.value,repository:REPOSITORY})));
  ipcMain.handle('blockage:preferences-save',guarded(async input=>{const value=await preferences.save(input);updater.available=null;return{ok:true,preferences:value};}));
    ipcMain.handle('blockage:update-check',guarded(async()=>updater.check()));
  ipcMain.handle('blockage:update-install',guarded(async()=>updater.install()));
  ipcMain.handle('blockage:update-local',guarded(async()=>{
    const choice=await dialog.showOpenDialog(window,{title:'Install a trusted Blockage update ZIP',properties:['openFile'],filters:[{name:'Blockage Update ZIP',extensions:['zip']}]});
    if(choice.canceled)return{ok:true,canceled:true};
    const answer=await dialog.showMessageBox(window,{type:'warning',title:'Trust this update?',message:'An engine update installs executable code.',detail:'Choose only a ZIP from your own build or the official Blockage repository. File checksums detect corruption, not the identity of a local ZIP author. Your running installation is not replaced until you choose Save & Restart.',buttons:['Cancel','Verify and prepare ZIP'],defaultId:0,cancelId:0});
    if(answer.response!==1)return{ok:true,canceled:true};
    return updater.installLocal(choice.filePaths[0]);
  }));
  ipcMain.handle('blockage:update-open',guarded(async()=>{if(!updater.ready)throw new Error('Install an update first.');const error=await shell.openPath(updater.ready.path);if(error)throw new Error(error);return{ok:true};}));
  ipcMain.handle('blockage:update-restart',guarded(async()=>{
    if(process.platform!=='win32'||!updater.ready)throw new Error('No Windows update is ready.');if(dirty)throw new Error('Save your scene before restarting.');
    const flags=[];if(compatibility)flags.push('--blockage-webgl');if(vulkanRequested)flags.push('--blockage-vulkan');if(player)flags.push('--blockage-player');
    const portableNode=app.isPackaged?path.join(process.resourcesPath,'updater','node.exe'):undefined;
    const relaunch=app.isPackaged?{mode:'packaged',executable:process.execPath}:undefined;
    const plan=await updater.prepareRestart(process.pid,flags,portableNode,relaunch),child=spawn(plan.executable,plan.args,{cwd:plan.directory,env:plan.env,detached:true,stdio:'ignore',windowsHide:true,shell:false});
    await new Promise((resolve,reject)=>{child.once('spawn',resolve);child.once('error',reject);});child.unref();setTimeout(()=>app.quit(),250);return{ok:true};
  }));
  ipcMain.handle('blockage:export-game',guarded(async (text,encoded)=>{if(process.platform!=='win32'||process.arch!=='x64')throw Error('Build the Windows x64 game from Blockage on Windows x64.');const scene=JSON.parse(await validatedText(text)),units=JSON.parse(encoded);const selected=await dialog.showOpenDialog(window,{title:'Choose parent folder for the Windows game',properties:['openDirectory','createDirectory']});if(selected.canceled)return {ok:true,canceled:true};return require('./export-game.cjs').exportGame({root,scene,units,assetStore,runtimeExe:process.execPath,parent:selected.filePaths[0]});}));
  ipcMain.handle('blockage:prefab-save',guarded(async(text,name)=>{
    const prefab=await validatedPrefab(text),filename=String(name||'Object').replace(/[^a-zA-Z0-9_-]/g,'_').slice(0,100)+'.blockageprefab';
    const selected=await dialog.showSaveDialog(window,{title:'Export Prefab',defaultPath:filename,filters:[{name:'Blockage Prefab',extensions:['blockageprefab']}]});if(selected.canceled)return{ok:true,canceled:true};const content=JSON.stringify(prefab,null,2);if(Buffer.byteLength(content)>MAX_SCENE_BYTES)throw new Error(`Formatted prefab exceeds ${MAX_SCENE_BYTES/1048576} MiB.`);await assetStore.save(selected.filePath,prefab.scene,content);return{ok:true,name:path.basename(selected.filePath)};
  }));
  ipcMain.handle('blockage:prefab-open',guarded(async()=>{
    const picked=await dialog.showOpenDialog(window,{title:'Import Prefab',properties:['openFile'],filters:[{name:'Blockage Prefab',extensions:['blockageprefab','json']}]});if(picked.canceled)return{ok:true,canceled:true};const stat=await fs.stat(picked.filePaths[0]);if(stat.size>MAX_SCENE_BYTES)throw new Error(`Prefab exceeds ${MAX_SCENE_BYTES/1048576} MiB.`);const prefab=await validatedPrefab(await fs.readFile(picked.filePaths[0],'utf8'));await assetStore.restore(picked.filePaths[0],prefab.scene);return{ok:true,prefab};
  }));
  ipcMain.handle('blockage:autosave', guarded(async text => { await atomicWrite(recoveryPath(), await validatedText(text)); return { ok: true }; }));
  ipcMain.handle('blockage:recover', guarded(async () => { try { return { ok: true, scene: await readScene(recoveryPath()) }; } catch { return { ok: true, scene: null }; } }));
  ipcMain.handle('blockage:clear-recovery', guarded(async () => { await fs.rm(recoveryPath(), { force: true }); return { ok: true }; }));
  ipcMain.handle('blockage:reset-path', guarded(async () => { scenePath = null; return { ok: true }; }));
  ipcMain.handle('blockage:close-recovery', guarded(async text => { await atomicWrite(recoveryPath(), await validatedText(text)); dirty = false; window.close(); return { ok: true }; }));
  ipcMain.on('blockage:dirty', (event, value) => { if (event.sender === window?.webContents) { dirty = Boolean(value); window.setDocumentEdited(dirty); } });
  ipcMain.on('blockage:window', (event, action) => {
    if (event.sender !== window?.webContents) return;
    if (action === 'minimize') window.minimize();
    if (action === 'maximize') window.isMaximized() ? window.unmaximize() : window.maximize();
    if (action === 'close') window.close();
    if (action === 'devtools') window.webContents.toggleDevTools();
  });
}
function createWindow() {
  window = new BrowserWindow({ title: 'Blockage', width: 1600, height: 1000, minWidth: 1100, minHeight: 720, backgroundColor: '#171b22', frame: process.platform === 'darwin', titleBarStyle: process.platform === 'darwin' ? 'hiddenInset' : 'default', icon: path.join(root, 'assets', 'icon.png'), autoHideMenuBar: true, show: false,
    webPreferences: { preload: path.join(__dirname, 'preload.cjs'), contextIsolation: true, nodeIntegration: false, sandbox: true, webSecurity: true, spellcheck: false, backgroundThrottling: false } });
  window.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  window.webContents.on('will-navigate', event => event.preventDefault());
  window.webContents.session.setPermissionRequestHandler((_contents, _permission, callback) => callback(false));
  const owner=window.webContents.id;window.on('closed',()=>transfers.clearOwner(owner));
  window.once('ready-to-show', () => window.show());
  window.on('close', event => {
    if (!dirty) return;
    const answer = dialog.showMessageBoxSync(window, { type: 'question', title: 'Unsaved Scene', message: 'Keep your unsaved scene?', detail: 'A recovery copy will be offered when you reopen Blockage. Choose Cancel to save your scene first.', buttons: ['Keep recovery & close', 'Cancel'], defaultId: 1, cancelId: 1 });
    event.preventDefault();
    if (answer === 0) window.webContents.send('blockage:menu', 'closeWithRecovery');
  });
  window.loadURL(`blockage://app/src/index.html${player ? '?player=1' : ''}`);
  const send = action => () => window.webContents.send('blockage:menu', action);
  const template = [
    { label: 'File', submenu: [{ label: 'New Scene', accelerator: 'CmdOrCtrl+N', click: send('new') }, { label: 'Open Scene…', accelerator: 'CmdOrCtrl+O', click: send('open') }, { type: 'separator' }, { label: 'Save', accelerator: 'CmdOrCtrl+S', click: send('save') }, { label: 'Save As…', accelerator: 'CmdOrCtrl+Shift+S', click: send('saveAs') }, { label:'Import Model Folder…',click:send('importFolder') }, { label: 'Import Assets…', accelerator: 'CmdOrCtrl+I', click: send('import') }, { type: 'separator' }, { role: 'quit' }] },
    { label: 'Edit', submenu: [{ label: 'Undo', accelerator: 'CmdOrCtrl+Z', click: send('undo') }, { label: 'Redo', accelerator: 'CmdOrCtrl+Shift+Z', click: send('redo') }, { label: 'Duplicate', accelerator: 'CmdOrCtrl+D', click: send('duplicate') }, { label: 'Delete', accelerator: 'Delete', click: send('delete') },{type:'separator'},{label:'Preferences…',click:send('preferences')}] },
    { label: 'View', submenu: [{ label: 'Focus Selected', accelerator: 'F', click: send('focus') }, { label: 'Toggle Grid', click: send('grid') }, { label: 'Fullscreen', accelerator: 'F11', role: 'togglefullscreen' }, { label: 'Developer Tools', accelerator: 'CmdOrCtrl+Shift+I', click: () => window.webContents.toggleDevTools() }] },
    { label: 'Help', submenu: [{label:'Check for Updates…',click:send('updates')},{label:'Install Update ZIP…',click:send('updateZip')},{ label: 'Controls & About', click: send('help') }] }
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}
app.whenReady().then(async () => {
  if(!primaryInstance)return;
  if(await recoverInterrupted(root)){app.relaunch();app.exit(0);return;}
  await fs.mkdir(app.getPath('userData'),{recursive:true});assetStore=new AssetStore(path.join(app.getPath('userData'),'model-assets'));converter=new Converter({directory:app.getPath('userData'),root,fetchImpl:(url,options)=>net.fetch(url,options),onProgress:progress=>window?.webContents.send('blockage:import-progress',progress)});preferences=new Preferences(app.getPath('userData'));await preferences.load();updater=new UpdateService({fetchImpl:(url,options)=>net.fetch(url,options),directory:app.getPath('userData'),installationRoot:root,currentVersion,packaged:app.isPackaged,onProgress:progress=>window?.webContents.send('blockage:update-progress',progress)});
  protocol.handle('blockage', async request => {
    try { if(new URL(request.url).pathname.startsWith('/model-assets/'))return await assetStore.response(request);const filename = resolveAppPath(root, request.url); return new Response(await fs.readFile(filename), { headers: { 'content-type': mime[path.extname(filename)] || 'application/octet-stream' } }); }
    catch { return new Response('Not found', { status: 404 }); }
  });
  installIPC(); createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
}).catch(error => { console.error(error); app.quit(); });
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
