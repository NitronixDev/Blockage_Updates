import fs from 'node:fs/promises';
import path from 'node:path';
import { createRequire } from 'node:module';
import { writeZip } from './zip-writer.mjs';
const require=createRequire(import.meta.url),{DIRECTORIES,ROOT_FILES,REPOSITORY,version,updateName,hashFile,listFiles,validatePatch}=require('../electron/update-manifest.cjs');
const args=process.argv.slice(2),option=(key,fallback)=>{const index=args.indexOf(key);if(index<0)return fallback;if(!args[index+1])throw new Error('Missing '+key+' value.');return args[index+1];};
const root=path.resolve(option('--root',path.resolve(import.meta.dirname,'..'))),baseValue=option('--base',null),base=baseValue?path.resolve(baseValue):null,output=path.resolve(option('--output',path.join(root,'release')));
const pkg=JSON.parse(await fs.readFile(path.join(root,'package.json'),'utf8')),previous=base?JSON.parse(await fs.readFile(path.join(base,'package.json'),'utf8')):null;
const minVersion=option('--min-version',previous?.version||'0.4.0');version(pkg.version);version(minVersion);
if(output===root||root.startsWith(output+path.sep))throw new Error('Choose a separate update output directory.');
const components=[];
async function signature(directory){const entries=await listFiles(directory);return Promise.all(entries.map(async name=>[name,await hashFile(path.join(directory,...name.split('/')))]));}
for(const name of [...DIRECTORIES.filter(n=>!['runtime','node_modules'].includes(n)),...ROOT_FILES]) {
  const current=path.join(root,name),stat=await fs.lstat(current).catch(()=>null);if(!stat)continue;if(stat.isSymbolicLink())throw new Error('Update source may not contain symlinks.');
  const old=base?path.join(base,name):null,oldStat=old?await fs.lstat(old).catch(()=>null):null;
  const changed=!oldStat||(stat.isDirectory()?JSON.stringify(await signature(current))!==JSON.stringify(await signature(old)):await hashFile(current)!==await hashFile(old));
  if(changed||name==='package.json')components.push(name);
}
for(const [name,flag] of [['runtime','--include-runtime'],['node_modules','--include-dependencies']]) {
  const changed=name==='runtime'?previous&&JSON.stringify(previous.engines)!==JSON.stringify(pkg.engines):previous&&(JSON.stringify(previous.dependencies)!==JSON.stringify(pkg.dependencies)||JSON.stringify(previous.devDependencies)!==JSON.stringify(pkg.devDependencies));
  if(changed||args.includes(flag)){if(!(await fs.stat(path.join(root,name)).catch(()=>null))?.isDirectory())throw new Error('This update needs '+name+'. Prepare the Windows runtime/dependencies first.');components.push(name);}
}
await fs.mkdir(output,{recursive:true});const stage=await fs.mkdtemp(path.join(output,'patch-'));
try {
  for(const component of components)await fs.cp(path.join(root,component),path.join(stage,component),{recursive:true,dereference:false});
  const names=await listFiles(stage),files=[];
  for(const name of names){const filename=path.join(stage,...name.split('/'));files.push({path:name,bytes:(await fs.stat(filename)).size,sha256:await hashFile(filename)});}
  const manifest={format:'blockage.update',schema:1,repository:REPOSITORY,version:pkg.version,minVersion,components,files};
  await fs.writeFile(path.join(stage,'update.json'),JSON.stringify(manifest,null,2)+'\n');await validatePatch(stage,{expectedVersion:pkg.version,currentVersion:minVersion});
  const result=await writeZip(stage,[...names,'update.json'].sort(),path.join(output,updateName(pkg.version)));
  const sumsFile=path.join(output,'SHA256SUMS.json'),sums=JSON.parse(await fs.readFile(sumsFile,'utf8').catch(()=>'{}'));sums[updateName(pkg.version)]=result.sha256;await fs.writeFile(sumsFile,JSON.stringify(sums,null,2)+'\n');console.log(JSON.stringify({...result,components,minVersion}));
}finally{await fs.rm(stage,{recursive:true,force:true});}
