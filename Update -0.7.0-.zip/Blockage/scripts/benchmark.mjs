import { performance } from 'node:perf_hooks';
import { pathToFileURL } from 'node:url';
import path from 'node:path';
const args=process.argv.slice(2),index=args.indexOf('--baseline'),roots=[...(index<0?[]:[path.resolve(args[index+1])]),path.resolve(import.meta.dirname,'..')];
for(const root of roots){
  const {RigidWorld}=await import(pathToFileURL(path.join(root,'src/engine/rigid-world.js')));
  const staticBodies=Array.from({length:1600},(_,i)=>({id:'wall'+i,type:'box',position:[i%40*4,0,Math.floor(i/40)*4],half:[.5,.5,.5],velocity:[0,0,0],invMass:0,restitution:0,friction:.5}));
  const dynamic=Array.from({length:64},(_,i)=>({id:'body'+i,type:'sphere',position:[i%8*4,2+Math.floor(i/8),Math.floor(i/8)*4],half:[.3,.3,.3],velocity:[0,0,0],invMass:1,restitution:.2,friction:.5,damping:.03,floor:0}));
  const world=new RigidWorld([...staticBodies,...dynamic]);for(let i=0;i<10;i++)world.step(1/60);
  const samples=[];for(let i=0;i<80;i++){const start=performance.now();world.step(1/60);samples.push(performance.now()-start);}samples.sort((a,b)=>a-b);
  console.log(JSON.stringify({root,staticBodies:staticBodies.length,dynamicBodies:dynamic.length,medianStepMs:samples[Math.floor(samples.length/2)],p95StepMs:samples[Math.floor(samples.length*.95)],candidateChecks:world.candidateChecks??null}));
}
