"""Bake constant-topology Alembic meshes into portable morph and transform keys."""
from array import array
import bpy

def bake_alembic():
    scene = bpy.context.scene
    first, last = scene.frame_start, scene.frame_end
    frames = last - first + 1
    meshes = [obj for obj in scene.objects if obj.type == 'MESH']
    if frames > 600 or sum(len(obj.data.vertices) for obj in meshes) * frames > 32000000:
        raise RuntimeError('Alembic baking exceeds 600 frames / 32 million vertex samples. Split the cache into smaller clips.')
    baked_objects = []
    samples = 0
    for source in meshes:
        scene.frame_set(first)
        graph = bpy.context.evaluated_depsgraph_get()
        evaluated = source.evaluated_get(graph)
        data = bpy.data.meshes.new_from_object(evaluated, preserve_all_data_layers=True, depsgraph=graph)
        baked = bpy.data.objects.new(source.name + '_Cache', data)
        scene.collection.objects.link(baked)
        baked.rotation_mode = 'QUATERNION'
        baked.shape_key_add(name='Basis')
        count = len(data.vertices)
        samples += count * frames
        if samples > 32000000:
            raise RuntimeError('Alembic baking exceeds 32 million evaluated vertex samples. Split the cache into smaller clips.')
        base = array('f', [0]) * (count * 3)
        data.vertices.foreach_get('co', base)
        indices = array('I', [0]) * len(data.loops)
        data.loops.foreach_get('vertex_index', indices)
        polygons = array('I', [0]) * len(data.polygons)
        data.polygons.foreach_get('loop_total', polygons)
        for frame in range(first, last + 1):
            scene.frame_set(frame)
            graph = bpy.context.evaluated_depsgraph_get()
            evaluated = source.evaluated_get(graph)
            mesh = evaluated.to_mesh()
            try:
                check = array('I', [0]) * len(mesh.loops)
                mesh.loops.foreach_get('vertex_index', check)
                faces = array('I', [0]) * len(mesh.polygons)
                mesh.polygons.foreach_get('loop_total', faces)
                if len(mesh.vertices) != count or check != indices or faces != polygons:
                    raise RuntimeError('Alembic topology changes cannot be represented by morph targets. Export a constant-topology cache.')
                values = array('f', [0]) * (count * 3)
                mesh.vertices.foreach_get('co', values)
                if values != base:
                    key = baked.shape_key_add(name='Frame_' + str(frame), from_mix=False)
                    key.data.foreach_set('co', values)
                    key.value = 0
                    key.keyframe_insert('value', frame=frame - 1)
                    key.value = 1
                    key.keyframe_insert('value', frame=frame)
                    key.value = 0
                    key.keyframe_insert('value', frame=frame + 1)
                location, rotation, scale = evaluated.matrix_world.decompose()
                baked.location, baked.rotation_quaternion, baked.scale = location, rotation, scale
                for field in ('location', 'rotation_quaternion', 'scale'):
                    baked.keyframe_insert(field, frame=frame)
            finally:
                evaluated.to_mesh_clear()
        baked_objects.append(baked)
    for obj in list(scene.objects):
        if obj not in baked_objects:
            bpy.data.objects.remove(obj, do_unlink=True)
    scene.frame_set(first)
