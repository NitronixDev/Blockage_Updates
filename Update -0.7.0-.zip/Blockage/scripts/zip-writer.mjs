import fs from 'node:fs/promises';
import { createReadStream } from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { Transform, Writable } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { createDeflateRaw } from 'node:zlib';
import { createRequire } from 'node:module';
const require=createRequire(import.meta.url),{crc32}=require('../electron/zip-reader.cjs');
export async function writeZip(root,files,archive,prefix='Blockage/') {
  if(files.length>10000)throw new Error('ZIP contains too many files.');
  const temporary=archive+'.'+crypto.randomUUID()+'.tmp',file=await fs.open(temporary,'wx');let offset=0;const central=[];
  async function write(buffer){let done=0;while(done<buffer.length){const result=await file.write(buffer,done,buffer.length-done,null);if(!result.bytesWritten)throw new Error('ZIP write stopped.');done+=result.bytesWritten;}offset+=buffer.length;if(offset>0xffffffff)throw new Error('Archive exceeds ZIP32.');}
  try {
    for(const relative of files){
      const source=path.join(root,...relative.split('/')),filename=Buffer.from(prefix+relative),start=offset,header=Buffer.alloc(30);
      header.writeUInt32LE(0x04034b50,0);header.writeUInt16LE(20,4);header.writeUInt16LE(0x0808,6);header.writeUInt16LE(8,8);header.writeUInt16LE(33,12);header.writeUInt16LE(filename.length,26);await write(header);await write(filename);let bytes=0,compressed=0,crc=0;
      const tracker=new Transform({transform(chunk,_encoding,callback){bytes+=chunk.length;crc=crc32(chunk,crc);callback(null,chunk);}}),sink=new Writable({write(chunk,_encoding,callback){compressed+=chunk.length;write(chunk).then(()=>callback(),callback);}});
      await pipeline(createReadStream(source),tracker,createDeflateRaw({level:6}),sink);
      const descriptor=Buffer.alloc(16);descriptor.writeUInt32LE(0x08074b50,0);descriptor.writeUInt32LE(crc,4);descriptor.writeUInt32LE(compressed,8);descriptor.writeUInt32LE(bytes,12);await write(descriptor);
      const record=Buffer.alloc(46);record.writeUInt32LE(0x02014b50,0);record.writeUInt16LE(20,4);record.writeUInt16LE(20,6);record.writeUInt16LE(0x0808,8);record.writeUInt16LE(8,10);record.writeUInt16LE(33,14);record.writeUInt32LE(crc,16);record.writeUInt32LE(compressed,20);record.writeUInt32LE(bytes,24);record.writeUInt16LE(filename.length,28);record.writeUInt32LE(start,42);central.push(record,filename);
    }
    const centralStart=offset;for(const buffer of central)await write(buffer);
    const end=Buffer.alloc(22);end.writeUInt32LE(0x06054b50,0);end.writeUInt16LE(files.length,8);end.writeUInt16LE(files.length,10);end.writeUInt32LE(offset-centralStart,12);end.writeUInt32LE(centralStart,16);await write(end);await file.close();await fs.rename(temporary,archive);
  }catch(error){await file.close().catch(()=>{});await fs.unlink(temporary).catch(()=>{});throw error;}
  const hash=crypto.createHash('sha256');for await(const chunk of createReadStream(archive))hash.update(chunk);
  return {archive,bytes:offset,files:files.length,sha256:hash.digest('hex')};
}
