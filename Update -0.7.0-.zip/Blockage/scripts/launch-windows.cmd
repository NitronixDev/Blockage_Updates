@echo off
setlocal
cd /d "%~dp0.."
if not exist "package.json" goto incomplete
if not exist "package-lock.json" goto incomplete
if not exist "electron\main.cjs" goto incomplete
if not exist "src\index.html" goto incomplete
if not exist "%~dp0verify-install.cjs" goto incomplete
if not exist "%~dp0install-windows.ps1" goto incomplete
if not exist "%~dp0windows-runtime.json" goto incomplete
if "%~1"=="repair" goto repair
if not exist "runtime\node\node.exe" goto setup
if not exist "runtime\node\node_modules\npm\bin\npm-cli.js" goto setup
"%~dp0..\runtime\node\node.exe" "%~dp0verify-install.cjs" --quiet
if not errorlevel 1 goto ready
:setup
echo Installation automatique des composants manquants...
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-windows.ps1"
if errorlevel 1 goto failed
goto ready
:repair
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-windows.ps1" -Repair
if errorlevel 1 goto failed
exit /b 0
:ready
if "%~1"=="setup" exit /b 0
set "PATH=%~dp0..\runtime\node;%PATH%"
set "ELECTRON_RUN_AS_NODE="
set "BLOCKAGE_FLAGS="
if "%~1"=="compat" set "BLOCKAGE_FLAGS=--blockage-webgl"
if "%~1"=="vulkan" set "BLOCKAGE_FLAGS=--blockage-vulkan"
if "%~1"=="player" set "BLOCKAGE_FLAGS=--blockage-player"
"%~dp0..\node_modules\electron\dist\electron.exe" . %BLOCKAGE_FLAGS%
if errorlevel 1 goto launchfailed
exit /b 0
:incomplete
echo Archive incomplete. Extrais tout le ZIP Blockage dans un dossier avant de le lancer.
pause
exit /b 1
:failed
echo.
echo Installation interrompue. Relance ce fichier pour reessayer.
echo Details : blockage-install.log dans le dossier Blockage.
pause
exit /b 1
:launchfailed
echo.
echo Blockage ne peut pas demarrer. Essaie START_BLOCKAGE_COMPAT.bat.
echo Pour reparer les composants : scripts\INSTALL_DEPENDENCIES.bat.
pause
exit /b 1
