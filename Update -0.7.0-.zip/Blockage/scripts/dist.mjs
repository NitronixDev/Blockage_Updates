import fs from 'node:fs/promises';
import { createReadStream, rmSync } from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawn } from 'node:child_process';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
import { unzipSync } from 'three/addons/libs/fflate.module.js';
const require = createRequire(import.meta.url), { distributionConfig } = require('./electron-builder.cjs');
const root = path.resolve(import.meta.dirname, '..');

export function distributionOptions(args, host = process.platform) {
  if (args.some(a => !['--dir', '--win', '--linux'].includes(a)) || args.includes('--win') && args.includes('--linux')) throw new Error('Options: --dir, --win or --linux. Publishing is not enabled.');
  const platform = args.includes('--win') ? 'win32' : args.includes('--linux') ? 'linux' : host;
  if (!['win32', 'linux'].includes(platform)) throw new Error('This distribution supports Windows x64 and Linux x64. Build Windows on Windows for the installer.');
  return { platform, directoryOnly: args.includes('--dir') };
}

async function runNode(script, args, cwd) {
  const env = { ...process.env, PATH: path.dirname(process.execPath) + path.delimiter + (process.env.PATH || '') };
  const child = spawn(process.execPath, [script, ...args], { cwd, env, stdio: 'inherit', shell: false });
  await new Promise((resolve, reject) => { child.once('error', reject); child.once('exit', code => code === 0 ? resolve() : reject(new Error('Build prerequisite failed with exit code ' + code))); });
}

async function npmCLI() {
  const candidates = [process.env.npm_execpath, path.join(path.dirname(process.execPath), 'node_modules/npm/bin/npm-cli.js'), path.resolve(path.dirname(process.execPath), '../lib/node_modules/npm/bin/npm-cli.js')].filter(Boolean);
  for (const candidate of candidates) if (path.isAbsolute(candidate) && (await fs.stat(candidate).catch(() => null))?.isFile()) return candidate;
  throw new Error('Run this command through npm run dist, with Node.js and npm installed.');
}

async function buildTools(cache) {
  const source = path.join(root, 'scripts/build-tools'), lock = await fs.readFile(path.join(source, 'package-lock.json'));
  const digest = crypto.createHash('sha256').update(lock).digest('hex').slice(0, 20), directory = path.join(cache, 'tools-' + digest);
  const metadata = JSON.parse(await fs.readFile(path.join(source, 'package.json'), 'utf8'));
  const marker = path.join(directory, 'complete.json'), current = JSON.parse(await fs.readFile(marker, 'utf8').catch(() => 'null'));
  if (!current || current.digest !== digest || !(await fs.stat(path.join(directory, 'node_modules/electron-builder/out/index.js')).catch(() => null))) {
    await fs.mkdir(directory, { recursive: true });
    await fs.copyFile(path.join(source, 'package.json'), path.join(directory, 'package.json'));
    await fs.copyFile(path.join(source, 'package-lock.json'), path.join(directory, 'package-lock.json'));
    console.log('Installing pinned build tools (separate from engine dependencies)…');
    await runNode(await npmCLI(), ['ci', '--prefix', directory, '--ignore-scripts', '--no-audit', '--no-fund', '--registry=https://registry.npmjs.org'], root);
    const installed = JSON.parse(await fs.readFile(path.join(directory, 'node_modules/electron-builder/package.json'), 'utf8'));
    if (installed.version !== metadata.dependencies['electron-builder']) throw new Error('Unexpected electron-builder version.');
    await fs.writeFile(marker, JSON.stringify({ digest, version: installed.version }));
  }
  return createRequire(path.join(directory, 'package.json'))('electron-builder');
}

async function hashFile(file) {
  const hash = crypto.createHash('sha256'); for await (const chunk of createReadStream(file)) hash.update(chunk); return hash.digest('hex');
}

async function updaterRuntime(cache, platform) {
  const directory = path.join(cache, 'updater-' + platform + '-x64'); await fs.mkdir(directory, { recursive: true });
  const destination = path.join(directory, platform === 'win32' ? 'node.exe' : 'node');
  if (platform === process.platform && process.arch === 'x64') {
    if (process.versions.electron) throw new Error('Build with standalone Node.js, not Electron.');
    const bin = path.dirname(process.execPath);
    for (const license of [path.join(bin, 'LICENSE'), path.resolve(bin, '../LICENSE'), ...(platform === 'linux' ? ['/usr/share/doc/nodejs/copyright'] : [])]) {
      if (!(await fs.stat(license).catch(() => null))?.isFile()) continue;
      await fs.copyFile(license, path.join(directory, 'LICENSE.node.txt'));
      await fs.copyFile(process.execPath, destination); if (platform !== 'win32') await fs.chmod(destination, 0o755); return directory;
    }
    if (platform !== 'win32') throw new Error('Use an official Node.js x64 distribution with its LICENSE file.');
  }
  if (platform !== 'win32') throw new Error('Build the Linux distribution on Linux x64.');
  // Cross-packaging Windows: only the official pinned standalone Node executable.
  const spec = JSON.parse(await fs.readFile(path.join(root, 'scripts/windows-runtime.json'), 'utf8'));
  const archive = path.join(cache, spec.archive);
  if (await hashFile(archive).catch(() => '') !== spec.sha256) {
    console.log('Downloading the verified Windows updater runtime…');
    const response = await fetch(spec.url, { signal: AbortSignal.timeout(300000) });
    if (!response.ok) throw new Error('Node runtime download failed: ' + response.status);
    const temporary = archive + '.' + crypto.randomUUID() + '.tmp', handle = await fs.open(temporary, 'wx'); let bytes = 0;
    try { for await (const chunk of response.body) { bytes += chunk.length; if (bytes > 100 * 1048576) throw new Error('Node runtime archive too large.'); await handle.writeFile(chunk); } }
    catch (error) { await handle.close(); await fs.unlink(temporary).catch(() => {}); throw error; }
    await handle.close();
    if (await hashFile(temporary) !== spec.sha256) { await fs.unlink(temporary); throw new Error('Node runtime SHA-256 mismatch.'); }
    await fs.rename(temporary, archive);
  }
  const base = `node-v${spec.version}-win-x64/`, entry = base + 'node.exe', license = base + 'LICENSE';
  const files = unzipSync(new Uint8Array(await fs.readFile(archive)), { filter: file => file.name === entry || file.name === license });
  if (!files[license]?.length || !files[entry] || files[entry][0] !== 77 || files[entry][1] !== 90) throw new Error('Missing Windows Node executable or notices.');
  await fs.writeFile(path.join(directory, 'LICENSE.node.txt'), files[license]); await fs.writeFile(destination, files[entry]); return directory;
}

async function prepareApp(directory, pkg) {
  for (const component of ['src', 'electron', 'assets']) await fs.cp(path.join(root, component), path.join(directory, component), { recursive: true, dereference: false, filter: file => file !== path.join(root, 'src/native') });
  await fs.mkdir(path.join(directory, 'scripts'), { recursive: true });
  await fs.copyFile(path.join(root, 'LICENSE'), path.join(directory, 'LICENSE'));
  for (const name of ['blender-export.py', 'blender-alembic.py']) await fs.copyFile(path.join(root, 'scripts', name), path.join(directory, 'scripts', name));
  await fs.mkdir(path.join(directory, 'node_modules'), { recursive: true });
  // Explicit production dependency, no developer cache or user projects are packaged.
  const source = await fs.realpath(path.join(root, 'node_modules/three'));
  const dependency = JSON.parse(await fs.readFile(path.join(source, 'package.json'), 'utf8'));
  if (dependency.version !== pkg.dependencies.three) throw new Error('Three.js does not match package.json. Run npm ci before building.');
  await fs.cp(source, path.join(directory, 'node_modules/three'), { recursive: true, dereference: true });
  await fs.writeFile(path.join(directory, 'package.json'), JSON.stringify(pkg, null, 2));
}

// A failed NSIS build can leave a small intermediate .exe. Only promote the
// completed target; a failed rebuild never replaces a previous working build.
export async function promoteOutput(buildDirectory, distDirectory, platform, directoryOnly, version) {
  if (!/^\d+\.\d+\.\d+$/.test(version)) throw new Error('Invalid distribution version.');
  const win = platform === 'win32', name = directoryOnly ? (win ? 'win-unpacked' : 'linux-unpacked') : win ? `Blockage-Setup-${version}-x64.exe` : `Blockage-${version}-linux-x64.zip`;
  const source = path.join(buildDirectory, name), target = path.join(distDirectory, name);
  async function markedDirectory(folder) {
    const metadata = JSON.parse(await fs.readFile(path.join(folder, 'resources/blockage-distribution.json'), 'utf8'));
    if (metadata.format !== 'blockage.distribution' || metadata.arch !== 'x64' || metadata.platform !== platform) throw new Error('Not a Blockage distribution: ' + folder);
    return metadata;
  }
  if (directoryOnly) {
    if ((await markedDirectory(source)).engineVersion !== version) throw new Error('Wrong packaged engine version.');
  } else {
    const handle = await fs.open(source, 'r'); try {
      const signature = Buffer.alloc(2); await handle.read(signature, 0, 2, 0);
      if (signature.toString() !== (win ? 'MZ' : 'PK') || (await handle.stat()).size < 1024 * 1024) throw new Error('Incomplete distribution artifact: ' + name);
    } finally { await handle.close(); }
  }
  await fs.mkdir(distDirectory, { recursive: true }); const previous = await fs.lstat(target).catch(e => { if (e.code === 'ENOENT') return null; throw e; });
  if (previous?.isSymbolicLink()) throw new Error('Refusing to replace an output symlink.');
  if (previous && directoryOnly) {
    await markedDirectory(target);
    const backup = path.join(distDirectory, '.previous-' + name + '-' + crypto.randomUUID());
    await fs.rename(target, backup);
    try { await fs.rename(source, target); } catch (error) { await fs.rename(backup, target); throw error; }
    await fs.rm(backup, { recursive: true, force: true });
  } else { if (previous && !previous.isFile()) throw new Error('Unexpected output path: ' + target); await fs.rename(source, target); }
  return target;
}

export async function main(args = process.argv.slice(2)) {
  const { platform, directoryOnly } = distributionOptions(args), pkg = JSON.parse(await fs.readFile(path.join(root, 'package.json'), 'utf8'));
  const minimum = pkg.engines.node.replace('>=', '').split('.').map(Number), actual = process.versions.node.split('.').map(Number);
  if (actual[0] < minimum[0] || actual[0] === minimum[0] && (actual[1] < minimum[1] || actual[1] === minimum[1] && actual[2] < minimum[2])) throw new Error('Build requires Node ' + pkg.engines.node + '.');
  if (process.arch !== 'x64') throw new Error('Build on a Windows/Linux x64 machine.');
  const cache = path.join(root, '.build-cache'); await fs.mkdir(cache, { recursive: true });
  const lock = path.join(cache, 'dist.lock');
  let handle;
  try { handle = await fs.open(lock, 'wx'); } catch (error) { if (error.code === 'EEXIST') throw new Error('A distribution build is active. If it was interrupted, close it and remove .build-cache/dist.lock before retrying.'); throw error; }
  let staging, outputStage;
  try {
    await handle.writeFile(JSON.stringify({ pid: process.pid, started: new Date().toISOString() }));
    const builder = await buildTools(cache), updaterDirectory = await updaterRuntime(cache, platform);
    staging = await fs.mkdtemp(path.join(cache, 'app-')); await prepareApp(staging, pkg);
    const electronDist = platform === process.platform ? await fs.realpath(path.join(root, 'node_modules/electron/dist')) : undefined;
    const config = distributionConfig({ root, appDirectory: staging, updaterDirectory, platform, pkg, electronDist });
    outputStage = await fs.mkdtemp(path.join(cache, 'output-')); config.directories.output = outputStage;
    // The cross-platform PE resource editor keeps Blockage's own icon. The pinned
    // Wine toolset is solely for creating the NSIS uninstaller on Linux hosts.
    if (platform === 'win32' && process.platform !== 'win32') { config.win.signExecutable = false; if (!directoryOnly) config.toolsets = { wine: '1.0.1' }; }
    const target = platform === 'win32' ? builder.Platform.WINDOWS : builder.Platform.LINUX;
    console.log(`Building Blockage ${pkg.version} · ${platform} x64 · ${directoryOnly ? 'unpacked' : 'distribution'}…`);
    await builder.build({ projectDir: root, config, targets: target.createTarget(directoryOnly ? 'dir' : platform === 'win32' ? 'nsis' : 'zip', builder.Arch.x64), publish: 'never' });
    const result = await promoteOutput(outputStage, path.join(root, 'dist'), platform, directoryOnly, pkg.version);
    console.log('Build complete: ' + result);
  } finally {
    try { if (staging) rmSync(staging, { recursive: true, force: true }); if (outputStage) rmSync(outputStage, { recursive: true, force: true }); }
    finally { await handle.close(); await fs.unlink(lock); }
  }
}
if (path.resolve(process.argv[1] || '') === fileURLToPath(import.meta.url)) await main().catch(error => { console.error('Distribution failed: ' + error.message); process.exit(1); });
