import fs from 'node:fs/promises';
import path from 'node:path';
import { createRequire } from 'node:module';
import { writeZip } from './zip-writer.mjs';
const require = createRequire(import.meta.url);
const { ROOT_FILES, hashFile } = require('../electron/update-manifest.cjs');
const root = path.resolve(import.meta.dirname, '..'), args = process.argv.slice(2);
const outputIndex = args.indexOf('--output');
if (outputIndex >= 0 && !args[outputIndex + 1]) throw new Error('Missing output directory.');
const output = path.resolve(outputIndex >= 0 ? args[outputIndex + 1] : path.join(root, 'release'));
if (output === root || root.startsWith(output + path.sep)) throw new Error('Choose a separate output directory.');
const pkg = JSON.parse(await fs.readFile(path.join(root, 'package.json'), 'utf8'));
const sums = JSON.parse(await fs.readFile(path.join(root, 'SHA256SUMS.json'), 'utf8'));
const files = [], directories = ['src', 'electron', 'scripts', 'assets', 'docs', 'tests', 'examples', '.github'];
async function walk(relative) {
  for (const entry of await fs.readdir(path.join(root, relative), { withFileTypes: true })) {
    const name = relative + '/' + entry.name;
    if (entry.isDirectory()) await walk(name);
    else if (entry.isFile()) files.push(name);
    else throw new Error('Source archives may not include links: ' + name);
  }
}
for (const directory of directories) if (await fs.stat(path.join(root, directory)).catch(() => null)) await walk(directory);
for (const name of [...ROOT_FILES, 'SHA256SUMS.json']) if ((await fs.lstat(path.join(root, name)).catch(() => null))?.isFile()) files.push(name);
for (const entry of await fs.readdir(root, { withFileTypes: true })) if (entry.isFile() && /^Update -\d+\.\d+\.\d+-\.zip$/.test(entry.name)) {
  if (await hashFile(path.join(root, entry.name)) !== sums[entry.name]) throw new Error('Patch checksum mismatch: ' + entry.name);
  files.push(entry.name);
}
if (!files.includes(`Update -${pkg.version}-.zip`)) throw new Error('Generate and copy the current update ZIP and merged SHA256SUMS.json to the source root first.');
await fs.mkdir(output, { recursive: true });
const result = await writeZip(root, files.sort(), path.join(output, `Blockage_GitHub_${pkg.version}.zip`), '');
console.log(JSON.stringify(result));
