import fs from 'node:fs/promises';
import path from 'node:path';
import { createReadStream } from 'node:fs';
import { createHash } from 'node:crypto';
import {
  cookNativeScene,
  validateNativeBytes,
} from '../src/engine/native-cook.js';
import { imports, systemDLL } from './native/pe.mjs';
const root = path.resolve(import.meta.dirname, '..');
export function steamFiles(app, depot) {
  for (const v of [app, depot])
    if (!/^[1-9]\d{0,9}$/.test(v || '') || Number(v) > 0xffffffff)
      throw new Error('Supply your actual Steam AppID and DepotID together.');
  const build = (preview) =>
    '"AppBuild"\n{\n  "AppID" "' +
    app +
    '"\n  "Desc" "Blockage Windows x64"\n  "Preview" "' +
    Number(preview) +
    '"\n  "ContentRoot" "../content"\n  "BuildOutput" "../steampipe-cache"\n  "Depots"\n  {\n    "' +
    depot +
    '" "depot_' +
    depot +
    '.vdf"\n  }\n}\n';
  return {
    'app_preview.vdf': build(true),
    'app_candidate.vdf': build(false),
    ['depot_' + depot + '.vdf']:
      '"DepotBuildConfig"\n{\n  "DepotID" "' +
      depot +
      '"\n  "FileMapping"\n  {\n    "LocalPath" "*"\n    "DepotPath" "."\n    "recursive" "1"\n  }\n}\n',
  };
}
async function regular(file, max) {
  const s = await fs.lstat(file);
  if (!s.isFile() || s.isSymbolicLink() || s.size < 1 || s.size > max)
    throw new Error('Invalid input: ' + path.basename(file));
}
export function assetName(name) {
  if (
    typeof name !== 'string' ||
    name.length > 240 ||
    name
      .split('/')
      .some(
        (s) =>
          !s ||
          s === '.' ||
          s === '..' ||
          /[\x00-\x1f\\:*?"<>|]/.test(s) ||
          /[. ]$/.test(s) ||
          /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(s),
      ) ||
    !/\.(wav|ogg|obj|png|jpg|ktx2|mesh|bin|glb|bns|json)$/i.test(name)
  )
    throw new Error('Unsafe asset path: ' + name);
  return name;
}
export function options(args) {
  const o = { dll: [], asset: [] };
  for (let i = 0; i < args.length; i += 2) {
    const k = args[i],
      v = args[i + 1];
    if (
      !v ||
      v.startsWith('--') ||
      ![
        '--binary',
        '--scene',
        '--out',
        '--config',
        '--app-id',
        '--depot-id',
        '--asset-root',
        '--asset',
        '--dll',
      ].includes(k)
    )
      throw new Error('Unknown/incomplete argument: ' + k);
    if (k === '--asset' || k === '--dll') o[k.slice(2)].push(v);
    else {
      if (Object.hasOwn(o, k.slice(2))) throw new Error('Duplicate ' + k);
      o[k.slice(2)] = v;
    }
  }
  for (const k of ['binary', 'scene', 'out'])
    if (!o[k]) throw new Error('Missing --' + k);
  return o;
}
export async function exportGame(o) {
  const exe = path.resolve(o.binary),
    scene = path.resolve(o.scene),
    out = path.resolve(o.out),
    base = path.dirname(exe),
    config = path.resolve(
      o.config || path.join(root, 'src/native/sample/game.cfg'),
    );
  if (
    await fs.lstat(out).catch((e) => {
      if (e.code === 'ENOENT') return null;
      throw e;
    })
  )
    throw new Error('Output already exists; choose a new folder.');
  const steam =
    o['app-id'] || o['depot-id']
      ? steamFiles(o['app-id'], o['depot-id'])
      : null;
  const isCooked = path.extname(scene).toLowerCase() === '.bns';
  await regular(scene, (isCooked ? 8 : 100) * 1024 ** 2);
  const cooked = isCooked
    ? validateNativeBytes(await fs.readFile(scene))
    : cookNativeScene(JSON.parse(await fs.readFile(scene, 'utf8')));
  await regular(config, 4096);
  const settings = new Map();
  for (const line of (await fs.readFile(config, 'utf8')).split(/\r?\n/)) {
    if (!line || line.startsWith('#')) continue;
    const m = /^([a-z_]+)=(.*)$/.exec(line);
    if (!m || settings.has(m[1])) throw new Error('Invalid game.cfg');
    settings.set(m[1], m[2]);
  }
  if (!/^[a-z0-9_-]{1,48}$/.test(settings.get('game_id') || ''))
    throw new Error('Invalid game_id');
  const ranges = {
    width: [320, 7680],
    height: [200, 4320],
    vsync: [0, 1],
    volume: [0, 100],
  };
  for (const [k, v] of settings)
    if (
      k !== 'game_id' &&
      (!Object.hasOwn(ranges, k) ||
        !/^\d+$/.test(v) ||
        +v < ranges[k][0] ||
        +v > ranges[k][1])
    )
      throw new Error('Invalid setting: ' + k);
  const files = new Map([
    ['BlockageGame.exe', exe],
    ['game.cfg', config],
    ['licenses/Blockage-MIT.txt', path.join(root, 'LICENSE')],
  ]);
  for (const n of await fs.readdir(path.join(root, 'src/native/licenses')))
    if (/^[a-zA-Z0-9-]+\.txt$/.test(n))
      files.set('licenses/' + n, path.join(root, 'src/native/licenses', n));
  await regular(exe, 512 * 1024 ** 2);
  const dependencies = new Set(imports(await fs.readFile(exe))),
    supplied = new Set();
  for (const dll of o.dll || []) {
    const lower = dll.toLowerCase();
    if (
      !/^[a-z0-9_.+-]+\.dll$/i.test(dll) ||
      supplied.has(lower) ||
      systemDLL(lower)
    )
      throw new Error('Invalid DLL: ' + dll);
    const f = path.join(base, dll);
    await regular(f, 256 * 1024 ** 2);
    for (const dep of imports(await fs.readFile(f), true))
      dependencies.add(dep);
    supplied.add(lower);
    files.set(dll, f);
  }
  for (const d of dependencies)
    if (!systemDLL(d) && !supplied.has(d))
      throw new Error('Missing redistributable DLL: ' + d);
  const assets = o.asset || [],
    seen = new Set();
  if (assets.length > 2048 || (assets.length && !o['asset-root']))
    throw new Error('Supply --asset-root and at most 2048 named assets.');
  if (assets.length) {
    const parent = await fs.realpath(o['asset-root']);
    for (const a of assets) {
      const n = assetName(a),
        f = path.join(parent, ...n.split('/'));
      if (seen.has(n.toLowerCase()) || (await fs.realpath(f)) !== f)
        throw new Error('Duplicate or linked asset');
      seen.add(n.toLowerCase());
      await regular(f, 1024 ** 3);
      files.set('content/assets/' + n, f);
    }
  }
  await fs.mkdir(path.dirname(out), { recursive: true });
  const stage = await fs.mkdtemp(
      path.join(path.dirname(out), '.blockage-native-'),
    ),
    content = path.join(stage, 'content');
  try {
    for (const [n, f] of files) {
      const dst = path.join(content, n);
      await fs.mkdir(path.dirname(dst), { recursive: true });
      await fs.copyFile(f, dst);
    }
    await fs.mkdir(path.join(content, 'content'), { recursive: true });
    await fs.writeFile(path.join(content, 'content/level.bns'), cooked.bytes);
    if (steam) {
      await fs.mkdir(path.join(stage, 'steam'));
      for (const [n, s] of Object.entries(steam))
        await fs.writeFile(path.join(stage, 'steam', n), s);
    }
    const hashes = {};
    for (const n of [...files.keys(), 'content/level.bns'].sort()) {
      const h = createHash('sha256');
      for await (const b of createReadStream(path.join(content, n)))
        h.update(b);
      hashes[n] = h.digest('hex');
    }
    const report = {
      schema: 1,
      platform: 'windows-x64',
      launch: 'BlockageGame.exe',
      gameId: settings.get('game_id'),
      objects: cooked.count,
      warnings: cooked.warnings,
      imports: [...dependencies].sort(),
      sha256: hashes,
      steamPublished: false,
    };
    await fs.writeFile(
      path.join(stage, 'build-report.json'),
      JSON.stringify(report, null, 2) + '\n',
    );
    await fs.rename(stage, out);
    return report;
  } catch (e) {
    await fs.rm(stage, { recursive: true, force: true });
    throw e;
  }
}
if (import.meta.main)
  try {
    console.log(
      JSON.stringify(await exportGame(options(process.argv.slice(2))), null, 2),
    );
  } catch (e) {
    console.error(e.message);
    process.exitCode = 1;
  }
