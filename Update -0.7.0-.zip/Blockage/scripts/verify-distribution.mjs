// Run against the actual packaged app, without resolving Three.js from the development tree.
import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';
import { createRequire } from 'node:module';

export async function verifyDistribution(folder) {
  const resources = path.join(path.resolve(folder), 'resources'), root = path.join(resources, 'app');
  const metadata = JSON.parse(await fs.readFile(path.join(resources, 'blockage-distribution.json')));
  const pkg = JSON.parse(await fs.readFile(path.join(root, 'package.json')));
  assert.equal(metadata.format, 'blockage.distribution'); assert.equal(metadata.engineVersion, pkg.version);
  assert.equal(pkg.devDependencies.electron, metadata.electronVersion); assert.equal(pkg.name, 'blockage-engine');
  const win = metadata.platform === 'win32', exe = path.join(folder, win ? 'Blockage.exe' : 'blockage');
  for (const file of [exe, path.join(resources, 'updater', win ? 'node.exe' : 'node')]) {
    const h = await fs.open(file); try { const magic = Buffer.alloc(4); await h.read(magic, 0, 4, 0); assert(win ? magic.subarray(0, 2).toString() === 'MZ' : magic.equals(Buffer.from([127, 69, 76, 70]))); } finally { await h.close(); }
  }
  await fs.access(path.join(resources, 'updater/LICENSE.node.txt'));
  const requireInstalled = createRequire(path.join(root, 'package.json'));
  // Resolve renderer dependencies from the installed application, not from this script.
  await import(pathToFileURL(path.join(root, 'src/engine/renderer.js')).href);
  const { GLTFLoader } = await import(pathToFileURL(requireInstalled.resolve('three/addons/loaders/GLTFLoader.js')).href);
  const model = await new GLTFLoader().parseAsync(JSON.stringify({ asset: { version: '2.0' }, scenes: [{ nodes: [0] }], scene: 0, nodes: [{ name: 'DistributionTest' }] }), '');
  assert(model.scene.getObjectByName('DistributionTest'));
  for (const decoder of ['draco/gltf/draco_decoder.wasm', 'basis/basis_transcoder.wasm']) assert(WebAssembly.validate(await fs.readFile(path.join(root, 'node_modules/three/examples/jsm/libs', decoder))));
  for (const file of ['electron/main.cjs', 'electron/preload.cjs', 'src/index.html', 'assets/logo.svg', 'scripts/blender-export.py', 'scripts/blender-alembic.py']) await fs.access(path.join(root, file));
  console.log(`Verified Blockage ${pkg.version} ${metadata.platform}/${metadata.arch}: executable headers, renderer imports, glTF scene, Draco/KTX2, update helper and converters.`);
}
if (import.meta.main) { if (!process.argv[2]) throw new Error('Pass the installed or unpacked Blockage application folder.'); await verifyDistribution(process.argv[2]); }
