import fs from 'node:fs/promises';
import path from 'node:path';
import { createDocument, createEntity } from '../src/engine/document.js';
import { cookNativeScene } from '../src/engine/native-cook.js';
export function exampleLevel() {
  const d = createDocument('Beacon Run');
  function add(kind, name, position, scale, color, collider = false) {
    const e = createEntity(kind, {
      id: 'beacon:' + name,
      name,
      collider,
      transform: { position, rotation: [0, 0, 0], scale },
    });
    e.material.color = color;
    d.entities.push(e);
  }
  add('box', 'Track', [0, -0.5, 6], [11, 1, 23], '#324662', true);
  add('box', 'PlayerSpawn', [0, 0.5, 0], [0.7, 1, 0.7], '#ffaf50', true);
  add('sphere', 'Beacon_1', [-2, 0.7, 3], [0.85, 0.85, 0.85], '#5ff1d7');
  add('sphere', 'Beacon_2', [2, 0.7, 6], [0.85, 0.85, 0.85], '#5ff1d7');
  add('sphere', 'Beacon_3', [-1, 0.7, 9], [0.85, 0.85, 0.85], '#5ff1d7');
  add('box', 'Exit', [0, 0.65, 13], [2.4, 1.3, 0.5], '#ed78ae');
  for (const side of [-1, 1]) {
    add(
      'box',
      'Rail_' + side,
      [side * 5.35, 0.34, 6],
      [0.28, 0.68, 23],
      '#718ca1',
      true,
    );
    for (let i = 0; i < 6; i++)
      add(
        'cylinder',
        'Post_' + side + '_' + i,
        [side * 5.15, 0.65, -2 + i * 3.3],
        [0.3, 1.3, 0.3],
        '#5a8c99',
      );
  }
  return d;
}
if (import.meta.main) {
  const d = exampleLevel(),
    p = path.resolve(import.meta.dirname, '../src/native/sample');
  await fs.writeFile(
    path.join(p, 'beacon-run.blockage'),
    JSON.stringify(d, null, 2) + '\n',
  );
  await fs.writeFile(path.join(p, 'level.bns'), cookNativeScene(d).bytes);
}
