param([Parameter(Mandatory=$true)][string]$Installer)
$ErrorActionPreference = 'Stop'
if ($env:RUNNER_OS -ne 'Windows' -or $env:GITHUB_ACTIONS -ne 'true') { throw 'Run this installation test only on an isolated GitHub Windows runner.' }
$setup = (Resolve-Path -LiteralPath $Installer).Path
if ((Get-Item -LiteralPath $setup).Length -lt 1MB) { throw 'Incomplete installer' }
$destination = Join-Path $env:RUNNER_TEMP ('Blockage QA ' + [guid]::NewGuid().ToString())
$install = Start-Process -FilePath $setup -ArgumentList @('/S', "/D=$destination") -Wait -PassThru
if ($install.ExitCode -ne 0) { throw "NSIS install failed: $($install.ExitCode)" }
$helper = Join-Path $destination 'resources/updater/node.exe'
& $helper (Join-Path $PSScriptRoot 'verify-distribution.mjs') $destination
if ($LASTEXITCODE -ne 0) { throw 'Installed application verification failed' }
