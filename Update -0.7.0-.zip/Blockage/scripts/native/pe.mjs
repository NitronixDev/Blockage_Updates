// Inspect the PE32+ file; no executable or DLL is loaded into a build process.
export function imports(b, dll = false) {
  const ok = (v, msg) => {
    if (!v) throw new Error('Invalid Windows x64 image: ' + msg);
  };
  ok(b.length >= 64 && b.toString('ascii', 0, 2) === 'MZ', 'DOS header');
  const pe = b.readUInt32LE(60);
  ok(
    pe >= 64 && pe <= b.length - 24 && b.readUInt32LE(pe) === 0x4550,
    'signature',
  );
  const opt = pe + 24,
    n = b.readUInt16LE(pe + 6),
    len = b.readUInt16LE(pe + 20),
    flags = b.readUInt16LE(pe + 22);
  ok(
    b.readUInt16LE(pe + 4) === 0x8664 &&
      flags & 2 &&
      !!(flags & 0x2000) === dll,
    'machine or file type',
  );
  ok(
    n > 0 &&
      n <= 96 &&
      len >= 128 &&
      opt + len + n * 40 <= b.length &&
      b.readUInt16LE(opt) === 0x20b,
    'headers',
  );
  const sections = [];
  for (let j = 0; j < n; j++) {
    const p = opt + len + j * 40,
      va = b.readUInt32LE(p + 12),
      size = b.readUInt32LE(p + 16),
      start = b.readUInt32LE(p + 20);
    ok(start + size <= b.length, 'section bounds');
    sections.push({ va, size, start });
  }
  const offset = (rva, count) => {
    const s = sections.find((s) => rva >= s.va && rva - s.va + count <= s.size);
    ok(s, 'unmapped address');
    return s.start + rva - s.va;
  };
  const names = new Set();
  for (const [index, stride, nameOffset] of [
    [1, 20, 12],
    [13, 32, 4],
  ]) {
    if (b.readUInt32LE(opt + 108) <= index) continue;
    ok(112 + (index + 1) * 8 <= len, 'directories');
    const d = opt + 112 + index * 8,
      table = b.readUInt32LE(d),
      size = b.readUInt32LE(d + 4);
    if (!table && !size) continue;
    ok(table && size >= stride && size <= 1024 * 1024, 'import table');
    let ended = false;
    for (let pos = 0; pos + stride <= size; pos += stride) {
      const i = offset(table + pos, stride);
      if (b.subarray(i, i + stride).every((v) => v === 0)) {
        ended = true;
        break;
      }
      if (index === 13) ok(b.readUInt32LE(i) === 1, 'delay import type');
      const r = b.readUInt32LE(i + nameOffset),
        at = offset(r, 1),
        end = b.indexOf(0, at);
      ok(end > at && end - at <= 160, 'DLL name');
      offset(r, end - at + 1);
      const name = b.toString('ascii', at, end).toLowerCase();
      ok(/^[a-z0-9_+.-]+\.dll$/.test(name), 'unsafe DLL name');
      names.add(name);
    }
    ok(ended, 'unterminated import table');
  }
  return [...names].sort();
}
const windows = new Set(
  'kernel32 kernelbase user32 gdi32 winmm d3d11 dxgi d3dcompiler_47 msvcrt ucrtbase ole32 oleaut32 shell32 shlwapi advapi32 ws2_32 ntdll bcrypt version imm32 setupapi crypt32 comdlg32 comctl32 hid shcore rpcrt4 cfgmgr32'
    .split(' ')
    .map((n) => n + '.dll'),
);
export const systemDLL = (n) =>
  windows.has(n) || /^(api|ext)-ms-win-[a-z0-9-]+\.dll$/.test(n);
