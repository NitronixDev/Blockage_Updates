const fs = require('node:fs/promises');
const path = require('node:path');

/** Source-only ZIP updates require real resources/app folders, not app.asar.
 * No installer hooks download code and publishing is explicitly disabled by dist.mjs.
 */
function distributionConfig({ root, appDirectory, updaterDirectory, platform, pkg, electronDist }) {
  const windows = platform === 'win32';
  return {
    appId: 'dev.nitronix.blockage', productName: 'Blockage',
    electronVersion: pkg.devDependencies.electron,
    ...(electronDist ? { electronDist } : {}),
    asar: false, npmRebuild: false, nodeGypRebuild: false,
    directories: { app: appDirectory, output: path.join(root, 'dist'), buildResources: path.join(root, 'assets') },
    files: ['**/*'],
    extraResources: [{ from: updaterDirectory, to: 'updater', filter: [windows ? 'node.exe' : 'node', 'LICENSE.node.txt'] }],
    publish: null,
    win: { target: [{ target: 'nsis', arch: ['x64'] }], icon: path.join(root, 'assets/icon.png'), executableName: 'Blockage', requestedExecutionLevel: 'asInvoker' },
    nsis: {
      oneClick: false, perMachine: false, allowElevation: false,
      allowToChangeInstallationDirectory: true, createDesktopShortcut: true, createStartMenuShortcut: true,
      deleteAppDataOnUninstall: false, runAfterFinish: true,
      artifactName: 'Blockage-Setup-${version}-${arch}.${ext}'
    },
    linux: { target: [{ target: 'zip', arch: ['x64'] }], executableName: 'blockage', category: 'Development', icon: path.join(root, 'assets/icon.png'), artifactName: 'Blockage-${version}-linux-${arch}.${ext}' },
    async afterPack(context) {
      const resources = path.join(context.appOutDir, 'resources'), installed = path.join(resources, 'app');
      // electron-builder prunes `examples` in production dependencies. In Three.js,
      // examples/jsm is the runtime addon module tree, not example projects.
      const addons = 'node_modules/three/examples/jsm';
      await fs.cp(path.join(appDirectory, addons), path.join(installed, addons), { recursive: true });
      // Keep the canonical engine manifest: the ZIP validator compares dependency
      // versions against this file, including the Electron version. Builder strips
      // devDependencies by default, even though Electron is bundled separately.
      await fs.writeFile(path.join(installed, 'package.json'), JSON.stringify(pkg, null, 2) + '\n');
      for (const name of ['electron/main.cjs', 'electron/preload.cjs', 'src/index.html', 'assets/logo.svg', 'scripts/blender-export.py', 'scripts/blender-alembic.py', 'node_modules/three/build/three.webgpu.js', `${addons}/controls/OrbitControls.js`, `${addons}/loaders/GLTFLoader.js`, `${addons}/libs/draco/gltf/draco_decoder.wasm`, `${addons}/libs/basis/basis_transcoder.wasm`]) {
        if (!(await fs.stat(path.join(installed, name))).isFile()) throw new Error('Incomplete application: ' + name);
      }
      if (!(await fs.stat(path.join(resources, 'updater', windows ? 'node.exe' : 'node'))).isFile()) throw new Error('Missing standalone updater runtime.');
      if (!(await fs.stat(path.join(resources, 'updater/LICENSE.node.txt'))).isFile()) throw new Error('Missing standalone Node notices.');
      if (await fs.stat(path.join(resources, 'app.asar')).catch(() => null)) throw new Error('ASAR is incompatible with Blockage component ZIP updates.');
      await fs.writeFile(path.join(resources, 'blockage-distribution.json'), JSON.stringify({ format: 'blockage.distribution', version: 1, engineVersion: pkg.version, electronVersion: pkg.devDependencies.electron, nodeVersion: process.version, platform, arch: 'x64', updates: 'component-zips', appDirectory: 'app' }, null, 2) + '\n');
    }
  };
}
module.exports = { distributionConfig };
