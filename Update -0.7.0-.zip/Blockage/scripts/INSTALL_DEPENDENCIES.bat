@echo off
setlocal
call "%~dp0launch-windows.cmd" repair
if errorlevel 1 exit /b 1
echo Les composants Blockage sont installes.
pause
exit /b 0
