"""Trusted converter; imported .blend auto-execution is disabled by the caller."""
import argparse
import os
import sys
import bpy
sys.dont_write_bytecode = True

parser = argparse.ArgumentParser()
parser.add_argument('--input', required=True)
parser.add_argument('--output', required=True)
args = parser.parse_args(sys.argv[sys.argv.index('--') + 1:])
ext = os.path.splitext(args.input)[1].lower()
if ext != '.blend':
    bpy.ops.object.select_all(action='SELECT')
    bpy.ops.object.delete(use_global=False)
    if ext in ('.usd', '.usda', '.usdc', '.usdz'):
        bpy.ops.wm.usd_import(filepath=args.input)
    elif ext == '.abc':
        bpy.ops.wm.alembic_import(filepath=args.input, set_frame_range=True)
        sys.path.insert(0, os.path.dirname(__file__))
        from importlib import import_module
        import_module('blender-alembic').bake_alembic()
    elif ext == '.obj':
        bpy.ops.wm.obj_import(filepath=args.input)
    elif ext in ('.gltf', '.glb'):
        bpy.ops.import_scene.gltf(filepath=args.input)
    elif ext == '.stl':
        bpy.ops.wm.stl_import(filepath=args.input)
    elif ext == '.ply':
        bpy.ops.wm.ply_import(filepath=args.input)
    elif ext == '.dae':
        bpy.ops.wm.collada_import(filepath=args.input)
    else:
        raise RuntimeError('Unsupported conversion format: ' + ext)
# Bake Alembic vertex animation to morph targets for a portable game asset.
options = dict(filepath=args.output, export_format='GLB', export_animations=True,
               export_skins=True, export_morph=True, export_apply=False)
if ext == '.abc':
    options.update(export_animation_mode='SCENE', export_morph_animation=True,
                   export_anim_scene_split_object=False, export_bake_animation=True)
bpy.ops.export_scene.gltf(**options)
