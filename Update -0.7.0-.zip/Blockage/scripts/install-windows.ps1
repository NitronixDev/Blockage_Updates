param([switch]$Repair)

function Test-NodeRuntime {
    param([string]$Directory, [string]$MinimumVersion)
    $executable = Join-Path $Directory 'node.exe'
    if (-not (Test-Path -LiteralPath $executable -PathType Leaf)) { return $false }
    if (-not (Test-Path -LiteralPath (Join-Path $Directory 'node_modules/npm/bin/npm-cli.js') -PathType Leaf)) { return $false }
    try {
        $actual = & $executable --version 2>$null
        if ($LASTEXITCODE -ne 0) { return $false }
        return ([version]($actual.Trim().TrimStart('v')) -ge [version]$MinimumVersion)
    } catch { return $false }
}

function Test-BlockageDependencies {
    param([string]$Root, [string]$Node)
    & $Node (Join-Path $PSScriptRoot 'verify-install.cjs') $Root --quiet
    return ($LASTEXITCODE -eq 0)
}

function Invoke-BlockageNode {
    param([string]$Node, [string[]]$NodeArguments, [string]$Operation)
    & $Node @NodeArguments
    if ($LASTEXITCODE -ne 0) { throw "$Operation : code $LASTEXITCODE." }
}

function Receive-NodeArchive {
    param([string]$Url, [string]$Destination)
    [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
    for ($attempt = 1; $attempt -le 3; $attempt++) {
        try {
            Invoke-WebRequest -Uri $Url -OutFile $Destination -UseBasicParsing -TimeoutSec 300
            return
        } catch {
            if ($attempt -eq 3) { throw }
            Write-Host "Telechargement interrompu. Nouvelle tentative ($attempt/3)..."
            Start-Sleep -Seconds 2
        }
    }
}

function Expand-NodeArchive {
    param([string]$Archive, [string]$Destination, [string]$Sha256)
    if ((Get-FileHash -LiteralPath $Archive -Algorithm SHA256).Hash.ToLowerInvariant() -ne $Sha256) {
        throw 'Le telechargement Node est incomplet : verification SHA-256 incorrecte.'
    }
    Expand-Archive -LiteralPath $Archive -DestinationPath $Destination -Force
}

function Set-BlockageDirectory {
    param([string]$Source, [string]$Destination)
    $backup = $Destination + '.backup-' + [guid]::NewGuid().ToString('N')
    $moved = $false
    try {
        if (Test-Path -LiteralPath $Destination) {
            Move-Item -LiteralPath $Destination -Destination $backup -ErrorAction Stop
            $moved = $true
        }
        Move-Item -LiteralPath $Source -Destination $Destination -ErrorAction Stop
    } catch {
        if ($moved -and -not (Test-Path -LiteralPath $Destination)) {
            Move-Item -LiteralPath $backup -Destination $Destination -ErrorAction Stop
        }
        throw
    }
    if ($moved) { Remove-Item -LiteralPath $backup -Recurse -Force -ErrorAction SilentlyContinue }
}

function Install-Blockage {
    param([string]$Root, [switch]$Repair)
    $ErrorActionPreference = 'Stop'
    $ProgressPreference = 'SilentlyContinue'
    if ($env:OS -ne 'Windows_NT' -or -not [Environment]::Is64BitOperatingSystem) {
        throw 'Ce lanceur demande Windows 10/11 64 bits. Sous Linux/macOS, utilise npm ci puis npm start.'
    }
    foreach ($relative in @('package.json', 'package-lock.json', 'electron/main.cjs', 'src/index.html', 'scripts/windows-runtime.json', 'scripts/verify-install.cjs')) {
        if (-not (Test-Path -LiteralPath (Join-Path $Root $relative) -PathType Leaf)) {
            throw "Archive incomplete : $relative manque. Extrais toute l'archive dans un dossier avant de lancer Blockage."
        }
    }
    $config = Get-Content -LiteralPath (Join-Path $Root 'scripts/windows-runtime.json') -Raw | ConvertFrom-Json
    $runtime = Join-Path $Root 'runtime'
    $nodeDirectory = Join-Path $runtime 'node'
    $node = Join-Path $nodeDirectory 'node.exe'
    if (-not $Repair -and (Test-NodeRuntime $nodeDirectory $config.version) -and (Test-BlockageDependencies $Root $node)) { return }
    $lock = $null
    $stage = $null
    $transcript = $false
    $originalPath = $env:PATH
    $originalSkip = $env:ELECTRON_SKIP_BINARY_DOWNLOAD
    try {
        New-Item -ItemType Directory -Path $runtime -Force | Out-Null
        $timer = [Diagnostics.Stopwatch]::StartNew()
        while ($null -eq $lock) {
            try { $lock = [IO.File]::Open((Join-Path $runtime '.setup.lock'), [IO.FileMode]::OpenOrCreate, [IO.FileAccess]::ReadWrite, [IO.FileShare]::None) }
            catch [IO.IOException] {
                if ($timer.Elapsed.TotalSeconds -ge 600) { throw 'Une autre installation est en cours. Ferme-la puis relance Blockage.' }
                Start-Sleep -Milliseconds 300
            }
        }
        if (-not $Repair -and (Test-NodeRuntime $nodeDirectory $config.version) -and (Test-BlockageDependencies $Root $node)) { return }
        Start-Transcript -LiteralPath (Join-Path $Root 'blockage-install.log') -Append -Force | Out-Null
        $transcript = $true
        $stage = Join-Path $runtime ('.setup-' + [guid]::NewGuid().ToString('N'))
        New-Item -ItemType Directory -Path $stage | Out-Null
        Write-Host 'Preparation de Blockage dans son dossier. Internet est necessaire pour les composants manquants.'
        if (-not (Test-NodeRuntime $nodeDirectory $config.version)) {
            Write-Host '[1/3] Telechargement et verification du runtime Node...'
            $archive = Join-Path $stage $config.archive
            Receive-NodeArchive $config.url $archive
            $unpacked = Join-Path $stage 'unpacked'
            Expand-NodeArchive $archive $unpacked $config.sha256
            $newNode = Join-Path $unpacked ('node-v' + $config.version + '-win-x64')
            if (-not (Test-NodeRuntime $newNode $config.version)) { throw 'Le runtime telecharge ne peut pas demarrer sur ce PC.' }
            Set-BlockageDirectory $newNode $nodeDirectory
        }
        $env:PATH = $nodeDirectory + [IO.Path]::PathSeparator + $originalPath
        if ($Repair -or -not (Test-BlockageDependencies $Root $node)) {
            Write-Host '[2/3] Installation des dependances et du moteur graphique...'
            $dependencies = Join-Path $stage 'dependencies'
            New-Item -ItemType Directory -Path $dependencies | Out-Null
            foreach ($name in @('package.json', 'package-lock.json')) {
                Copy-Item -LiteralPath (Join-Path $Root $name) -Destination (Join-Path $dependencies $name)
            }
            $npm = Join-Path $nodeDirectory 'node_modules/npm/bin/npm-cli.js'
            Invoke-BlockageNode -Node $node -NodeArguments @($npm, 'ci', '--prefix', $dependencies, '--include=dev', '--ignore-scripts', '--no-audit', '--no-fund', '--registry=https://registry.npmjs.org') -Operation 'Installation npm interrompue'
            $env:ELECTRON_SKIP_BINARY_DOWNLOAD = $null
            Invoke-BlockageNode -Node $node -NodeArguments @((Join-Path $dependencies 'node_modules/electron/install.js')) -Operation 'Telechargement Electron interrompu'
            if (-not (Test-BlockageDependencies $dependencies $node)) { throw 'Les dependances installees sont incompletes. Relance pour reessayer.' }
            Set-BlockageDirectory (Join-Path $dependencies 'node_modules') (Join-Path $Root 'node_modules')
        }
        Write-Host '[3/3] Blockage est pret.'
    } finally {
        $env:PATH = $originalPath
        $env:ELECTRON_SKIP_BINARY_DOWNLOAD = $originalSkip
        if ($null -ne $stage -and (Test-Path -LiteralPath $stage)) { Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue }
        if ($null -ne $lock) { $lock.Dispose() }
        if ($transcript) { Stop-Transcript | Out-Null }
    }
}

if ($MyInvocation.InvocationName -ne '.') {
    try {
        Install-Blockage -Root (Split-Path -Parent $PSScriptRoot) -Repair:$Repair
        exit 0
    } catch {
        Write-Host ''
        Write-Host ('Installation impossible : ' + $_.Exception.Message) -ForegroundColor Red
        Write-Host 'Verifie la connexion Internet et ferme les autres fenetres Blockage avant de reessayer.'
        Write-Host 'Details : blockage-install.log dans le dossier Blockage.'
        exit 1
    }
}
