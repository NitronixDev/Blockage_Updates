const fs = require('node:fs');
const path = require('node:path');

function installationProblems(root, platform = process.platform) {
  const problems = [];
  const readPackage = file => JSON.parse(fs.readFileSync(file, 'utf8'));
  let expected;
  try { expected = readPackage(path.join(root, 'package.json')); }
  catch { return ['package.json absent ou illisible. Extrais toute l\'archive.']; }
  for (const name of ['three', 'electron']) {
    try {
      const actual = readPackage(path.join(root, 'node_modules', name, 'package.json'));
      const version = expected.dependencies?.[name] || expected.devDependencies?.[name];
      if (actual.version !== version) problems.push(name + ' : version incorrecte.');
    } catch { problems.push(name + ' : dependance absente ou incomplete.'); }
  }
  const distribution = path.join(root, 'node_modules', 'electron', 'dist');
  const executable = platform === 'win32' ? 'electron.exe' : platform === 'darwin' ? 'Electron.app/Contents/MacOS/Electron' : 'electron';
  const required = ['node_modules/three/build/three.module.js', 'node_modules/three/build/three.core.js', 'node_modules/three/examples/jsm/loaders/GLTFLoader.js'];
  if (platform === 'win32') required.push(...['icudtl.dat', 'resources.pak', 'locales/en-US.pak'].map(file => 'node_modules/electron/dist/' + file));
  for (const relative of required) {
    try { const info = fs.statSync(path.join(root, relative)); if (!info.isFile() || !info.size) throw new Error(); }
    catch { problems.push('Fichier absent : ' + relative); }
  }
  try {
    const filename = path.join(distribution, executable);
    if (fs.statSync(filename).size < 1024) throw new Error();
    const file = fs.openSync(filename, 'r');
    try {
      const signature = Buffer.alloc(4);
      fs.readSync(file, signature, 0, 4, 0);
      if (platform === 'win32' && signature.subarray(0, 2).toString() !== 'MZ') throw new Error();
      if (platform === 'linux' && !signature.equals(Buffer.from([0x7f, 0x45, 0x4c, 0x46]))) throw new Error();
    } finally { fs.closeSync(file); }
    if (fs.readFileSync(path.join(root, 'node_modules/electron/path.txt'), 'utf8').trim() !== executable) throw new Error();
  } catch { problems.push('Electron : executable absent, incomplet ou incompatible.'); }
  return problems;
}

if (require.main === module) {
  const root = path.resolve(process.argv.slice(2).find(arg => arg !== '--quiet') || path.join(__dirname, '..'));
  const problems = installationProblems(root);
  const minimum = require('./windows-runtime.json').version.split('.').map(Number);
  const actual = process.versions.node.split('.').map(Number);
  for (let i = 0; i < 3; i++) {
    if (actual[i] === minimum[i]) continue;
    if (actual[i] < minimum[i]) problems.push('Le runtime Node doit etre mis a jour.');
    break;
  }
  if (!process.argv.includes('--quiet')) for (const problem of problems) console.error(problem);
  process.exitCode = problems.length ? 1 : 0;
}
module.exports = { installationProblems };
