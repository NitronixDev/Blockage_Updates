# Blockage 0.7.0 — Studio et SDK natif

Blockage Studio reste l’éditeur Electron/Three.js : il ouvre les projets existants, conserve le format de scène 7 et l’ancien logo. **Blockage Native** est une cible distincte : un jeu Windows x64 écrit en C++20, sans Electron, JavaScript ni npm à l’exécution.

| Objectif | Point d’entrée |
| --- | --- |
| Ouvrir Studio sous Windows | `START_BLOCKAGE.bat` |
| Créer l’installateur de **l’éditeur** | `.\npm.cmd run dist` dans les sources |
| Construire le **jeu natif** | CMake, projet `src/native` ; commandes ci-dessous |
| Écrire le gameplay | `src/native/sample/game.cpp`, puis ta propre implémentation de `blockage::makeGame` |
| Exporter une scène | **File → Export Native Scene (.bns)…** dans Studio |
| Préparer le dossier du jeu ou un dépôt SteamPipe | `npm run native:export` ; aucun envoi automatique |
| Mettre à jour Studio 0.6.1 | Déposer **Update -0.7.0-.zip** intact à la racine de NitronixDev/Blockage_Updates |

## Compiler Beacon Run sous Windows

Prérequis développeur : Visual Studio 2022 ou Build Tools avec **Développement Desktop en C++**, SDK Windows et CMake ≥ 3.20. Les fichiers du niveau sont fournis : aucun téléchargement de dépendance par CMake.

```powershell
cmake -S src/native -B build/native -A x64
cmake --build build/native --config Release --parallel
ctest --test-dir build/native -C Release --output-on-failure
.\build\native\Release\BlockageGame.exe
```

Dans Beacon Run, déplace le bloc orange avec les flèches, ZQSD ou WASD. Récupère les trois balises turquoise et rejoins la sortie rose. **R** recommence, **Échap** quitte. Le titre affiche le compteur et le record. Le record reste dans le profil utilisateur, hors de l’installation.

## Exporter le jeu

Sur un poste de développement avec les dépendances de Studio installées (ou en utilisant `.\npm.cmd` fourni sous Windows) :

```powershell
.\npm.cmd run native:export -- --binary build/native/Release/BlockageGame.exe --scene src/native/sample/beacon-run.blockage --out native-out/beacon
```

Le dossier **native-out/beacon/content/** est le jeu à distribuer. Lance `BlockageGame.exe` à sa racine. Contrairement au jeu, le générateur utilise Node sur la machine de développement. Choisis un nouveau dossier pour chaque export. Pour générer les fichiers SteamPipe, ajoute `--app-id TON_APPID --depot-id TON_DEPOTID`, remplacés par tes **vrais** identifiants numériques.

L’éditeur et le jeu natif n’ont pas encore la même couverture : les matériaux PBR, l’eau, le tissu et les rigs de Studio ne sont pas portés dans le lecteur natif. Le générateur refuse les objets incompatibles par nom au lieu de les effacer du jeu.

**Documentation :** [architecture, API C++, configuration et SteamPipe](docs/ARCHITECTURE_NATIVE_0.7.md) · [mises à jour GitHub](docs/GITHUB_UPDATES.md) · [imports et personnages Studio](docs/IMPORTS_AND_CHARACTERS.md) · [référence de la génération Studio 0.6.1](docs/STUDIO_0.6.1.md).
