import * as THREE from 'three/webgpu';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { OBJLoader } from 'three/addons/loaders/OBJLoader.js';
import { MTLLoader } from 'three/addons/loaders/MTLLoader.js';
import { FBXLoader } from 'three/addons/loaders/FBXLoader.js';
import { STLLoader } from 'three/addons/loaders/STLLoader.js';
import { PLYLoader } from 'three/addons/loaders/PLYLoader.js';
import { ColladaLoader } from 'three/addons/loaders/ColladaLoader.js';
import { ThreeMFLoader } from 'three/addons/loaders/3MFLoader.js';
import { TGALoader } from 'three/addons/loaders/TGALoader.js';
import { DDSLoader } from 'three/addons/loaders/DDSLoader.js';
import { TDSLoader } from 'three/addons/loaders/TDSLoader.js';
import { AMFLoader } from 'three/addons/loaders/AMFLoader.js';
import { MD2Loader } from 'three/addons/loaders/MD2Loader.js';
import { VTKLoader } from 'three/addons/loaders/VTKLoader.js';
import { XYZLoader } from 'three/addons/loaders/XYZLoader.js';
import { PCDLoader } from 'three/addons/loaders/PCDLoader.js';
import { VOXLoader, buildMesh } from 'three/addons/loaders/VOXLoader.js';
import { DRACOLoader } from 'three/addons/loaders/DRACOLoader.js';
import { KTX2Loader } from 'three/addons/loaders/KTX2Loader.js';
import { MeshoptDecoder } from 'three/addons/libs/meshopt_decoder.module.js';
import { MODEL_MIMES, resourceName } from './model-formats.js';
import { assetBytes, assetUrl } from './asset-source.js';
import { glbBytes } from './glb-source.js';
let sharedDraco;
function draco(){return sharedDraco ||= new DRACOLoader().setDecoderPath(new URL('../../node_modules/three/examples/jsm/libs/draco/gltf/',import.meta.url).href).setWorkerLimit(Math.max(1,Math.min(4,(navigator.hardwareConcurrency||4)-1)));}
export async function loadModel(asset,{renderer}={}){
  const manager=new THREE.LoadingManager(),resources=new Map((asset.resources||[]).map(r=>[r.name.toLowerCase(),r]));
  const resourceBuffers=new Map();for(const r of resources.values())if(r.mime==='text/x-wavefront-mtl'||r.dataChunks)resourceBuffers.set(r,await assetBytes(r));
  const awaitableResourceBytes=r=>resourceBuffers.get(r);
  const blobUrls=new Map();let active=0;const errors=[];const start=manager.itemStart.bind(manager),end=manager.itemEnd.bind(manager);manager.itemStart=url=>{active++;start(url);};manager.itemEnd=url=>{active--;end(url);};manager.onError=url=>errors.push(url);
  manager.setURLModifier(url=>{if(/^(data:|blob:)/.test(url))return url;if(/^[a-z][a-z0-9+.-]*:/i.test(url)&&! /^[A-Za-z]:[\\/]/.test(url))throw new Error('Use embedded model resources.');let name;try{name=resourceName(url).toLowerCase();}catch{if(!asset.resourceBase)throw new Error('Model resource outside bundle.');name=resourceName(asset.resourceBase+'/'+url).toLowerCase();}let r=resources.get(name);if(!r&&asset.resourceBase)r=resources.get(resourceName(asset.resourceBase+'/'+url).toLowerCase());if(!r){const matches=[...resources.values()].filter(r=>r.name.toLowerCase().split('/').pop()===name.split('/').pop());if(matches.length===1)r=matches[0];}if(!r)throw new Error(`Missing model resource: ${name}`);if(r.storage)return assetUrl(r);if(r.dataChunks){if(!blobUrls.has(r.name))blobUrls.set(r.name,URL.createObjectURL(new Blob([awaitableResourceBytes(r)],{type:r.mime})));return blobUrls.get(r.name);}return `data:${r.mime};base64,${r.data}`;});
  manager.addHandler(/\.tga$/i,new TGALoader(manager));manager.addHandler(/\.dds$/i,new DDSLoader(manager));
  const ktx=renderer?new KTX2Loader().setTranscoderPath(new URL('../../node_modules/three/examples/jsm/libs/basis/',import.meta.url).href).detectSupport(renderer):null;
  try{const format=Object.keys(MODEL_MIMES).find(k=>MODEL_MIMES[k]===asset.mime),bytes=format==='glb'?await glbBytes(asset):await assetBytes(asset),text=()=>new TextDecoder().decode(bytes);let root,animations=[];
  if(['glb','gltf'].includes(format)){const result=await new GLTFLoader(manager).setDRACOLoader(draco()).setMeshoptDecoder(MeshoptDecoder).setKTX2Loader(ktx).parseAsync(format==='gltf'?text():bytes.buffer,'');root=result.scene;animations=result.animations;}
  else if(format==='obj'){const loader=new OBJLoader(manager),materials=new MTLLoader(manager).parse('','');for(const r of resources.values())if(r.mime==='text/x-wavefront-mtl'){const base=r.name.includes('/')?r.name.slice(0,r.name.lastIndexOf('/')+1):'',m=new MTLLoader(manager).parse(new TextDecoder().decode(await assetBytes(r)),base);m.preload();Object.assign(materials.materials,m.materials);}loader.setMaterials(materials);root=loader.parse(text());}
  else if(format==='fbx'){root=new FBXLoader(manager).parse(bytes.buffer,'');animations=root.animations||[];}
  else if(format==='dae'){const result=new ColladaLoader(manager).parse(text(),'');root=result.scene;animations=result.animations||[];}
  else if(format==='3mf')root=new ThreeMFLoader(manager).parse(bytes.buffer);
  else if(format==='3ds')root=new TDSLoader(manager).parse(bytes.buffer,'');
  else if(format==='amf')root=new AMFLoader(manager).parse(bytes.buffer);
  else if(format==='vox'){const data=new VOXLoader(manager).parse(bytes.buffer);root=data.scene||new THREE.Group();if(!data.scene)for(const chunk of data.chunks)root.add(buildMesh(chunk));}
  else if(format==='pcd')root=new PCDLoader(manager).parse(bytes.buffer);
  else if(format==='xyz'){const geometry=new XYZLoader(manager).parse(text());root=new THREE.Points(geometry,new THREE.PointsMaterial({size:.025,vertexColors:Boolean(geometry.attributes.color),color:geometry.attributes.color?'#ffffff':'#a8a8a8'}));}
  else if(format==='drc'){const geometry=await new Promise((resolve,reject)=>draco().parse(bytes.buffer,resolve,reject));root=new THREE.Mesh(geometry,new THREE.MeshStandardMaterial({color:'#a8a8a8',vertexColors:Boolean(geometry.attributes.color)}));}
  else if(format==='md2'){const geometry=new MD2Loader(manager).parse(bytes.buffer);root=new THREE.Mesh(geometry,new THREE.MeshStandardMaterial({color:'#a8a8a8'}));animations=geometry.animations||[];}
  else if(['vtk','vtp'].includes(format)){const padded=bytes.length<250?new Uint8Array(250).fill(32):bytes;if(padded!==bytes)padded.set(bytes);const geometry=new VTKLoader(manager).parse(padded.buffer);if(!geometry.attributes.normal)geometry.computeVertexNormals();root=new THREE.Mesh(geometry,new THREE.MeshStandardMaterial({color:'#a8a8a8',side:THREE.DoubleSide}));}
  else if(['stl','ply'].includes(format)){const geometry=format==='stl'?new STLLoader(manager).parse(bytes.buffer):new PLYLoader(manager).parse(bytes.buffer);if(!geometry.attributes.normal)geometry.computeVertexNormals();root=new THREE.Group();root.add(new THREE.Mesh(geometry,new THREE.MeshStandardMaterial({color:'#a8a8a8',roughness:.65,vertexColors:Boolean(geometry.attributes.color)})));}
  else throw new Error('Unsupported model format.');
  const deadline=Date.now()+30000;while(active>0){if(Date.now()>deadline)throw new Error('Model textures timed out.');await new Promise(r=>setTimeout(r,20));}if(errors.length)throw new Error('Model texture could not load.');
  const stats={format:asset.sourceFormat||format,vertices:0,meshes:0,bones:0,clips:animations.length};root.traverse(o=>{if(o.isMesh||o.isPoints){stats.meshes++;stats.vertices+=o.geometry?.attributes.position?.count||0;}if(o.isBone)stats.bones++;});
  if(!stats.meshes)throw new Error('The model contains no mesh.');if(stats.vertices>10000000||stats.meshes>8192||stats.bones>1024||stats.clips>1024)throw new Error('Model exceeds the mesh, vertex, bone or clip limit.');
  return {root,animations,stats};}finally{ktx?.dispose();for(const url of blobUrls.values())URL.revokeObjectURL(url);}
}
