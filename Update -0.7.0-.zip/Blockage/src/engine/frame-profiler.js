/** Fixed-size ring: no per-frame array allocation or full-scene traversal. */
export class FrameProfiler {
  constructor(capacity = 240) {
    this.capacity = capacity; this.frame = new Float64Array(capacity);
    this.update = new Float64Array(capacity); this.submit = new Float64Array(capacity); this.reset();
  }
  reset() { this.cursor = 0; this.count = 0; }
  record(frame, update, submit) {
    if (!Number.isFinite(frame) || !Number.isFinite(update) || !Number.isFinite(submit) || frame <= 0 || update < 0 || submit < 0) return;
    this.frame[this.cursor] = frame; this.update[this.cursor] = update; this.submit[this.cursor] = submit;
    this.cursor = (this.cursor + 1) % this.capacity; this.count = Math.min(this.capacity, this.count + 1);
  }
  snapshot(targetFPS = 60) {
    const budgetMs = 1000 / (Number.isFinite(targetFPS) && targetFPS > 0 ? targetFPS : 60);
    if (!this.count) return { samples: 0, fps: 0, frameMs: 0, p50: 0, p95: 0, p99: 0, budgetMs, overBudget: 0, overBudgetPercent: 0, updateMs: 0, submitMs: 0, history: [] };
    const history = []; let total = 0, update = 0, submit = 0, overBudget = 0;
    for (let i = 0; i < this.count; i++) {
      const at = (this.cursor - this.count + i + this.capacity) % this.capacity;
      history.push(this.frame[at]); total += this.frame[at]; update += this.update[at]; submit += this.submit[at];
      if (this.frame[at] > budgetMs) overBudget++;
    }
    const sorted = [...history].sort((a, b) => a - b), frameMs = total / this.count;
    return { samples: this.count, fps: 1000 / frameMs, frameMs, p50: sorted[Math.ceil(this.count * .5) - 1], p95: sorted[Math.ceil(this.count * .95) - 1], p99: sorted[Math.ceil(this.count * .99) - 1], budgetMs, overBudget, overBudgetPercent: 100 * overBudget / this.count, updateMs: update / this.count, submitMs: submit / this.count, history };
  }
}
