import * as THREE from 'three/webgpu';
/** Shared opaque primitives and model meshes, partitioned into 32 m cells.
 * Skinned, morph, mirrored, custom-layer and transparent meshes remain separate.
 * Originals stay in the hierarchy for physics and restore their exact layers.
 */
export class StaticBatches {
  constructor(content) { this.content=content;this.root=new THREE.Group();this.root.name='Static instances';this.originals=[];this.count=0; }
  clear() {
    for(const [object,mask] of this.originals)object.layers.mask=mask;
    for(const batch of this.root.children)batch.dispose();
    this.root.clear();this.root.removeFromParent();this.originals=[];this.count=0;
  }
  build(entities,objects,dynamicIds,excludedIds=new Set()) {
    this.clear();this.content.updateMatrixWorld(true);const groups=new Map(),position=new THREE.Vector3();
    for(const entity of entities) {
      const primitive=['box','sphere','cylinder','torus','plane'].includes(entity.kind);
      if((!primitive&&entity.kind!=='model')||dynamicIds.has(entity.id)||excludedIds.has(entity.id))continue;
      const root=objects.get(entity.id);if(!root)continue;
      root.traverse(object=>{
        if(!object.isMesh||object.isSkinnedMesh||object.isInstancedMesh||object.morphTargetInfluences?.length||object.layers.mask!==1||object.matrixWorld.determinant()<=0)return;
        for(let parent=object;parent;parent=parent.parent)if(!parent.visible)return;
        const materials=Array.isArray(object.material)?object.material:[object.material];
        if(materials.some(m=>!m||m.transparent||m.opacity<1||m.transmission>0))return;
        const materialKey=primitive?JSON.stringify(entity.material):materials.map(m=>m.uuid).join(',');
        position.setFromMatrixPosition(object.matrixWorld);
        const key=[object.geometry.uuid,materialKey,object.castShadow,object.receiveShadow,object.renderOrder,Math.floor(position.x/32),Math.floor(position.y/32),Math.floor(position.z/32)].join(':');
        let group=groups.get(key);if(!group)groups.set(key,group=[]);group.push({object,entityId:entity.id,threshold:primitive?8:4});
      });
    }
    const inverse=this.content.matrixWorld.clone().invert(),matrix=new THREE.Matrix4();
    for(const entries of groups.values()) {
      if(entries.length<entries[0].threshold)continue;const source=entries[0].object,batch=new THREE.InstancedMesh(source.geometry,source.material,entries.length);
      batch.userData.instanceEntities=entries.map(e=>e.entityId);batch.name='Batch · '+source.name;batch.castShadow=source.castShadow;batch.receiveShadow=source.receiveShadow;batch.renderOrder=source.renderOrder;
      for(let i=0;i<entries.length;i++) { const object=entries[i].object;batch.setMatrixAt(i,matrix.multiplyMatrices(inverse,object.matrixWorld));this.originals.push([object,object.layers.mask]);object.layers.disable(0);object.layers.enable(31); }
      batch.instanceMatrix.needsUpdate=true;batch.computeBoundingSphere();batch.computeBoundingBox();batch.matrixAutoUpdate=false;this.root.add(batch);this.count+=entries.length;
    }
    if(this.root.children.length)this.content.add(this.root);
  }
}
