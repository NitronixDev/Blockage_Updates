import { assetUrl, assetBytes } from './asset-source.js';
/** Fetch only referenced BIN ranges from file-backed GLB, including compressed buffer views. */
export async function glbBytes(asset) {
  if(!asset.storage)return assetBytes(asset);
  async function range(start,length) {
    if(!length)return new Uint8Array();
    const response=await fetch(assetUrl(asset),{headers:{Range:`bytes=${start}-${start+length-1}`},cache:'no-store'});
    if(response.status!==206)throw new Error('The model binary does not support bounded reads.');
    const bytes=new Uint8Array(await response.arrayBuffer());if(bytes.length!==length)throw new Error('Truncated model binary.');return bytes;
  }
  const header=await range(0,20),view=new DataView(header.buffer),jsonLength=view.getUint32(12,true);
  if(view.getUint32(0,true)!==0x46546c67||view.getUint32(4,true)!==2||view.getUint32(8,true)!==asset.storage.bytes||view.getUint32(16,true)!==0x4e4f534a||jsonLength>16*1048576||jsonLength+20>asset.storage.bytes)throw new Error('Invalid GLB header.');
  const json=JSON.parse(new TextDecoder().decode(await range(20,jsonLength))),chunkOffset=20+jsonLength;
  if(chunkOffset===asset.storage.bytes)return assetBytes(asset);
  const binaryHeader=await range(chunkOffset,8),binaryView=new DataView(binaryHeader.buffer),binaryLength=binaryView.getUint32(0,true);
  if(binaryView.getUint32(4,true)!==0x004e4942||chunkOffset+8+binaryLength>asset.storage.bytes)throw new Error('Invalid GLB binary chunk.');
  let used=0;
  for(const bufferView of json.bufferViews||[]){const source=bufferView.extensions?.EXT_meshopt_compression||bufferView;if((source.buffer||0)===0){const end=(source.byteOffset||0)+source.byteLength;if(!Number.isSafeInteger(end)||end<0||end>binaryLength)throw new Error('GLB buffer view is outside the binary chunk.');used=Math.max(used,end);}}
  used=Math.ceil(used/4)*4;if(used>binaryLength)throw new Error('Invalid GLB padding.');
  if(json.buffers?.[0]&&!json.buffers[0].uri)json.buffers[0].byteLength=used;
  const text=new TextEncoder().encode(JSON.stringify(json)),padded=Math.ceil(text.length/4)*4,bytes=new Uint8Array(20+padded+8+used),out=new DataView(bytes.buffer);
  out.setUint32(0,0x46546c67,true);out.setUint32(4,2,true);out.setUint32(8,bytes.length,true);out.setUint32(12,padded,true);out.setUint32(16,0x4e4f534a,true);bytes.fill(32,20,20+padded);bytes.set(text,20);out.setUint32(20+padded,used,true);out.setUint32(24+padded,0x004e4942,true);bytes.set(await range(chunkOffset+8,used),28+padded);
  return bytes;
}
