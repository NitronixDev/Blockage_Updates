export const KIND_LABELS = Object.freeze({
  box: 'Cube', sphere: 'Sphere', cylinder: 'Cylinder', torus: 'Torus', plane: 'Plane',
  group: 'Scene Group', model: 'Model Instance', player: 'Character Controller',
  directionalLight: 'Directional Light', pointLight: 'Point Light', spotLight: 'Spot Light',
  cloth: 'Cloth Surface', fluid: 'Fluid Volume', particles: 'Particle Emitter',
  water: 'Water Surface', terrain: 'Terrain', camera: 'Scene Camera', audio: 'Audio Source', trigger: 'Trigger Volume'
});
export const kindLabel = kind => KIND_LABELS[kind] || kind;
export function uniqueObjectName(entities, base) {
  const used = new Set(entities.map(e => e.name.toLowerCase()));
  if (!used.has(base.toLowerCase())) return base;
  for (let i = 1; ; i++) { const name = base.slice(0, 185) + '_' + String(i).padStart(3, '0'); if (!used.has(name.toLowerCase())) return name; }
}
