/** X/Z broad phase. Oversized objects stay in a bounded global list. */
export class SpatialIndex {
  constructor(cellSize = 8, maxCells = 64) { this.cellSize = cellSize; this.maxCells = maxCells; this.cells = new Map(); this.entries = new Map(); this.large = new Set(); }
  clear() { this.cells.clear(); this.entries.clear(); this.large.clear(); }
  remove(id) {
    const entry = this.entries.get(id); if (!entry) return;
    if (entry.keys) for (const key of entry.keys) { const cell = this.cells.get(key); cell.delete(entry); if (!cell.size) this.cells.delete(key); }
    else this.large.delete(entry);
    this.entries.delete(id);
  }
  set(id, bounds, value) {
    const previous = this.entries.get(id);
    if (previous && previous.value === value && previous.bounds.every((n,i) => n === bounds[i])) return;
    this.remove(id); const entry = { id, bounds: [...bounds], value, keys: null }; this.entries.set(id, entry);
    const [minX,minZ,maxX,maxZ] = bounds.map(n => Math.floor(n / this.cellSize));
    if ((maxX-minX+1)*(maxZ-minZ+1) > this.maxCells) { this.large.add(entry); return; }
    entry.keys = [];
    for (let x = minX; x <= maxX; x++) for (let z = minZ; z <= maxZ; z++) {
      const key = x + ',' + z; let cell = this.cells.get(key); if (!cell) this.cells.set(key, cell = new Set()); cell.add(entry); entry.keys.push(key);
    }
  }
  query(minX,minZ,maxX,maxZ) {
    const found = new Set();
    const intersects = entry => { const b = entry.bounds; if (b[0] <= maxX && b[2] >= minX && b[1] <= maxZ && b[3] >= minZ) found.add(entry.value); };
    const x0 = Math.floor(minX/this.cellSize), z0 = Math.floor(minZ/this.cellSize), x1 = Math.floor(maxX/this.cellSize), z1 = Math.floor(maxZ/this.cellSize);
    if ((x1-x0+1)*(z1-z0+1) > this.maxCells*4) { for (const entry of this.entries.values()) intersects(entry); }
    else { for (let x=x0;x<=x1;x++) for (let z=z0;z<=z1;z++) for (const entry of this.cells.get(x+','+z)||[]) intersects(entry); for (const entry of this.large) intersects(entry); }
    return [...found];
  }
}
