// Versioned, serializable rendering controls. Profiles never alter scene lighting.
export const RENDER_DEFAULTS = Object.freeze({
  toneMapping: 'agx', environmentIntensity: .65, bloomThreshold: 1.15, bloomRadius: .25,
  renderScale: 1, maxPixelRatio: 1.5, dynamicResolution: false, minRenderScale: .5,
  targetFPS: 60, shadowQuality: 'high', maxShadowLights: 8, shadowUpdate: 'automatic',
  ambientOcclusion: false, aoRadius: .5, aoStrength: 1
});

export const QUALITY_PROFILES = Object.freeze({
  performance: { label: 'Performance', renderScale: .85, maxPixelRatio: 1, dynamicResolution: true, minRenderScale: .5, targetFPS: 60, shadowQuality: 'low', maxShadowLights: 2, bloom: false, ambientOcclusion: false },
  balanced: { label: 'Balanced', renderScale: 1, maxPixelRatio: 1.5, dynamicResolution: true, minRenderScale: .65, targetFPS: 60, shadowQuality: 'medium', maxShadowLights: 4, bloom: true, ambientOcclusion: false },
  cinematic: { label: 'Cinematic', renderScale: 1, maxPixelRatio: 2, dynamicResolution: false, minRenderScale: .5, targetFPS: 60, shadowQuality: 'high', maxShadowLights: 8, bloom: true, ambientOcclusion: true }
});

export function applyQualityProfile(settings, name) {
  if (!Object.hasOwn(QUALITY_PROFILES, name)) throw new Error('Unknown quality profile.');
  const profile = QUALITY_PROFILES[name];
  const { label, ...values } = profile;
  Object.assign(settings, values);
  return label;
}

export function validateRenderSettings(s) {
  for (const [key, min, max] of [
    ['environmentIntensity', 0, 5], ['bloomThreshold', 0, 10], ['bloomRadius', 0, 1],
    ['renderScale', .5, 1.5], ['maxPixelRatio', 1, 2], ['minRenderScale', .5, 1],
    ['targetFPS', 30, 144], ['maxShadowLights', 0, 64], ['aoRadius', .05, 5], ['aoStrength', 0, 2]
  ]) if (!Number.isFinite(s[key]) || s[key] < min || s[key] > max) throw new Error('Invalid ' + key);
  if (typeof s.dynamicResolution !== 'boolean') throw new Error('Invalid dynamic resolution flag.');
  if (typeof s.ambientOcclusion !== 'boolean') throw new Error('Invalid ambient occlusion flag.');
  if (!Number.isInteger(s.maxShadowLights) || !Number.isInteger(s.targetFPS)) throw new Error('Rendering budgets must be integers.');
  if (s.minRenderScale > s.renderScale) throw new Error('Minimum render scale must not exceed render scale.');
  if (!['agx', 'aces', 'neutral'].includes(s.toneMapping)) throw new Error('Invalid tone mapping.');
  if (!['low', 'medium', 'high'].includes(s.shadowQuality)) throw new Error('Invalid shadow quality.');
  if (!['automatic', 'realtime'].includes(s.shadowUpdate)) throw new Error('Invalid shadow update mode.');
}

export function shadowMapSize(quality, point = false) {
  return point ? { low: 256, medium: 512, high: 512 }[quality] : { low: 512, medium: 1024, high: 2048 }[quality];
}

/** Frame-time feedback, not a GPU timer. Slow CPU frames do not trigger downscaling. */
export class AdaptiveResolution {
  constructor() { this.key = ''; this.reset(); }
  reset(scale = 1) { this.scale = scale; this.elapsed = 0; this.samples = 0; this.sum = 0; this.cpuSum = 0; this.fastWindows = 0; }
  configure(s) {
    const key = JSON.stringify([s.renderScale, s.dynamicResolution, s.minRenderScale, s.targetFPS]);
    if (key !== this.key) { this.key = key; this.reset(s.renderScale); }
    this.settings = s;
  }
  update(frameMs, cpuMs) {
    const s = this.settings;
    if (!s?.dynamicResolution || !Number.isFinite(frameMs) || frameMs <= 0 || frameMs > 250 || !Number.isFinite(cpuMs)) return false;
    this.elapsed += frameMs; this.sum += frameMs; this.cpuSum += cpuMs; this.samples++;
    if (this.elapsed < 900 || this.samples < 15) return false;
    const mean = this.sum / this.samples, cpu = this.cpuSum / this.samples, budget = 1000 / s.targetFPS;
    this.elapsed = this.sum = this.cpuSum = this.samples = 0;
    let next = this.scale;
    if (mean > budget * 1.12 && cpu < budget * .8) { next -= .05; this.fastWindows = 0; }
    else if (mean < budget * 1.03) { if (++this.fastWindows >= 3) { next += .05; this.fastWindows = 0; } }
    else this.fastWindows = 0;
    next = Math.max(s.minRenderScale, Math.min(s.renderScale, Math.round(next * 100) / 100));
    const changed = next !== this.scale; this.scale = next; return changed;
  }
}
