#include <blockage/engine.hpp>
#include <fstream>
#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#endif
namespace blockage {
namespace {
struct Beacon {
  bool taken = false;
};
class BeaconRun final : public Game {
  Entity player_, exit_;
  V3 spawn_{};
  unsigned collected_ = 0, total_ = 0, best_ = 0, gem_ = 0;
  float seconds_ = 0;
  bool won_ = false, saveError_ = false;
  std::filesystem::path dir_;
  std::shared_ptr<const Clip> pickup_ = Mixer::tone(660, .15f),
                              finish_ = Mixer::tone(990, .34f);
  void save() {
    auto ms = std::max(1u, unsigned(std::min(86400000.f, seconds_ * 1000)));
    if (best_ && ms >= best_)
      return;
    try {
      std::filesystem::create_directories(dir_);
      auto tmp = dir_ / "best.tmp", dst = dir_ / "best.sav";
      {
        std::ofstream f(tmp);
        f << "BKS1 " << ms << '\n';
        f.close();
        if (!f)
          throw std::runtime_error("save write");
      }
#ifdef _WIN32
      if (!MoveFileExW(tmp.c_str(), dst.c_str(),
                       MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH))
        throw std::runtime_error("save replace");
#else
      std::filesystem::rename(tmp, dst);
#endif
      best_ = ms;
    } catch (const std::exception &) {
      saveError_ = true;
    }
  }
  void restart(Services &s) {
    seconds_ = 0;
    collected_ = 0;
    won_ = false;
    saveError_ = false;
    auto &t = *s.world.pool<Transform>().get(player_);
    t.p = t.prev = spawn_;
    s.world.pool<Body>().get(player_)->velocity = {};
    auto &tags = s.world.pool<Beacon>();
    for (std::size_t i = 0; i < tags.ids().size(); ++i) {
      tags.values()[i].taken = false;
      s.world.set(tags.ids()[i], Surface{gem_, 0x5ff1d7});
    }
  }

public:
  explicit BeaconRun(std::filesystem::path p) : dir_(std::move(p)) {
    std::ifstream f(dir_ / "best.sav");
    std::string tag;
    unsigned n = 0;
    if (f >> tag >> n && tag == "BKS1" && n <= 86400000)
      best_ = n;
  }
  void start(Services &s) override {
    Mesh gem;
    V3 ring[] = {{.55f, 0, 0}, {0, 0, .55f}, {-.55f, 0, 0}, {0, 0, -.55f}};
    for (int side : {-1, 1})
      for (int i = 0; i < 4; ++i) {
        V3 a{0, .8f * side, 0}, b = ring[i], c = ring[(i + 1) % 4];
        auto n = unit(cross(b - a, c - a));
        if (dot(n, a) < 0)
          n = n * -1;
        for (auto p : {a, b, c}) {
          gem.indices.push_back(
              static_cast<std::uint32_t>(gem.vertices.size()));
          gem.vertices.push_back({p, n});
        }
      }
    gem_ = s.meshes.add(std::move(gem));
    auto &ids = s.world.pool<Identity>();
    for (std::size_t i = 0; i < ids.ids().size(); ++i) {
      auto e = ids.ids()[i];
      auto &n = ids.values()[i].name;
      auto &t = *s.world.pool<Transform>().get(e);
      Body b;
      b.half = t.scale * .5f;
      if (n == "PlayerSpawn") {
        if (player_.slot != invalid)
          throw std::runtime_error("duplicate PlayerSpawn");
        player_ = e;
        spawn_ = t.p;
        b.invMass = 1;
        b.friction = 0;
        s.world.set(e, b);
      } else if (n == "Exit" || n.starts_with("Beacon_")) {
        b.sensor = true;
        b.layer = 2;
        b.mask = 1;
        s.world.set(e, b);
        if (n == "Exit") {
          if (exit_.slot != invalid)
            throw std::runtime_error("duplicate Exit");
          exit_ = e;
        } else {
          s.world.set(e, Beacon{});
          ++total_;
        }
      }
    }
    if (player_.slot == invalid || exit_.slot == invalid || !total_)
      throw std::runtime_error(
          "Beacon Run requires PlayerSpawn, Exit and Beacon_*");
    restart(s);
    s.camera.eye = spawn_ + V3{0, 9, -11};
    s.camera.target = spawn_ + V3{0, 0, 2};
  }
  void fixed(Services &s, Input input, float dt) override {
    if (input.restart || s.world.pool<Transform>().get(player_)->p.y < -15)
      restart(s);
    auto &b = *s.world.pool<Body>().get(player_);
    auto move = V3{input.x, 0, input.z};
    if (dot(move, move) > 1)
      move = unit(move);
    b.velocity.x = won_ ? 0 : 5 * move.x;
    b.velocity.z = won_ ? 0 : 5 * move.z;
    if (!won_)
      seconds_ += dt;
  }
  void afterPhysics(Services &s, float) override {
    bool atExit = false;
    if (!won_) {
      for (auto hit : s.physics.contacts()) {
        if (!hit.sensor)
          continue;
        auto e = hit.a == player_ ? hit.b : hit.b == player_ ? hit.a : Entity{};
        if (auto *b = s.world.pool<Beacon>().get(e); b && !b->taken) {
          b->taken = true;
          ++collected_;
          s.world.pool<Surface>().erase(e);
          s.audio.play(pickup_);
        }
        atExit |= e == exit_;
      }
      if (atExit && collected_ == total_) {
        won_ = true;
        s.audio.play(finish_);
        save();
      }
    }
    auto p = s.world.pool<Transform>().get(player_)->p;
    s.camera.target = p + V3{0, 0, 2};
    s.camera.eye = p + V3{0, 9, -11};
  }
  std::string title() const override {
    return std::string(won_ ? "FINISH!" : "Beacon Run") + " | " +
           std::to_string(collected_) + "/" + std::to_string(total_) + " | " +
           std::to_string(int(seconds_)) + " s | best " +
           std::to_string(best_) + " ms" +
           (saveError_ ? " | save failed" : "") +
           " | WASD / ZQSD / arrows | R restart | Esc quit";
  }
};
} // namespace
std::unique_ptr<Game> makeGame(const std::filesystem::path &p) {
  return std::make_unique<BeaconRun>(p);
}
} // namespace blockage
