#include <blockage/engine.hpp>
#include <chrono>
#include <cstring>
#include <fstream>
#include <iostream>
using namespace blockage;
namespace fs = std::filesystem;
namespace {
void require(bool ok, const char *msg) {
  if (!ok)
    throw std::runtime_error(msg);
}
template <class F> void reject(F f) {
  try {
    f();
  } catch (const std::exception &) {
    return;
  }
  throw std::runtime_error("unsafe input accepted");
}
unsigned groups = 0;
template <class F> void test(const char *name, F f) {
  f();
  ++groups;
  std::cout << "PASS " << name << '\n';
}
Entity box(World &w, V3 p, V3 half, float mass, bool sensor = false) {
  auto e = w.create();
  w.set(e, Transform{p, p, half * 2});
  Body b;
  b.half = half;
  b.invMass = mass;
  b.sensor = sensor;
  w.set(e, b);
  return e;
}
void ecs() {
  struct Health {
    int hp;
  };
  World w;
  auto a = w.create(), b = w.create(), c = w.create();
  w.set(a, Health{1});
  w.set(b, Health{2});
  w.set(c, Health{3});
  w.destroy(b);
  auto d = w.create();
  auto &hp = w.pool<Health>();
  require(d.slot == b.slot && d.generation != b.generation && !w.alive(b) &&
              !hp.get(b) && !hp.get(d) && hp.get(c)->hp == 3,
          "generation or swap erase");
  reject([&] { w.set(b, Health{4}); });
  w.set(d, Health{4});
  int sum = 0;
  for (auto v : hp.values())
    sum += v.hp;
  require(sum == 8, "custom component");
}
void clockTest() {
  Clock c;
  int n = 0;
  auto count = [&](float) { ++n; };
  c.advance(Clock::dt / 2, count);
  require(n == 0 && std::abs(c.alpha() - .5f) < .001, "interpolation");
  c.advance(Clock::dt / 2, count);
  require(n == 1, "fixed tick");
  require(c.advance(1, count) == 8 && c.dropped > .8 && c.alpha() < 1,
          "catchup");
  c.advance(NAN, count);
  require(n == 9, "NaN clock");
}
void physics() {
  World w;
  Physics p;
  box(w, {0, -.5f, 0}, {5, .5f, 5}, 0);
  auto player = box(w, {0, 2, 0}, {.5f, .5f, .5f}, 1);
  for (int i = 0; i < 240; ++i)
    p.step(w, 1.f / 60);
  require(std::abs(w.pool<Transform>().get(player)->p.y - .5f) < .001f,
          "floor");
  auto target = box(w, {0, .6f, 0}, {.4f, .4f, .4f}, 0, true);
  p.step(w, 1.f / 60);
  auto found = [&] {
    return std::any_of(p.contacts().begin(), p.contacts().end(), [&](auto c) {
      return c.sensor && (c.a == target || c.b == target);
    });
  };
  require(found(), "sensor");
  w.pool<Body>().get(target)->mask = 0;
  p.step(w, 1.f / 60);
  require(!found(), "layer filter");
}
void sweep(bool bench) {
  World w;
  Physics p;
  p.gravity = {};
  for (int i = 0; i < 4096; ++i)
    box(w, {0, 0, 3.f * i}, {.5f, .5f, .5f}, 1);
  std::vector<double> samples;
  for (int i = 0; i < (bench ? 210 : 2); ++i) {
    auto start = std::chrono::steady_clock::now();
    p.step(w, 1.f / 60);
    if (i >= 10)
      samples.push_back(std::chrono::duration<double, std::milli>(
                            std::chrono::steady_clock::now() - start)
                            .count());
  }
  require(p.candidates == 0 && p.contacts().empty(), "sweep pruning");
  if (bench) {
    std::sort(samples.begin(), samples.end());
    std::cout << "BENCH 4096 distant bodies, 200 samples: p50_ms="
              << samples[99] << " p95_ms=" << samples[189]
              << " candidates=0 all_pairs=8386560\n";
  }
}
void media() {
  Mixer m;
  std::array<std::int16_t, 1024> out{};
  auto c = Mixer::tone(440, .01f);
  for (int i = 0; i < 32; ++i)
    require(m.play(c), "voice");
  require(!m.play(c), "voice cap");
  m.mix(out);
  require(std::any_of(out.begin(), out.end(),
                      [](auto u) { return std::abs(int(u)) > 1000; }),
          "audible mix");
  m.mix(out);
  require(std::all_of(out.begin(), out.end(), [](auto u) { return u == 0; }),
          "silence");
  require(m.play(c), "recycle");
  MeshBank bank;
  Mesh bad;
  reject([&] { bank.add(bad); });
  World w;
  auto e = w.create();
  w.set(e, Transform{{0, 0, 4}, {0, 0, 2}});
  w.set(e, Surface{});
  auto off = w.create();
  w.set(off, Transform{{100, 0, 3}, {100, 0, 3}});
  w.set(off, Surface{});
  Camera cam;
  cam.eye = {};
  cam.target = {0, 0, 1};
  DrawList draw;
  draw.gather(w, bank, cam, 1, .5);
  require(draw.batches[0].size() == 1 && draw.batches[0][0].p.z == 3,
          "cull/interpolate");
}
void codec(const fs::path &src) {
  auto scene = load(src);
  auto b = encode(scene);
  std::ifstream f(src, std::ios::binary);
  std::vector<char> bytes((std::istreambuf_iterator<char>(f)), {});
  require(bytes.size() == b.size() &&
              !std::memcmp(bytes.data(), b.data(), bytes.size()),
          "JS to C++ byte parity");
  auto broken = b;
  broken.back() ^= 1;
  reject([&] { decode(broken); });
  for (std::size_t i = 0; i < b.size(); i += 31)
    reject([&] { decode(std::span(b).first(i)); });
  scene.push_back(scene.front());
  reject([&] { encode(scene); });
  scene.pop_back();
  scene.front().transform.scale.x = NAN;
  reject([&] { encode(scene); });
}
void config(const fs::path &dir) {
  auto p = dir / "options.cfg";
  {
    std::ofstream o(p);
    o << "width=1600\nvolume=75\n";
  }
  auto s = readConfig(p);
  require(s.width == 1600 && s.volume == .75f, "settings");
  for (auto text :
       {"width=99", "width=600\nwidth=700", "game_id=../bad", "vsync=4"}) {
    {
      std::ofstream o(p);
      o << text;
    }
    reject([&] { readConfig(p); });
  }
}
void game(const fs::path &src, const fs::path &dir) {
  auto w = instantiate(load(src));
  Services s{w};
  auto g = makeGame(dir);
  g->start(s);
  auto &id = w.pool<Identity>();
  auto find = [&](std::string n) {
    for (std::size_t i = 0; i < id.ids().size(); ++i)
      if (id.values()[i].name == n)
        return id.ids()[i];
    throw std::runtime_error("missing fixture");
  };
  auto player = find("PlayerSpawn");
  require(s.meshes.size() > 4, "custom gameplay geometry");
  for (auto name : {"Beacon_1", "Beacon_2", "Beacon_3", "Exit"}) {
    auto target = w.pool<Transform>().get(find(name))->p;
    for (int i = 0; i < 400; ++i) {
      auto d = target - w.pool<Transform>().get(player)->p;
      d.y = 0;
      if (dot(d, d) < .008f)
        break;
      auto v = unit(d);
      tick(s, *g, {v.x, v.z}, float(Clock::dt));
      if (g->title().starts_with("FINISH!"))
        break;
    }
  }
  require(g->title().starts_with("FINISH!") &&
              fs::file_size(dir / "best.sav") > 4,
          "win/record");
  tick(s, *g, {0, 0, true}, float(Clock::dt));
  require(g->title().find("0/3") != std::string::npos, "restart");
}
} // namespace
int main(int argc, char **argv) {
  try {
    if (argc < 3)
      throw std::invalid_argument("sample + test profile required");
    fs::path src = argv[1], dir = argv[2];
    fs::create_directories(dir);
    test("generational ECS", ecs);
    test("bounded tick", clockTest);
    test("AABB and sensors", physics);
    test("adaptive sweep", [&] { sweep(argc > 3); });
    test("audio and render batching", media);
    test("native OBJ and invalid geometry", [&] {
      const auto path = dir / "fixture.obj";
      {
        std::ofstream o(path);
        o << "v 0 0 0\nv 1 0 0\nv 0 1 0\nvn 0 0 1\nf -3//1 -2//1 -1//1\n";
      }
      MeshBank bank;
      auto m = loadTriangleOBJ(path);
      require(m.indices.size() == 3 && bank.add(m) == 4,
              "real triangle geometry");
      m.indices[1] = 20;
      reject([&] { bank.add(m); });
      {
        std::ofstream o(path, std::ios::app);
        o << "f 1 2 7\n";
      }
      reject([&] { loadTriangleOBJ(path); });
    });
    test("physics saturation reports rather than growing indefinitely", [] {
      World w;
      Physics p;
      p.maxContacts = 0;
      box(w, {}, {1, 1, 1}, 0, true);
      box(w, {}, {1, 1, 1}, 1);
      reject([&] { p.step(w, 1.f / 60); });
    });
    test("scene codecs", [&] { codec(src); });
    test("config", [&] { config(dir); });
    test("game win + save + restart", [&] { game(src, dir); });
    std::cout << groups << " native groups passed\n";
  } catch (const std::exception &e) {
    std::cerr << "FAIL " << e.what() << '\n';
    return 1;
  }
}
