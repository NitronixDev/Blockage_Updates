#pragma once
#include <cstdint>
#include <memory>
#include <span>
#include <stdexcept>
#include <type_traits>
#include <typeindex>
#include <unordered_map>
#include <utility>
#include <vector>
namespace blockage {
constexpr std::uint32_t invalid = UINT32_MAX;
struct Entity {
  std::uint32_t slot = invalid, generation = 0;
  friend bool operator==(Entity, Entity) = default;
};
struct PoolBase {
  virtual ~PoolBase() = default;
  virtual void erase(Entity) = 0;
};
class World;
template <class T> class Pool final : public PoolBase {
  friend class World;
  static_assert(std::is_nothrow_move_constructible_v<T> &&
                std::is_nothrow_move_assignable_v<T>);
  std::vector<T> dense_;
  std::vector<Entity> ids_;
  std::vector<std::uint32_t> sparse_;
  T &set(Entity e, T value) {
    if (auto *p = get(e)) {
      *p = std::move(value);
      return *p;
    }
    if (sparse_.size() <= e.slot)
      sparse_.resize(std::size_t(e.slot) + 1, invalid);
    ids_.push_back(e);
    try {
      dense_.push_back(std::move(value));
    } catch (...) {
      ids_.pop_back();
      throw;
    }
    sparse_[e.slot] = static_cast<std::uint32_t>(ids_.size() - 1);
    return dense_.back();
  }

public:
  void reserve(std::size_t n) {
    dense_.reserve(n);
    ids_.reserve(n);
    sparse_.reserve(n);
  }
  std::span<T> values() { return dense_; }
  std::span<const Entity> ids() const { return ids_; }
  T *get(Entity e) {
    if (e.slot >= sparse_.size())
      return nullptr;
    auto n = sparse_[e.slot];
    return n < ids_.size() && ids_[n] == e ? &dense_[n] : nullptr;
  }
  void erase(Entity e) override {
    if (!get(e))
      return;
    auto i = sparse_[e.slot];
    if (i + 1 != dense_.size()) {
      dense_[i] = std::move(dense_.back());
      ids_[i] = ids_.back();
      sparse_[ids_[i].slot] = i;
    }
    dense_.pop_back();
    ids_.pop_back();
    sparse_[e.slot] = invalid;
  }
};
class World {
  struct Slot {
    std::uint32_t generation = 1, next = invalid;
    bool live = true;
  };
  std::vector<Slot> slots_;
  std::uint32_t free_ = invalid;
  std::unordered_map<std::type_index, std::unique_ptr<PoolBase>> pools_;

public:
  bool alive(Entity e) const {
    return e.slot < slots_.size() && slots_[e.slot].live &&
           slots_[e.slot].generation == e.generation;
  }
  Entity create() {
    if (free_ != invalid) {
      auto i = free_;
      auto &s = slots_[i];
      free_ = s.next;
      s.live = true;
      return {i, s.generation};
    }
    if (slots_.size() >= invalid)
      throw std::length_error("entity capacity");
    slots_.emplace_back();
    return {static_cast<std::uint32_t>(slots_.size() - 1), 1};
  }
  void destroy(Entity e) {
    if (!alive(e))
      return;
    for (auto &[_, p] : pools_)
      p->erase(e);
    auto &s = slots_[e.slot];
    s.live = false;
    if (s.generation != UINT32_MAX) {
      ++s.generation;
      s.next = free_;
      free_ = e.slot;
    }
  }
  template <class T> Pool<T> &pool() {
    std::type_index k = typeid(T);
    auto it = pools_.find(k);
    if (it == pools_.end())
      it = pools_.emplace(k, std::make_unique<Pool<T>>()).first;
    return static_cast<Pool<T> &>(*it->second);
  }
  template <class T> T &set(Entity e, T value) {
    if (!alive(e))
      throw std::invalid_argument("stale entity");
    return pool<T>().set(e, std::move(value));
  }
};
} // namespace blockage
