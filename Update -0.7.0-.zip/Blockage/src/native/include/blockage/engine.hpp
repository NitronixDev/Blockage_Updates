#pragma once
#include "ecs.hpp"
#include <algorithm>
#include <array>
#include <cmath>
#include <filesystem>
#include <string>
namespace blockage {
struct V3 {
  float x{}, y{}, z{};
};
constexpr V3 operator+(V3 a, V3 b) { return {a.x + b.x, a.y + b.y, a.z + b.z}; }
constexpr V3 operator-(V3 a, V3 b) { return {a.x - b.x, a.y - b.y, a.z - b.z}; }
constexpr V3 operator*(V3 a, float n) { return {a.x * n, a.y * n, a.z * n}; }
constexpr float dot(V3 a, V3 b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
constexpr V3 cross(V3 a, V3 b) {
  return {a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x};
}
inline V3 unit(V3 v) {
  auto n = std::sqrt(dot(v, v));
  return n > 1e-8f ? v * (1 / n) : V3{};
}
struct Transform {
  V3 p{}, prev{}, scale{1, 1, 1}, rot{};
};
struct Identity {
  std::string id, name;
};
struct Surface {
  std::uint32_t mesh = 0, rgb = 0xffffff;
};
struct Body {
  V3 half{.5f, .5f, .5f}, velocity{};
  float invMass = 0, bounce = 0, friction = .5f;
  bool sensor = false;
  std::uint32_t layer = 1, mask = UINT32_MAX;
};
struct Contact {
  Entity a, b;
  bool sensor;
};
class Physics {
  struct Proxy {
    Entity e;
    Transform *t;
    Body *b;
    V3 lo, hi;
  };
  std::vector<Proxy> proxies_;
  std::vector<Contact> hits_;

public:
  V3 gravity{0, -9.81f, 0};
  std::size_t candidates = 0;
  std::size_t maxPairVisits = 2000000, maxContacts = 65536;
  void step(World &, float);
  std::span<const Contact> contacts() const { return hits_; }
};
struct Camera {
  V3 eye{0, 8, -10}, target{};
  float fov = .92f, nearZ = .1f, farZ = 400;
};
struct Vertex {
  V3 p, n;
};
struct Mesh {
  std::vector<Vertex> vertices;
  std::vector<std::uint32_t> indices;
};
Mesh loadTriangleOBJ(const std::filesystem::path &);
class MeshBank {
  struct Asset {
    Mesh data;
    float radius;
  };
  std::vector<Asset> assets_;

public:
  MeshBank();
  std::uint32_t add(Mesh);
  const Mesh &get(std::uint32_t i) const { return assets_.at(i).data; }
  float radius(std::uint32_t i) const { return assets_.at(i).radius; }
  std::size_t size() const { return assets_.size(); }
};
struct Instance {
  V3 p, scale, rot;
  std::uint32_t rgb;
};
struct DrawList {
  std::vector<std::vector<Instance>> batches;
  void gather(World &, const MeshBank &, const Camera &, float aspect,
              float alpha);
};
struct Clip {
  std::vector<float> mono;
};
class Mixer {
  struct Voice {
    std::shared_ptr<const Clip> sound;
    std::size_t frame = 0;
    float gain = 1;
  };
  std::array<Voice, 32> voices_{};

public:
  static constexpr unsigned rate = 48000;
  float volume = .35f;
  static std::shared_ptr<const Clip> tone(float hz, float seconds);
  bool play(std::shared_ptr<const Clip>, float gain = 1);
  void mix(std::span<std::int16_t>);
};
struct Record {
  Identity identity;
  Transform transform;
  Surface surface;
  bool visible = true, collider = false;
};
using Scene = std::vector<Record>;
std::vector<std::uint8_t> encode(const Scene &);
Scene decode(std::span<const std::uint8_t>);
Scene load(const std::filesystem::path &);
World instantiate(const Scene &);
struct Config {
  unsigned width = 1280, height = 720;
  bool vsync = true;
  float volume = .35f;
  std::string id = "beacon-run";
};
Config readConfig(const std::filesystem::path &, Config = {},
                  bool user = false);
struct Input {
  float x{}, z{};
  bool restart = false;
};
struct Services {
  World &world;
  Physics physics;
  MeshBank meshes;
  Mixer audio;
  Camera camera;
  std::filesystem::path content;
};
class Game {
public:
  virtual ~Game() = default;
  virtual void start(Services &) = 0;
  virtual void fixed(Services &, Input, float) = 0;
  virtual void afterPhysics(Services &, float) {}
  virtual std::string title() const = 0;
};
std::unique_ptr<Game> makeGame(const std::filesystem::path &userDirectory);
inline void tick(Services &s, Game &g, Input in, float dt) {
  for (auto &t : s.world.pool<Transform>().values())
    t.prev = t.p;
  g.fixed(s, in, dt);
  s.physics.step(s.world, dt);
  g.afterPhysics(s, dt);
}
class Clock {
  double acc_ = 0;

public:
  static constexpr double dt = 1. / 60;
  double dropped = 0;
  float alpha() const { return float(acc_ / dt); }
  template <class F> unsigned advance(double t, F f) {
    if (!std::isfinite(t) || t <= 0)
      return 0;
    dropped += std::max(0., t - .25);
    acc_ += std::min(t, .25);
    unsigned n = 0;
    while (acc_ + 1e-12 >= dt && n < 8) {
      f(float(dt));
      acc_ = std::max(0., acc_ - dt);
      ++n;
    }
    if (acc_ >= dt) {
      double r = std::fmod(acc_, dt);
      dropped += acc_ - r;
      acc_ = r;
    }
    return n;
  }
};
int windowLoop(Services &, Game &, const Config &, bool smoke);
} // namespace blockage
