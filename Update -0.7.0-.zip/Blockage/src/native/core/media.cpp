#include <blockage/engine.hpp>
#include <numbers>
namespace blockage {
std::uint32_t MeshBank::add(Mesh g) {
  if (assets_.size() >= 2048 || g.vertices.empty() ||
      g.vertices.size() > 1000000 || g.indices.empty() ||
      g.indices.size() % 3 || g.indices.size() > 3000000)
    throw std::invalid_argument("mesh bounds or topology");
  float radius = 0;
  for (auto &v : g.vertices) {
    for (float f : {v.p.x, v.p.y, v.p.z, v.n.x, v.n.y, v.n.z})
      if (!std::isfinite(f) || std::abs(f) > 100000)
        throw std::invalid_argument("invalid vertex");
    if (dot(v.n, v.n) < 1e-12f)
      throw std::invalid_argument("invalid normal");
    v.n = unit(v.n);
    radius = std::max(radius, dot(v.p, v.p));
  }
  for (auto i : g.indices)
    if (i >= g.vertices.size())
      throw std::invalid_argument("mesh index outside geometry");
  assets_.push_back({std::move(g), std::sqrt(radius)});
  return static_cast<std::uint32_t>(assets_.size() - 1);
}
MeshBank::MeshBank() {
  auto quad = [](Mesh &m, V3 a, V3 b, V3 c, V3 d, V3 n) {
    auto i = static_cast<std::uint32_t>(m.vertices.size());
    for (auto p : {a, b, c, d})
      m.vertices.push_back({p, n});
    for (int k : {0, 1, 2, 0, 2, 3})
      m.indices.push_back(i + k);
  };
  Mesh cube;
  for (int axis = 0; axis < 3; ++axis)
    for (int sign : {-1, 1}) {
      V3 n{}, u{}, v{};
      if (!axis) {
        n.x = float(sign);
        u.y = .5f;
        v.z = .5f;
      } else if (axis == 1) {
        n.y = float(sign);
        u.z = .5f;
        v.x = .5f;
      } else {
        n.z = float(sign);
        u.x = .5f;
        v.y = .5f;
      }
      auto p = n * .5f;
      quad(cube, p - u - v, p + u - v, p + u + v, p - u + v, n);
    }
  add(std::move(cube));
  const float pi = std::numbers::pi_v<float>;
  for (bool round : {true, false}) {
    Mesh m;
    int rings = round ? 16 : 1, N = 32;
    for (int y = 0; y <= rings; ++y)
      for (int x = 0; x <= N; ++x) {
        float a = 2 * pi * x / N, b = pi * y / rings;
        V3 n = round ? V3{std::sin(b) * std::cos(a), std::cos(b),
                          std::sin(b) * std::sin(a)}
                     : V3{std::cos(a), 0, std::sin(a)};
        auto p = n * .5f;
        if (!round)
          p.y = y ? -.5f : .5f;
        m.vertices.push_back({p, n});
      }
    for (int y = 0; y < rings; ++y)
      for (int x = 0; x < N; ++x) {
        int a = y * (N + 1) + x, b = a + N + 1;
        for (int j : {a, b, a + 1, b, b + 1, a + 1})
          m.indices.push_back(j);
      }
    if (!round)
      for (int side : {-1, 1}) {
        auto base = static_cast<std::uint32_t>(m.vertices.size());
        V3 n{0, float(side), 0};
        m.vertices.push_back({n * .5f, n});
        for (int x = 0; x <= N; ++x) {
          float a = 2 * pi * x / N;
          m.vertices.push_back(
              {{.5f * std::cos(a), side * .5f, .5f * std::sin(a)}, n});
          if (x)
            for (int j : {0, x, x + 1})
              m.indices.push_back(base + j);
        }
      }
    add(std::move(m));
  }
  Mesh plane;
  quad(plane, {-.5f, 0, -.5f}, {-.5f, 0, .5f}, {.5f, 0, .5f}, {.5f, 0, -.5f},
       {0, 1, 0});
  add(std::move(plane));
}
void DrawList::gather(World &w, const MeshBank &meshes, const Camera &cam,
                      float aspect, float alpha) {
  batches.resize(meshes.size());
  for (auto &b : batches)
    b.clear();
  auto f = unit(cam.target - cam.eye), right = unit(cross({0, 1, 0}, f)),
       up = cross(f, right);
  auto ty = std::tan(cam.fov * .5f), tx = ty * aspect;
  auto &surfaces = w.pool<Surface>();
  auto &transforms = w.pool<Transform>();
  for (std::size_t i = 0; i < surfaces.ids().size(); ++i) {
    auto &s = surfaces.values()[i];
    auto *t = transforms.get(surfaces.ids()[i]);
    if (!t)
      continue;
    auto p = t->prev + (t->p - t->prev) * std::clamp(alpha, 0.f, 1.f),
         d = p - cam.eye;
    float z = dot(d, f),
          r = meshes.radius(s.mesh) *
              std::max({std::abs(t->scale.x), std::abs(t->scale.y),
                        std::abs(t->scale.z)});
    if (z + r < cam.nearZ || z - r > cam.farZ ||
        std::abs(dot(d, right)) > z * tx + r * std::sqrt(1 + tx * tx) ||
        std::abs(dot(d, up)) > z * ty + r * std::sqrt(1 + ty * ty))
      continue;
    batches[s.mesh].push_back({p, t->scale, t->rot, s.rgb});
  }
}
std::shared_ptr<const Clip> Mixer::tone(float hz, float seconds) {
  if (!(hz >= 20 && hz < rate * .5f && seconds > 0 && seconds <= 10))
    throw std::invalid_argument("invalid tone");
  auto c = std::make_shared<Clip>();
  c->mono.resize(std::max(1u, unsigned(rate * seconds)));
  for (std::size_t i = 0; i < c->mono.size(); ++i) {
    float t = float(i) / rate;
    c->mono[i] = std::sin(2 * std::numbers::pi_v<float> * hz * t) *
                 std::min(1.f, t * 180) * std::min(1.f, (seconds - t) * 25);
  }
  return c;
}
bool Mixer::play(std::shared_ptr<const Clip> clip, float gain) {
  if (!clip || clip->mono.empty() || !std::isfinite(gain))
    return false;
  for (auto &v : voices_)
    if (!v.sound) {
      v = {std::move(clip), 0, std::clamp(gain, 0.f, 1.f)};
      return true;
    }
  return false;
}
void Mixer::mix(std::span<std::int16_t> out) {
  std::array<float, 512> tmp{};
  while (!out.empty()) {
    auto n = std::min(out.size(), tmp.size());
    std::fill_n(tmp.begin(), n, 0.f);
    for (auto &v : voices_)
      if (v.sound) {
        auto k = std::min(n, v.sound->mono.size() - v.frame);
        for (std::size_t i = 0; i < k; ++i)
          tmp[i] += v.sound->mono[v.frame + i] * v.gain;
        v.frame += k;
        if (v.frame == v.sound->mono.size())
          v.sound.reset();
      }
    for (std::size_t i = 0; i < n; ++i) {
      float x = tmp[i] * volume;
      out[i] = std::isfinite(x)
                   ? static_cast<std::int16_t>(32767 * std::clamp(x, -1.f, 1.f))
                   : 0;
    }
    out = out.subspan(n);
  }
}
} // namespace blockage
