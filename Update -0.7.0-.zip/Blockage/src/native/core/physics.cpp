#include <blockage/engine.hpp>
namespace blockage {
void Physics::step(World &w, float dt) {
  if (!(dt > 0 && dt <= .25f))
    throw std::invalid_argument("invalid fixed step");
  auto &bodies = w.pool<Body>();
  auto &transforms = w.pool<Transform>();
  hits_.clear();
  proxies_.clear();
  proxies_.reserve(bodies.ids().size());
  candidates = 0;
  V3 lo{}, hi{};
  for (std::size_t i = 0; i < bodies.ids().size(); ++i) {
    Entity e = bodies.ids()[i];
    auto *t = transforms.get(e);
    if (!t)
      continue;
    auto &b = bodies.values()[i];
    if (b.invMass > 0) {
      b.velocity = b.velocity + gravity * dt;
      t->p = t->p + b.velocity * dt;
    }
    if (proxies_.empty())
      lo = hi = t->p;
    else {
      lo = {std::min(lo.x, t->p.x), std::min(lo.y, t->p.y),
            std::min(lo.z, t->p.z)};
      hi = {std::max(hi.x, t->p.x), std::max(hi.y, t->p.y),
            std::max(hi.z, t->p.z)};
    }
    proxies_.push_back({e, t, &b, t->p - b.half, t->p + b.half});
  }
  auto span = hi - lo;
  float V3::*axis = span.x >= span.y && span.x >= span.z ? &V3::x
                    : span.y >= span.z                   ? &V3::y
                                                         : &V3::z;
  std::sort(proxies_.begin(), proxies_.end(),
            [axis](const auto &a, const auto &b) {
              return a.lo.*axis == b.lo.*axis ? a.e.slot < b.e.slot
                                              : a.lo.*axis < b.lo.*axis;
            });
  std::size_t visited = 0;
  for (std::size_t i = 0; i < proxies_.size(); ++i)
    for (std::size_t j = i + 1;
         j < proxies_.size() && proxies_[j].lo.*axis <= proxies_[i].hi.*axis;
         ++j) {
      if (++visited > maxPairVisits)
        throw std::length_error(
            "physics pair budget exceeded; split the active collision world");
      auto &a = proxies_[i];
      auto &b = proxies_[j];
      float mass = a.b->invMass + b.b->invMass;
      bool sensor = a.b->sensor || b.b->sensor;
      if (!(a.b->layer & b.b->mask) || !(b.b->layer & a.b->mask) ||
          (!sensor && mass == 0))
        continue;
      ++candidates;
      V3 d = b.t->p - a.t->p, half = a.b->half + b.b->half,
         pen{half.x - std::abs(d.x), half.y - std::abs(d.y),
             half.z - std::abs(d.z)};
      if (std::min({pen.x, pen.y, pen.z}) <= 0)
        continue;
      if (hits_.size() >= maxContacts)
        throw std::length_error("physics contact budget exceeded");
      hits_.push_back({a.e, b.e, sensor});
      if (sensor)
        continue;
      float V3::*k = pen.x <= pen.y && pen.x <= pen.z ? &V3::x
                     : pen.y <= pen.z                 ? &V3::y
                                                      : &V3::z;
      V3 n{};
      n.*k = d.*k < 0 ? -1.f : 1.f;
      float depth = pen.*k;
      a.t->p = a.t->p - n * (depth * a.b->invMass / mass);
      b.t->p = b.t->p + n * (depth * b.b->invMass / mass);
      auto v = b.b->velocity - a.b->velocity;
      float vn = dot(v, n);
      if (vn >= 0)
        continue;
      float impulse = -(1 + std::min(a.b->bounce, b.b->bounce)) * vn / mass;
      auto tangent = unit(v - n * vn);
      auto change =
          n * impulse -
          tangent * std::min(std::sqrt(a.b->friction * b.b->friction) * impulse,
                             std::abs(dot(v, tangent)) / mass);
      a.b->velocity = a.b->velocity - change * a.b->invMass;
      b.b->velocity = b.b->velocity + change * b.b->invMass;
    }
}
} // namespace blockage
