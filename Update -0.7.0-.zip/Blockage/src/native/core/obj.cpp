#include <blockage/engine.hpp>
#include <charconv>
#include <fstream>
#include <sstream>
namespace blockage {
// Deliberately narrow: triangles, positions, optional explicit normals. Refuses
// materials/UVs rather than silently displaying the wrong imported material.
Mesh loadTriangleOBJ(const std::filesystem::path &path) {
  if (std::filesystem::file_size(path) > 32 * 1024 * 1024)
    throw std::length_error("OBJ exceeds 32 MiB");
  std::ifstream f(path);
  if (!f)
    throw std::runtime_error("cannot open OBJ");
  std::vector<V3> pos, norm;
  Mesh mesh;
  unsigned lineNo = 0;
  std::string line;
  auto index = [](std::string_view t, std::size_t n) {
    int v{};
    auto [p, ec] = std::from_chars(t.data(), t.data() + t.size(), v);
    if (ec != std::errc{} || p != t.data() + t.size() || v == 0)
      throw std::invalid_argument("invalid face index");
    long long i = v > 0 ? v - 1 : static_cast<long long>(n) + v;
    if (i < 0 || static_cast<std::size_t>(i) >= n)
      throw std::out_of_range("face index out of bounds");
    return static_cast<std::size_t>(i);
  };
  try {
    while (std::getline(f, line)) {
      ++lineNo;
      if (line.size() > 8192)
        throw std::length_error("line too long");
      auto c = line.find('#');
      if (c != line.npos)
        line.resize(c);
      std::istringstream in(line);
      std::string op;
      if (!(in >> op))
        continue;
      if (op == "v" || op == "vn") {
        V3 v;
        std::string extra;
        if (!(in >> v.x >> v.y >> v.z) || in >> extra)
          throw std::invalid_argument("expected xyz");
        for (float n : {v.x, v.y, v.z})
          if (!std::isfinite(n) || std::abs(n) > 100000)
            throw std::invalid_argument("invalid component");
        auto &a = op == "v" ? pos : norm;
        if (a.size() >= 1000000)
          throw std::length_error("vertex budget");
        a.push_back(v);
      } else if (op == "f") {
        Vertex tri[3]{};
        bool given[3]{};
        for (int i = 0; i < 3; ++i) {
          std::string ref;
          if (!(in >> ref))
            throw std::invalid_argument("expected triangle");
          std::string_view view = ref;
          auto slash = view.find('/');
          tri[i].p = pos[index(view.substr(0, slash), pos.size())];
          if (slash != view.npos) {
            if (view.substr(slash, 2) != "//")
              throw std::invalid_argument("expected v or v//vn");
            tri[i].n = norm[index(view.substr(slash + 2), norm.size())];
            given[i] = true;
          }
        }
        std::string extra;
        if (in >> extra)
          throw std::invalid_argument("triangulate polygon first");
        auto normal = unit(cross(tri[1].p - tri[0].p, tri[2].p - tri[0].p));
        if (dot(normal, normal) < .5f || mesh.vertices.size() + 3 > 1000000)
          throw std::invalid_argument("degenerate triangle or vertex budget");
        for (int i = 0; i < 3; ++i) {
          if (!given[i])
            tri[i].n = normal;
          mesh.indices.push_back(
              static_cast<std::uint32_t>(mesh.vertices.size()));
          mesh.vertices.push_back(tri[i]);
        }
      } else if (op != "o" && op != "g" && op != "s")
        throw std::invalid_argument("unsupported directive: " + op);
    }
  } catch (const std::exception &e) {
    throw std::runtime_error("OBJ line " + std::to_string(lineNo) + ": " +
                             e.what());
  }
  if (f.bad() || mesh.indices.empty())
    throw std::runtime_error("empty or unreadable OBJ");
  return mesh;
}
} // namespace blockage
