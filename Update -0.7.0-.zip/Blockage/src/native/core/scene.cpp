#include <bit>
#include <blockage/engine.hpp>
#include <charconv>
#include <cstring>
#include <fstream>
#include <unordered_set>
namespace blockage {
namespace {
void need(bool ok, const char *message) {
  if (!ok)
    throw std::runtime_error(message);
}
constexpr std::size_t limit = 8u << 20;
auto read(const std::filesystem::path &path, std::size_t max) {
  std::ifstream f(path, std::ios::binary | std::ios::ate);
  need(bool(f), "cannot open content");
  auto n = f.tellg();
  need(n >= 0 && std::uintmax_t(n) <= max, "invalid content size");
  std::vector<std::uint8_t> b(static_cast<std::size_t>(n));
  f.seekg(0);
  if (!b.empty())
    f.read(reinterpret_cast<char *>(b.data()), n);
  need(bool(f), "short read");
  return b;
}
std::uint32_t crc(std::span<const std::uint8_t> b) {
  std::uint32_t c = ~0u;
  for (auto x : b) {
    c ^= x;
    for (int i = 0; i < 8; ++i)
      c = (c >> 1) ^ ((0u - (c & 1u)) & 0xedb88320u);
  }
  return ~c;
}
void put(std::vector<std::uint8_t> &b, std::uint32_t x, int n = 4) {
  for (int i = 0; i < n; ++i)
    b.push_back(static_cast<std::uint8_t>(x >> (i * 8)));
}
struct Read {
  std::span<const std::uint8_t> b;
  std::size_t at = 0;
  auto take(std::size_t n) {
    need(n <= b.size() - at, "truncated scene");
    auto s = b.subspan(at, n);
    at += n;
    return s;
  }
  std::uint32_t number(int n = 4) {
    auto s = take(n);
    std::uint32_t x = 0;
    for (int i = 0; i < n; ++i)
      x |= std::uint32_t(s[i]) << (i * 8);
    return x;
  }
  std::string text(std::size_t n) {
    need(n > 0 && n <= 800, "invalid identity length");
    auto s = take(n);
    return {reinterpret_cast<const char *>(s.data()), n};
  }
  V3 vec() {
    return {std::bit_cast<float>(number()), std::bit_cast<float>(number()),
            std::bit_cast<float>(number())};
  }
};
void valid(const Record &o) {
  for (auto *s : {&o.identity.id, &o.identity.name})
    need(!s->empty() && s->size() <= 800 && s->find('\0') == s->npos,
         "invalid identity");
  need(o.surface.mesh < 4 && o.surface.rgb <= 0xffffff,
       "invalid native primitive");
  for (auto v : {o.transform.p, o.transform.rot, o.transform.scale})
    for (float x : {v.x, v.y, v.z})
      need(std::isfinite(x) && std::abs(x) <= 100000, "invalid transform");
  for (float x :
       {o.transform.scale.x, o.transform.scale.y, o.transform.scale.z})
    need(x > 0 && x <= 10000, "invalid scale");
  if (o.collider)
    need(o.surface.mesh == 0 && dot(o.transform.rot, o.transform.rot) == 0,
         "native v1 colliders require unrotated boxes");
}
} // namespace
std::vector<std::uint8_t> encode(const Scene &scene) {
  need(scene.size() <= 20000, "too many entities");
  std::vector<std::uint8_t> b{'B', 'N', 'S', '1'};
  put(b, 1);
  put(b, static_cast<std::uint32_t>(scene.size()));
  put(b, 0);
  std::unordered_set<std::string> ids;
  for (auto &o : scene) {
    valid(o);
    need(ids.insert(o.identity.id).second, "duplicate id");
    const auto &a = o.identity.id;
    const auto &n = o.identity.name;
    put(b, a.size(), 2);
    put(b, n.size(), 2);
    b.insert(b.end(), a.begin(), a.end());
    b.insert(b.end(), n.begin(), n.end());
    put(b, o.surface.mesh, 1);
    put(b, o.visible | (o.collider << 1), 1);
    put(b, 0, 2);
    put(b, o.surface.rgb);
    for (auto v : {o.transform.p, o.transform.rot, o.transform.scale})
      for (float f : {v.x, v.y, v.z})
        put(b, std::bit_cast<std::uint32_t>(f));
    need(b.size() <= limit, "scene exceeds limit");
  }
  auto sum = crc(std::span<const std::uint8_t>(b).subspan(16));
  for (int i = 0; i < 4; ++i)
    b[12 + i] = static_cast<std::uint8_t>(sum >> (i * 8));
  return b;
}
Scene decode(std::span<const std::uint8_t> b) {
  need(b.size() >= 16 && b.size() <= limit, "invalid scene size");
  Read r{b};
  need(!std::memcmp(r.take(4).data(), "BNS1", 4) && r.number() == 1,
       "unknown scene format");
  auto n = r.number(), sum = r.number();
  need(n <= 20000 && n <= (b.size() - 16) / 50, "invalid object count");
  need(sum == crc(b.subspan(16)), "CRC mismatch");
  Scene scene;
  scene.reserve(n);
  std::unordered_set<std::string> ids;
  for (unsigned i = 0; i < n; ++i) {
    Record o;
    auto a = r.number(2), z = r.number(2);
    o.identity = {r.text(a), r.text(z)};
    o.surface.mesh = r.number(1);
    auto flags = r.number(1);
    need(flags <= 3 && r.number(2) == 0, "invalid flags");
    o.visible = flags & 1;
    o.collider = flags & 2;
    o.surface.rgb = r.number();
    o.transform.p = o.transform.prev = r.vec();
    o.transform.rot = r.vec();
    o.transform.scale = r.vec();
    valid(o);
    need(ids.insert(o.identity.id).second, "duplicate id");
    scene.push_back(std::move(o));
  }
  need(r.at == b.size(), "trailing scene bytes");
  return scene;
}
Scene load(const std::filesystem::path &p) { return decode(read(p, limit)); }
World instantiate(const Scene &s) {
  World w;
  for (auto &o : s) {
    auto e = w.create();
    w.set(e, o.identity);
    w.set(e, o.transform);
    if (o.visible)
      w.set(e, o.surface);
    if (o.collider) {
      Body b;
      b.half = o.transform.scale * .5f;
      w.set(e, b);
    }
  }
  return w;
}
Config readConfig(const std::filesystem::path &p, Config c, bool user) {
  if (user && !std::filesystem::exists(p))
    return c;
  auto b = read(p, 4096);
  std::string s(b.begin(), b.end());
  std::unordered_set<std::string> keys;
  for (std::size_t off = 0; off < s.size();) {
    auto end = s.find('\n', off);
    if (end == s.npos)
      end = s.size();
    auto line = s.substr(off, end - off);
    off = end + 1;
    if (!line.empty() && line.back() == '\r')
      line.pop_back();
    if (line.empty() || line.front() == '#')
      continue;
    auto eq = line.find('=');
    need(eq != s.npos, "invalid setting");
    auto k = line.substr(0, eq), v = line.substr(eq + 1);
    need(keys.insert(k).second, "duplicate setting");
    if (k == "game_id" && !user) {
      need(!v.empty() && v.size() <= 48 &&
               v.find_first_not_of("abcdefghijklmnopqrstuvwxyz0123456789_-") ==
                   v.npos,
           "invalid game id");
      c.id = v;
      continue;
    }
    unsigned n{};
    auto [ptr, ec] = std::from_chars(v.data(), v.data() + v.size(), n);
    need(ec == std::errc{} && ptr == v.data() + v.size(),
         "invalid setting value");
    if (k == "width" && n >= 320 && n <= 7680)
      c.width = n;
    else if (k == "height" && n >= 200 && n <= 4320)
      c.height = n;
    else if (k == "vsync" && n <= 1)
      c.vsync = n;
    else if (k == "volume" && n <= 100)
      c.volume = n / 100.f;
    else
      throw std::runtime_error("invalid setting: " + k);
  }
  return c;
}
} // namespace blockage
