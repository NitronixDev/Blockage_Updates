#include <blockage/engine.hpp>
#include <charconv>
#include <cstdlib>
#include <iostream>
#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#endif
namespace fs = std::filesystem;
using namespace blockage;
static fs::path executable() {
#ifdef _WIN32
  std::wstring s(32768, L'\0');
  auto n = GetModuleFileNameW(nullptr, s.data(), DWORD(s.size()));
  if (!n || n >= s.size())
    throw std::runtime_error("cannot find game installation");
  s.resize(n);
  return fs::path(s).parent_path();
#else
  return fs::read_symlink("/proc/self/exe").parent_path();
#endif
}
static fs::path userRoot() {
#ifdef _WIN32
  if (auto *p = _wgetenv(L"LOCALAPPDATA"); p && fs::path(p).is_absolute())
    return p;
#else
  if (auto *p = std::getenv("XDG_DATA_HOME"); p && fs::path(p).is_absolute())
    return p;
  if (auto *p = std::getenv("HOME"); p && fs::path(p).is_absolute())
    return fs::path(p) / ".local/share";
#endif
  throw std::runtime_error("no user data directory");
}
int main(int argc, char **argv) {
  bool unattended = false;
  try {
    int steps = 0;
    bool smoke = false;
    fs::path user;
    for (int i = 1; i < argc; ++i) {
      std::string arg = argv[i];
      if (arg == "--headless" && i + 1 < argc) {
        unattended = true;
        std::string v = argv[++i];
        auto [p, ec] = std::from_chars(v.data(), v.data() + v.size(), steps);
        if (ec != std::errc{} || p != v.data() + v.size() || steps < 1 ||
            steps > 1000000)
          throw std::runtime_error("invalid tick count");
      } else if (arg == "--gpu-smoke") {
        smoke = unattended = true;
      } else if (arg == "--save-dir" && i + 1 < argc)
        user = fs::absolute(argv[++i]);
      else
        throw std::runtime_error("unknown argument");
    }
    auto root = executable();
    auto cfg = readConfig(root / "game.cfg");
    if (user.empty())
      user = userRoot() / "BlockageGames" / cfg.id;
    cfg = readConfig(user / "settings.cfg", cfg, true);
    auto scene = load(root / "content/level.bns");
    auto world = instantiate(scene);
    Services s{world};
    s.content = root / "content";
    s.audio.volume = cfg.volume;
    auto g = makeGame(user);
    g->start(s);
    if (steps) {
      for (int i = 0; i < steps; ++i)
        tick(s, *g, {}, float(Clock::dt));
      std::cout << "OK ticks=" << steps << " objects=" << scene.size() << " "
                << g->title() << "\n";
      return 0;
    }
#ifdef _WIN32
    return windowLoop(s, *g, cfg, smoke);
#else
    (void)smoke;
    throw std::runtime_error(
        "Linux QA host: use --headless N. Interactive backend: Windows D3D11.");
#endif
  } catch (const std::exception &e) {
    std::cerr << e.what() << '\n';
#ifdef _WIN32
    if (!unattended)
      MessageBoxA(nullptr, e.what(), "Blockage Native", MB_OK | MB_ICONERROR);
#else
    (void)unattended;
#endif
    return 2;
  }
}
#ifdef _WIN32
int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int) {
  return main(__argc, __argv);
}
#endif
