#include "d3d11.hpp"
#include <chrono>
#include <mmsystem.h>
namespace blockage {
namespace {
LRESULT CALLBACK dispatch(HWND h, UINT m, WPARAM w, LPARAM l) {
  if (m == WM_NCCREATE)
    SetWindowLongPtrW(
        h, GWLP_USERDATA,
        reinterpret_cast<LONG_PTR>(
            reinterpret_cast<CREATESTRUCTW *>(l)->lpCreateParams));
  if (m == WM_DESTROY) {
    PostQuitMessage(0);
    return 0;
  }
  if (m == WM_KEYDOWN && w == VK_ESCAPE) {
    PostMessageW(h, WM_CLOSE, 0, 0);
    return 0;
  }
  if (m == WM_KEYDOWN && w == 'R' && !(l & (1L << 30)))
    if (auto *p = reinterpret_cast<bool *>(GetWindowLongPtrW(h, GWLP_USERDATA)))
      *p = true;
  return DefWindowProcW(h, m, w, l);
}
struct Window {
  HWND h{};
  bool restart = false;
  Window(const Config &c) {
    WNDCLASSW wc{};
    wc.lpfnWndProc = dispatch;
    wc.hInstance = GetModuleHandleW(nullptr);
    wc.lpszClassName = L"Blockage.Native";
    wc.hCursor = LoadCursorW(nullptr, MAKEINTRESOURCEW(32512));
    if (!RegisterClassW(&wc) && GetLastError() != ERROR_CLASS_ALREADY_EXISTS)
      throw std::runtime_error("window class");
    RECT r{0, 0, LONG(c.width), LONG(c.height)};
    AdjustWindowRect(&r, WS_OVERLAPPEDWINDOW, FALSE);
    h = CreateWindowExW(0, wc.lpszClassName, L"Blockage Native",
                        WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT,
                        r.right - r.left, r.bottom - r.top, nullptr, nullptr,
                        wc.hInstance, &restart);
    if (!h)
      throw std::runtime_error("create window");
    ShowWindow(h, SW_SHOW);
  }
  ~Window() {
    if (IsWindow(h))
      DestroyWindow(h);
  }
};
class Wave {
  HWAVEOUT out{};
  std::array<WAVEHDR, 3> headers{};
  std::array<std::array<std::int16_t, 1024>, 3> pcm{};
  void close() {
    if (!out)
      return;
    waveOutReset(out);
    for (auto &h : headers)
      if (h.dwFlags & WHDR_PREPARED)
        waveOutUnprepareHeader(out, &h, sizeof(h));
    waveOutClose(out);
    out = nullptr;
  }

public:
  Wave() {
    WAVEFORMATEX f{};
    f.wFormatTag = WAVE_FORMAT_PCM;
    f.nChannels = 1;
    f.nSamplesPerSec = Mixer::rate;
    f.wBitsPerSample = 16;
    f.nBlockAlign = 2;
    f.nAvgBytesPerSec = f.nSamplesPerSec * 2;
    if (waveOutOpen(&out, WAVE_MAPPER, &f, 0, 0, CALLBACK_NULL) !=
        MMSYSERR_NOERROR) {
      out = nullptr;
      return;
    }
    for (std::size_t i = 0; i < headers.size(); ++i) {
      auto &h = headers[i];
      h.lpData = reinterpret_cast<char *>(pcm[i].data());
      h.dwBufferLength = sizeof(pcm[i]);
      if (waveOutPrepareHeader(out, &h, sizeof(h)) != MMSYSERR_NOERROR) {
        close();
        break;
      }
    }
  }
  ~Wave() { close(); }
  void pump(Mixer &m) {
    if (!out)
      return;
    for (std::size_t i = 0; i < headers.size(); ++i) {
      auto &h = headers[i];
      if (!(h.dwFlags & WHDR_INQUEUE)) {
        m.mix(pcm[i]);
        if (waveOutWrite(out, &h, sizeof(h)) != MMSYSERR_NOERROR) {
          close();
          return;
        }
      }
    }
  }
};
} // namespace
int windowLoop(Services &s, Game &g, const Config &c, bool smoke) {
  Window win(c);
  auto renderer = std::make_unique<Renderer>(win.h, smoke);
  Wave sound;
  Clock clock;
  DrawList list;
  using Time = std::chrono::steady_clock;
  auto last = Time::now(), label = last - std::chrono::seconds(1);
  int frames = 0, resets = 0;
  for (;;) {
    MSG msg{};
    while (PeekMessageW(&msg, nullptr, 0, 0, PM_REMOVE)) {
      if (msg.message == WM_QUIT)
        return 0;
      TranslateMessage(&msg);
      DispatchMessageW(&msg);
    }
    RECT size{};
    GetClientRect(win.h, &size);
    unsigned w = size.right, h = size.bottom;
    if (!w || !h || IsIconic(win.h)) {
      WaitMessage();
      last = Time::now();
      continue;
    }
    auto key = [&](int k) {
      return GetForegroundWindow() == win.h && (GetAsyncKeyState(k) & 0x8000);
    };
    Input in{float(key('D') || key(VK_RIGHT)) -
                 float(key('A') || key('Q') || key(VK_LEFT)),
             float(key('W') || key('Z') || key(VK_UP)) -
                 float(key('S') || key(VK_DOWN)),
             win.restart};
    auto now = Time::now();
    clock.advance(std::chrono::duration<double>(now - last).count(),
                  [&](float dt) {
                    tick(s, g, in, dt);
                    win.restart = in.restart = false;
                  });
    last = now;
    sound.pump(s.audio);
    list.gather(s.world, s.meshes, s.camera, float(w) / h, clock.alpha());
    try {
      renderer->draw(list, s.meshes, s.camera, w, h, c.vsync,
                     smoke && frames == 2);
    } catch (const DeviceLost &) {
      if (++resets > 2)
        throw;
      renderer.reset();
      renderer = std::make_unique<Renderer>(win.h, smoke);
      last = Time::now();
      continue;
    }
    if (now - label > std::chrono::milliseconds(250)) {
      auto text = g.title();
      auto n = MultiByteToWideChar(CP_UTF8, 0, text.c_str(), -1, nullptr, 0);
      if (n > 0) {
        std::wstring title(n, L'\0');
        MultiByteToWideChar(CP_UTF8, 0, text.c_str(), -1, title.data(), n);
        SetWindowTextW(win.h, title.c_str());
      }
      label = now;
    }
    if (smoke && ++frames == 3)
      return 0;
  }
}
} // namespace blockage
