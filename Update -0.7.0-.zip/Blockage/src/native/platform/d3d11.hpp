#pragma once
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <blockage/engine.hpp>
#include <windows.h>
namespace blockage {
struct DeviceLost : std::runtime_error {
  using std::runtime_error::runtime_error;
};
class Renderer {
  struct State;
  std::unique_ptr<State> p_;

public:
  Renderer(HWND, bool software);
  ~Renderer();
  void draw(const DrawList &, const MeshBank &, const Camera &, unsigned,
            unsigned, bool, bool);
};
} // namespace blockage
