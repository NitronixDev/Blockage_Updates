#include "d3d11.hpp"
#include <cstring>
#include <d3d11.h>
#include <d3dcompiler.h>
#include <wrl/client.h>
namespace blockage {
using Microsoft::WRL::ComPtr;
namespace {
void check(HRESULT hr, const char *what) {
  if (hr == DXGI_ERROR_DEVICE_REMOVED || hr == DXGI_ERROR_DEVICE_RESET)
    throw DeviceLost(what);
  if (FAILED(hr))
    throw std::runtime_error(std::string(what) + " HRESULT=" +
                             std::to_string(static_cast<unsigned>(hr)));
}
constexpr char source[] = R"shader(
cbuffer View:register(b0){float4 eyeN,rightTx,upTy,frontF;};
struct V{float3 p:POSITION;float3 n:NORMAL;float3 center:IPOS;float3 size:ISIZE;float3 rot:IROT;uint color:ICOLOR;};
struct O{float4 p:SV_POSITION;float3 color:COLOR;};
float3 turn(float3 v,float3 r){float3 s,c;sincos(r,s,c);
v.xy=float2(c.z*v.x-s.z*v.y,s.z*v.x+c.z*v.y);v.xz=float2(c.y*v.x+s.y*v.z,-s.y*v.x+c.y*v.z);
v.yz=float2(c.x*v.y-s.x*v.z,s.x*v.y+c.x*v.z);return v;}
O vs(V i){O o;float3 d=turn(i.p*i.size,i.rot)+i.center-eyeN.xyz;float z=dot(d,frontF.xyz);
o.p=float4(dot(d,rightTx.xyz)/rightTx.w,dot(d,upTy.xyz)/upTy.w,(z-eyeN.w)*frontF.w/(frontF.w-eyeN.w),z);
float3 n=normalize(turn(i.n/i.size,i.rot));float lit=.22+.17*(.5+.5*n.y)+.70*saturate(dot(n,normalize(float3(-.36,.81,-.45))));
float3 col=float3((i.color>>16)&255,(i.color>>8)&255,i.color&255)/255.;o.color=pow(max(pow(col,2.2)*lit,.00001),1./2.2);return o;}
float4 ps(O i):SV_TARGET{return float4(i.color,1);}
)shader";
ComPtr<ID3DBlob> compile(const char *name, const char *profile) {
  ComPtr<ID3DBlob> b, err;
  auto hr = D3DCompile(source, sizeof(source) - 1, "Blockage/forward", nullptr,
                       nullptr, name, profile, D3DCOMPILE_OPTIMIZATION_LEVEL3,
                       0, &b, &err);
  if (FAILED(hr) && err)
    throw std::runtime_error(
        std::string(static_cast<const char *>(err->GetBufferPointer()),
                    err->GetBufferSize()));
  check(hr, "compile shader");
  return b;
}
} // namespace
struct Renderer::State {
  ComPtr<ID3D11Device> dev;
  ComPtr<ID3D11DeviceContext> ctx;
  ComPtr<IDXGISwapChain> swap;
  ComPtr<ID3D11RenderTargetView> rt;
  ComPtr<ID3D11DepthStencilView> depth;
  ComPtr<ID3D11VertexShader> vs;
  ComPtr<ID3D11PixelShader> ps;
  ComPtr<ID3D11RasterizerState> raster;
  ComPtr<ID3D11InputLayout> layout;
  ComPtr<ID3D11Buffer> cb, instances;
  struct GPU {
    ComPtr<ID3D11Buffer> vertices, indices;
    UINT count{};
  };
  std::vector<GPU> gpu;
  unsigned w = 0, h = 0;
  std::size_t capacity = 0;
  ComPtr<ID3D11Buffer> buffer(UINT size, UINT bind, D3D11_USAGE usage,
                              const void *data = nullptr) {
    D3D11_BUFFER_DESC d{};
    d.ByteWidth = size;
    d.BindFlags = bind;
    d.Usage = usage;
    if (usage == D3D11_USAGE_DYNAMIC)
      d.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
    D3D11_SUBRESOURCE_DATA init{};
    init.pSysMem = data;
    ComPtr<ID3D11Buffer> result;
    check(dev->CreateBuffer(&d, data ? &init : nullptr, &result),
          "create buffer");
    return result;
  }
  State(HWND hwnd, bool warp) {
    DXGI_SWAP_CHAIN_DESC sc{};
    sc.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    sc.SampleDesc.Count = 1;
    sc.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sc.BufferCount = 2;
    sc.OutputWindow = hwnd;
    sc.Windowed = TRUE;
    sc.SwapEffect = DXGI_SWAP_EFFECT_FLIP_DISCARD;
    auto create = [&](D3D_DRIVER_TYPE driver) {
      D3D_FEATURE_LEVEL level = D3D_FEATURE_LEVEL_11_0;
      return D3D11CreateDeviceAndSwapChain(nullptr, driver, nullptr, 0, &level,
                                           1, D3D11_SDK_VERSION, &sc, &swap,
                                           &dev, nullptr, &ctx);
    };
    auto hr = create(warp ? D3D_DRIVER_TYPE_WARP : D3D_DRIVER_TYPE_HARDWARE);
    if (FAILED(hr) && !warp)
      hr = create(D3D_DRIVER_TYPE_WARP);
    check(hr, "create D3D11 device");
    auto v = compile("vs", "vs_5_0"), p = compile("ps", "ps_5_0");
    check(dev->CreateVertexShader(v->GetBufferPointer(), v->GetBufferSize(),
                                  nullptr, &vs),
          "vertex shader");
    check(dev->CreatePixelShader(p->GetBufferPointer(), p->GetBufferSize(),
                                 nullptr, &ps),
          "pixel shader");
    static_assert(sizeof(Vertex) == 24 && sizeof(Instance) == 40 &&
                  offsetof(Instance, rgb) == 36);
    D3D11_INPUT_ELEMENT_DESC desc[] = {
        {"POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 0,
         D3D11_INPUT_PER_VERTEX_DATA, 0},
        {"NORMAL", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 12,
         D3D11_INPUT_PER_VERTEX_DATA, 0},
        {"IPOS", 0, DXGI_FORMAT_R32G32B32_FLOAT, 1, 0,
         D3D11_INPUT_PER_INSTANCE_DATA, 1},
        {"ISIZE", 0, DXGI_FORMAT_R32G32B32_FLOAT, 1, 12,
         D3D11_INPUT_PER_INSTANCE_DATA, 1},
        {"IROT", 0, DXGI_FORMAT_R32G32B32_FLOAT, 1, 24,
         D3D11_INPUT_PER_INSTANCE_DATA, 1},
        {"ICOLOR", 0, DXGI_FORMAT_R32_UINT, 1, 36,
         D3D11_INPUT_PER_INSTANCE_DATA, 1}};
    check(dev->CreateInputLayout(desc, 6, v->GetBufferPointer(),
                                 v->GetBufferSize(), &layout),
          "input layout");
    D3D11_RASTERIZER_DESC r{};
    r.FillMode = D3D11_FILL_SOLID;
    r.CullMode = D3D11_CULL_NONE;
    r.DepthClipEnable = TRUE;
    check(dev->CreateRasterizerState(&r, &raster), "rasterizer");
    cb = buffer(64, D3D11_BIND_CONSTANT_BUFFER, D3D11_USAGE_DEFAULT);
  }
  void resize(unsigned x, unsigned y) {
    if (w == x && h == y)
      return;
    ctx->OMSetRenderTargets(0, nullptr, nullptr);
    rt.Reset();
    depth.Reset();
    check(swap->ResizeBuffers(0, x, y, DXGI_FORMAT_UNKNOWN, 0),
          "resize swap chain");
    ComPtr<ID3D11Texture2D> back, dep;
    check(swap->GetBuffer(0, IID_PPV_ARGS(&back)), "back buffer");
    check(dev->CreateRenderTargetView(back.Get(), nullptr, &rt),
          "render target");
    D3D11_TEXTURE2D_DESC d{};
    d.Width = x;
    d.Height = y;
    d.MipLevels = d.ArraySize = d.SampleDesc.Count = 1;
    d.Format = DXGI_FORMAT_D24_UNORM_S8_UINT;
    d.BindFlags = D3D11_BIND_DEPTH_STENCIL;
    check(dev->CreateTexture2D(&d, nullptr, &dep), "depth buffer");
    check(dev->CreateDepthStencilView(dep.Get(), nullptr, &depth),
          "depth view");
    w = x;
    h = y;
  }
  void checkPixels() {
    ComPtr<ID3D11Texture2D> back, copy;
    check(swap->GetBuffer(0, IID_PPV_ARGS(&back)), "readback");
    D3D11_TEXTURE2D_DESC d;
    back->GetDesc(&d);
    d.Usage = D3D11_USAGE_STAGING;
    d.BindFlags = d.MiscFlags = 0;
    d.CPUAccessFlags = D3D11_CPU_ACCESS_READ;
    check(dev->CreateTexture2D(&d, nullptr, &copy), "readback texture");
    ctx->CopyResource(copy.Get(), back.Get());
    D3D11_MAPPED_SUBRESOURCE m{};
    check(ctx->Map(copy.Get(), 0, D3D11_MAP_READ, 0, &m), "readback map");
    bool color = false;
    for (UINT y = 0; y < h && !color; y += 4) {
      auto row = static_cast<const std::uint8_t *>(m.pData) + y * m.RowPitch;
      for (UINT x = 0; x < w; x += 4)
        if (row[4 * x] > 40 || row[4 * x + 1] > 45 || row[4 * x + 2] > 60) {
          color = true;
          break;
        }
    }
    ctx->Unmap(copy.Get(), 0);
    if (!color)
      throw std::runtime_error("GPU smoke: only background pixels");
  }
};
Renderer::Renderer(HWND hwnd, bool warp)
    : p_(std::make_unique<State>(hwnd, warp)) {}
Renderer::~Renderer() = default;
void Renderer::draw(const DrawList &list, const MeshBank &meshes,
                    const Camera &c, unsigned w, unsigned h, bool sync,
                    bool smoke) {
  auto &s = *p_;
  s.resize(w, h);
  auto *ctx = s.ctx.Get();
  auto *rt = s.rt.Get();
  ctx->OMSetRenderTargets(1, &rt, s.depth.Get());
  float clear[]{.025f, .04f, .065f, 1};
  ctx->ClearRenderTargetView(rt, clear);
  ctx->ClearDepthStencilView(s.depth.Get(), D3D11_CLEAR_DEPTH, 1, 0);
  D3D11_VIEWPORT vp{0, 0, float(w), float(h), 0, 1};
  ctx->RSSetViewports(1, &vp);
  ctx->RSSetState(s.raster.Get());
  ctx->IASetInputLayout(s.layout.Get());
  ctx->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
  ctx->VSSetShader(s.vs.Get(), nullptr, 0);
  ctx->PSSetShader(s.ps.Get(), nullptr, 0);
  auto f = unit(c.target - c.eye), r = unit(cross({0, 1, 0}, f)),
       u = cross(f, r);
  float ty = std::tan(c.fov * .5f);
  float constants[]{c.eye.x, c.eye.y,    c.eye.z, c.nearZ, r.x, r.y,
                    r.z,     ty * w / h, u.x,     u.y,     u.z, ty,
                    f.x,     f.y,        f.z,     c.farZ};
  ctx->UpdateSubresource(s.cb.Get(), 0, nullptr, constants, 0, 0);
  auto *cb = s.cb.Get();
  ctx->VSSetConstantBuffers(0, 1, &cb);
  s.gpu.resize(meshes.size());
  for (std::size_t i = 0; i < list.batches.size(); ++i) {
    const auto &frames = list.batches[i];
    if (frames.empty())
      continue;
    auto &g = s.gpu[i];
    if (!g.vertices) {
      const auto &m = meshes.get(static_cast<std::uint32_t>(i));
      g.vertices = s.buffer(UINT(m.vertices.size() * sizeof(Vertex)),
                            D3D11_BIND_VERTEX_BUFFER, D3D11_USAGE_IMMUTABLE,
                            m.vertices.data());
      g.indices = s.buffer(UINT(m.indices.size() * 4), D3D11_BIND_INDEX_BUFFER,
                           D3D11_USAGE_IMMUTABLE, m.indices.data());
      g.count = UINT(m.indices.size());
    }
    if (frames.size() > 1000000)
      throw std::length_error("instance budget");
    if (frames.size() > s.capacity) {
      s.capacity = std::max(frames.size(), s.capacity * 2);
      s.instances = s.buffer(UINT(s.capacity * sizeof(Instance)),
                             D3D11_BIND_VERTEX_BUFFER, D3D11_USAGE_DYNAMIC);
    }
    D3D11_MAPPED_SUBRESOURCE m{};
    check(ctx->Map(s.instances.Get(), 0, D3D11_MAP_WRITE_DISCARD, 0, &m),
          "map instances");
    std::memcpy(m.pData, frames.data(), frames.size() * sizeof(Instance));
    ctx->Unmap(s.instances.Get(), 0);
    ID3D11Buffer *buffers[]{g.vertices.Get(), s.instances.Get()};
    UINT strides[]{sizeof(Vertex), sizeof(Instance)}, offset[]{0, 0};
    ctx->IASetVertexBuffers(0, 2, buffers, strides, offset);
    ctx->IASetIndexBuffer(g.indices.Get(), DXGI_FORMAT_R32_UINT, 0);
    ctx->DrawIndexedInstanced(g.count, UINT(frames.size()), 0, 0, 0);
  }
  if (smoke)
    s.checkPixels();
  check(s.swap->Present(sync ? 1 : 0, 0), "present");
}
} // namespace blockage
