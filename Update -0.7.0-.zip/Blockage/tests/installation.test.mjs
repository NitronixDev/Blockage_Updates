import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const { installationProblems } = require('../scripts/verify-install.cjs');

async function fixture(run) {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'blockage-install-'));
  try {
    const write = async (name, data) => {
      const file = path.join(root, name);
      await fs.mkdir(path.dirname(file), { recursive: true });
      await fs.writeFile(file, data);
    };
    await write('package.json', JSON.stringify({ dependencies: { three: '0.186.1' }, devDependencies: { electron: '44.7.0' } }));
    await run(root, write);
  } finally { await fs.rm(root, { recursive: true, force: true }); }
}
async function ready(write) {
  for (const [name, version] of [['three', '0.186.1'], ['electron', '44.7.0']]) await write('node_modules/' + name + '/package.json', JSON.stringify({ version }));
  for (const file of ['build/three.module.js', 'build/three.core.js', 'examples/jsm/loaders/GLTFLoader.js']) await write('node_modules/three/' + file, 'module');
  for (const file of ['icudtl.dat', 'resources.pak', 'locales/en-US.pak']) await write('node_modules/electron/dist/' + file, 'resource');
  const binary = Buffer.alloc(4096); binary.write('MZ');
  await write('node_modules/electron/dist/electron.exe', binary);
  await write('node_modules/electron/path.txt', 'electron.exe\n');
}

test('a source checkout needs dependency installation', () => fixture(async root => {
  const problems = installationProblems(root, 'win32');
  assert(problems.some(problem => problem.startsWith('three')));
  assert(problems.some(problem => problem.startsWith('electron')));
  assert(problems.some(problem => problem.startsWith('Electron')));
}));
test('a ready Windows distribution passes the offline prerequisite check', () => fixture(async (root, write) => {
  await ready(write);
  assert.deepEqual(installationProblems(root, 'win32'), []);
}));
test('incomplete or incompatible dependencies trigger repair', () => fixture(async (root, write) => {
  await ready(write);
  await fs.unlink(path.join(root, 'node_modules/electron/dist/icudtl.dat'));
  assert(installationProblems(root, 'win32').some(problem => problem.includes('icudtl.dat')));
  await ready(write);
  await write('node_modules/electron/dist/electron.exe', Buffer.alloc(4096));
  assert(installationProblems(root, 'win32').some(problem => problem.startsWith('Electron')));
  await ready(write);
  await write('node_modules/three/package.json', JSON.stringify({ version: '0.185.0' }));
  assert(installationProblems(root, 'win32').some(problem => problem.startsWith('three')));
}));
