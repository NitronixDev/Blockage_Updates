import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { createDocument, createEntity } from '../src/engine/document.js';
import {
  cookNativeScene,
  validateNativeBytes,
} from '../src/engine/native-cook.js';
import { exampleLevel } from '../scripts/native-example.mjs';
import { imports } from '../scripts/native/pe.mjs';
import {
  exportGame,
  assetName,
  options,
  steamFiles,
} from '../scripts/native-export.mjs';
const sample = path.resolve(import.meta.dirname, '../src/native/sample');
test('BNS1 exported by the editor survives validation; corrupt and truncated levels fail', async () => {
  const b = await fs.readFile(path.join(sample, 'level.bns'));
  assert.equal(validateNativeBytes(b).count, 20);
  const changed = Buffer.from(b);
  changed[changed.length - 1] ^= 1;
  assert.throws(() => validateNativeBytes(changed), /CRC/);
  assert.throws(() => validateNativeBytes(b.subarray(0, 30)));
});
function pe(dllName = 'kernel32.dll', isDLL = false) {
  const b = Buffer.alloc(1024);
  b.write('MZ');
  b.writeUInt32LE(64, 60);
  b.write('PE\0\0', 64);
  b.writeUInt16LE(0x8664, 68);
  b.writeUInt16LE(1, 70);
  b.writeUInt16LE(0xf0, 84);
  b.writeUInt16LE(2 | (isDLL ? 0x2000 : 0), 86);
  const opt = 88,
    s = opt + 0xf0;
  b.writeUInt16LE(0x20b, opt);
  b.writeUInt32LE(16, opt + 108);
  b.writeUInt32LE(4096, opt + 120);
  b.writeUInt32LE(40, opt + 124);
  b.writeUInt32LE(4096, s + 12);
  b.writeUInt32LE(512, s + 16);
  b.writeUInt32LE(512, s + 20);
  b.writeUInt32LE(4160, 524);
  b.write(dllName, 576);
  return b;
}
const temporary = (fn) => async () => {
  const d = await fs.mkdtemp(path.join(os.tmpdir(), 'blockage-sdk-'));
  try {
    await fn(d);
  } finally {
    await fs.rm(d, { recursive: true, force: true });
  }
};
test('cook reproduces the exact bundled BNS1 scene without mutating Studio', async () => {
  const scene = exampleLevel(),
    before = JSON.stringify(scene),
    out = cookNativeScene(scene);
  assert.equal(out.count, 20);
  assert.equal(JSON.stringify(scene), before);
  assert.deepEqual(
    Buffer.from(out.bytes),
    await fs.readFile(path.join(sample, 'level.bns')),
  );
});
test('cook names unsupported objects, shaders, colliders and animation', () => {
  const d = createDocument();
  const water = createEntity('water', { name: 'Lake' });
  d.entities.push(water);
  assert.throws(() => cookNativeScene(d), /Lake.*water/);
  const e = createEntity('box');
  d.entities = [e];
  e.material.opacity = 0.4;
  assert.throws(() => cookNativeScene(d), /transparent/);
  e.material.opacity = 1;
  e.transform.rotation[0] = 10;
  assert.throws(() => cookNativeScene(d), /unrotated/);
  e.transform.rotation[0] = 0;
  e.behaviors.spin = { axis: 'Y', speed: 5 };
  assert.throws(() => cookNativeScene(d), /behaviours/);
});
test('groups flatten into world space; sheared transforms fail', () => {
  const d = createDocument(),
    g = createEntity('group', { visible: false }),
    b = createEntity('box', { parent: g.id, collider: false });
  d.entities = [b, g];
  g.transform.position = [2, 0, 0];
  b.transform.position = [3, 0, 0];
  let out = cookNativeScene(d);
  const view = new DataView(out.bytes.buffer),
    n = 16 + 4 + new TextEncoder().encode(b.id + b.name).length;
  assert.equal(out.bytes[n + 1], 0);
  assert.equal(view.getFloat32(n + 8, true), 5);
  g.transform.scale = [1, 2, 1];
  b.transform.rotation = [0, 0, 35];
  assert.throws(() => cookNativeScene(d), /shear/);
});
test('SteamPipe templates separate preview and upload, with no promotion or credentials', () => {
  const v = steamFiles('12345', '12346');
  assert.match(v['app_preview.vdf'], /"Preview" "1"/);
  assert.match(v['app_candidate.vdf'], /"Preview" "0"/);
  assert.match(v['depot_12346.vdf'], /"recursive" "1"/);
  assert.doesNotMatch(JSON.stringify(v), /SetLive|password|steam_appid/);
  for (const x of ['', '0', '4"', '9999999999'])
    assert.throws(() => steamFiles(x, '12'));
});
test('CLI input and redistributable audit reject foreign or unsafe values', () => {
  assert.deepEqual(imports(pe()), ['kernel32.dll']);
  assert.throws(() => imports(pe('kernel32.dll', true)));
  const a = pe();
  a.writeUInt16LE(0x14c, 68);
  assert.throws(() => imports(a));
  assert.throws(() => imports(pe('../evil.dll')));
  for (const p of [
    '../x.wav',
    'NUL.obj',
    'C:\\x.bin',
    'a/.hidden/../x.bin',
    'a.exe',
  ])
    assert.throws(() => assetName(p));
  assert.throws(() => options(['--publish', 'now']));
});
test(
  'clean export hashes only selected files and never overwrites an existing destination',
  temporary(async (d) => {
    const binary = path.join(d, 'game.exe'),
      out = path.join(d, 'New Game');
    await fs.writeFile(binary, pe());
    await fs.writeFile(path.join(d, 'private.txt'), 'not included');
    const o = {
      binary,
      scene: path.join(sample, 'beacon-run.blockage'),
      out,
      'app-id': '123',
      'depot-id': '124',
    };
    const report = await exportGame(o);
    assert.equal(report.objects, 20);
    assert.equal(report.steamPublished, false);
    assert.equal(
      report.sha256['BlockageGame.exe'],
      createHash('sha256').update(pe()).digest('hex'),
    );
    assert.equal(
      await fs.stat(path.join(out, 'content/private.txt')).catch(() => null),
      null,
    );
    await assert.rejects(() => exportGame(o), /already exists/);
    assert.match(
      await fs.readFile(path.join(out, 'steam/app_preview.vdf'), 'utf8'),
      /"Preview" "1"/,
    );
  }),
);
test(
  'unresolved DLLs and linked assets stop the export before delivery',
  temporary(async (d) => {
    const binary = path.join(d, 'game.exe');
    await fs.writeFile(binary, pe('custom.dll'));
    const o = {
      binary,
      scene: path.join(sample, 'beacon-run.blockage'),
      out: path.join(d, 'bundle'),
    };
    await assert.rejects(() => exportGame(o), /Missing.*custom/);
    assert.equal(await fs.stat(o.out).catch(() => null), null);
    await fs.writeFile(path.join(d, 'custom.dll'), pe('kernel32.dll', true));
    await exportGame({ ...o, dll: ['custom.dll'] });
    if (process.platform !== 'win32') {
      await fs.symlink(binary, path.join(d, 'x.bin'));
      await assert.rejects(
        () =>
          exportGame({
            ...o,
            out: path.join(d, 'other'),
            dll: ['custom.dll'],
            asset: ['x.bin'],
            'asset-root': d,
          }),
        /linked asset/,
      );
    }
  }),
);
