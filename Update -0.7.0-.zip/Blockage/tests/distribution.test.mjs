import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { createRequire } from 'node:module';
import { zipSync, strToU8 } from 'three/addons/libs/fflate.module.js';
import { distributionOptions, promoteOutput } from '../scripts/dist.mjs';
const require = createRequire(import.meta.url);
const { UpdateService, REPOSITORY } = require('../electron/updates.cjs');
const { launchPlan } = require('../electron/update-runner.cjs');
const { distributionConfig } = require('../scripts/electron-builder.cjs');
const sha = text => crypto.createHash('sha256').update(text).digest('hex');
const pkg = version => ({ name: 'blockage-engine', version, main: 'electron/main.cjs', dependencies: { three: '0.186.1' }, devDependencies: { electron: '44.7.0' }, engines: { node: '>=26.11.1' } });
const temporary = run => async () => {
  const directory = await fs.mkdtemp(path.join(os.tmpdir(), 'blockage-dist-'));
  try { await run(directory); } finally { await fs.rm(directory, { recursive: true, force: true }); }
};
function archive({ version = '0.6.2', component = 'src', minVersion = '0.6.1' } = {}) {
  const files = { 'package.json': JSON.stringify(pkg(version)), [component + '/new.js']: 'verified update' };
  const manifest = { format: 'blockage.update', schema: 1, repository: REPOSITORY, version, minVersion, components: ['package.json', component], files: Object.entries(files).map(([name, text]) => ({ path: name, bytes: Buffer.byteLength(text), sha256: sha(text) })) };
  return Buffer.from(zipSync(Object.fromEntries([...Object.entries(files), ['update.json', JSON.stringify(manifest)]].map(([name, text]) => ['Blockage/' + name, strToU8(text)]))));
}
async function fixture(directory, packaged = false) {
  const root = path.join(directory, packaged ? 'Installed/resources/app' : 'Source');
  await fs.mkdir(path.join(root, 'src'), { recursive: true });
  await fs.writeFile(path.join(root, 'package.json'), JSON.stringify(pkg('0.6.1')));
  await fs.writeFile(path.join(root, 'src/original.js'), 'original');
  const filename = path.join(directory, 'Update -0.6.2-.zip'); await fs.writeFile(filename, archive());
  const progress = [], service = new UpdateService({ directory: path.join(directory, 'profile'), installationRoot: root, currentVersion: '0.6.1', packaged, onProgress: value => progress.push(value) });
  return { root, filename, service, progress };
}

test('local ZIP extraction preserves the chosen ZIP and the running engine', temporary(async directory => {
  const { root, filename, service, progress } = await fixture(directory);
  assert.deepEqual(await service.installLocal(filename), { ok: true, version: '0.6.2', path: root, source: 'local' });
  assert.equal(await fs.readFile(path.join(root, 'src/original.js'), 'utf8'), 'original');
  assert.equal(JSON.parse(await fs.readFile(path.join(root, 'package.json'))).version, '0.6.1');
  assert.equal(await fs.readFile(path.join(service.ready.stagedRoot, 'src/new.js'), 'utf8'), 'verified update');
  assert.deepEqual(await fs.readFile(filename), archive());
  assert.equal(progress.at(-1).percent, 100); assert.equal(service.busy, false);
}));
test('local update rejects full-source archives, relative paths and old versions', temporary(async directory => {
  const { filename, service } = await fixture(directory);
  await assert.rejects(() => service.installLocal('Update -0.6.2-.zip'), /local update ZIP/);
  await assert.rejects(() => service.installLocal(path.join(directory, 'Blockage_GitHub_0.6.2.zip')), /not the full/);
  await fs.writeFile(filename, archive({ version: '0.6.1' }));
  await assert.rejects(() => service.installLocal(filename), /version|newer/i);
  assert.equal(service.ready, null); assert.equal(service.busy, false);
}));
test('local ZIPs reject empty files, directories and symlinks', temporary(async directory => {
  const { filename, service } = await fixture(directory);
  await fs.writeFile(filename, ''); await assert.rejects(() => service.installLocal(filename), /regular file/);
  await fs.unlink(filename); await fs.mkdir(filename); await assert.rejects(() => service.installLocal(filename), /regular file/);
  await fs.rmdir(filename);
  if (process.platform !== 'win32') {
    const other = path.join(directory, 'other.zip'); await fs.writeFile(other, archive()); await fs.symlink(other, filename);
    await assert.rejects(() => service.installLocal(filename), /regular file/);
  }
  assert.equal(service.busy, false);
}));
test('a corrupted local ZIP is cleaned up without modifying live files', temporary(async directory => {
  const { filename, service, root } = await fixture(directory), bytes = archive();
  bytes.writeUInt32LE(0, bytes.indexOf(Buffer.from([0x50, 0x4b, 0x01, 0x02])) + 16);
  await fs.writeFile(filename, bytes); await assert.rejects(() => service.installLocal(filename), /checksum/);
  assert.equal(service.ready, null); assert.equal(service.busy, false);
  assert.deepEqual(await fs.readdir(path.join(directory, 'profile/updates')), []);
  assert.equal(await fs.readFile(path.join(root, 'src/original.js'), 'utf8'), 'original');
}));
test('concurrent local installs are rejected before asynchronous file access', temporary(async directory => {
  const { filename, service } = await fixture(directory);
  const first = service.installLocal(filename);
  await assert.rejects(() => service.installLocal(filename), /already/);
  await assert.rejects(() => service.prepareRestart(123), /verification/);
  await first;
}));
test('packaged applications accept code ZIPs but require an installer for runtime/dependency ZIPs', temporary(async directory => {
  const { filename, service } = await fixture(directory, true);
  assert((await service.installLocal(filename)).ok);
  for (const component of ['runtime', 'node_modules']) {
    await fs.writeFile(filename, archive({ component }));
    await assert.rejects(() => service.installLocal(filename), /Setup.exe/);
  }
}));
test('source installations can still stage component runtime updates', temporary(async directory => {
  const { filename, service } = await fixture(directory);
  await fs.writeFile(filename, archive({ component: 'runtime' }));
  assert((await service.installLocal(filename)).ok);
}));
test('packaged restart copies an independent helper and records the installed executable', temporary(async directory => {
  const { filename, service, root } = await fixture(directory, true);
  await service.installLocal(filename);
  const helper = path.join(directory, 'standalone-node'); await fs.writeFile(helper, 'test helper');
  const relaunch = { mode: 'packaged', executable: path.resolve(root, '../../Blockage.exe') };
  await assert.rejects(() => service.prepareRestart(123, [], helper), /restart target/);
  const prepared = await service.prepareRestart(123, ['--blockage-webgl'], helper, relaunch);
  assert.equal(await fs.readFile(prepared.executable, 'utf8'), 'test helper');
  const plan = JSON.parse(await fs.readFile(prepared.args[1], 'utf8'));
  assert.deepEqual(plan.relaunch, relaunch); assert.equal(plan.parentPid, 123);
  assert.equal(prepared.env.ELECTRON_RUN_AS_NODE, undefined);
  for (const file of ['update-runner.cjs', 'update-apply.cjs', 'update-manifest.cjs']) assert((await fs.stat(path.join(prepared.directory, file))).isFile());
  await fs.writeFile(path.join(service.ready.stagedRoot, 'src/new.js'), 'tampered');
  await assert.rejects(() => service.prepareRestart(123, [], helper, relaunch), /SHA-256|size/);
}));
test('restart plans remain compatible with legacy source updaters and filter flags', () => {
  const root = path.resolve('Blockage'), result = launchPlan({ installationRoot: root, flags: ['--inspect', '--blockage-player', '--blockage-webgl', 42] }, 'win32');
  assert.equal(result.executable, path.join(root, 'node_modules/electron/dist/electron.exe'));
  assert.deepEqual(result.args, [root, '--blockage-player', '--blockage-webgl']);
  assert.equal(result.cwd, root);
});
test('packaged restart launches the installed app without a development path argument', () => {
  const root = path.resolve('My Blockage/resources/app'), executable = path.resolve(root, '../../Blockage.exe');
  assert.deepEqual(launchPlan({ installationRoot: root, flags: ['--blockage-webgl'], relaunch: { mode: 'packaged', executable } }, 'win32'), { executable, args: ['--blockage-webgl'], cwd: path.resolve(root, '../..') });
  for (const relaunch of [{ mode: 'packaged', executable: path.resolve('other.exe') }, { mode: 'unknown' }]) assert.throws(() => launchPlan({ installationRoot: root, relaunch }, 'win32'), /restart/);
  assert.throws(() => launchPlan({ installationRoot: path.resolve('Source'), relaunch: { mode: 'packaged', executable } }, 'win32'), /restart/);
});
test('distribution CLI defaults to the host and never accepts a publish flag', () => {
  assert.deepEqual(distributionOptions([], 'win32'), { platform: 'win32', directoryOnly: false });
  assert.deepEqual(distributionOptions(['--win', '--dir'], 'linux'), { platform: 'win32', directoryOnly: true });
  assert.deepEqual(distributionOptions(['--linux'], 'win32'), { platform: 'linux', directoryOnly: false });
  for (const args of [['--publish'], ['--win', '--linux'], ['--arm64']]) assert.throws(() => distributionOptions(args), /Options/);
  assert.throws(() => distributionOptions([], 'darwin'), /Windows/);
});
test('distribution is per-user, unpacked, isolated from projects, and preserves updater dependency identity', temporary(async directory => {
  const value = pkg('0.6.1'), config = distributionConfig({ root: directory, appDirectory: path.join(directory, 'stage'), updaterDirectory: path.join(directory, 'updater'), platform: 'win32', pkg: value });
  assert.equal(config.asar, false); assert.equal(config.npmRebuild, false); assert.equal(config.publish, null);
  assert.equal(config.nsis.perMachine, false); assert.equal(config.nsis.allowElevation, false); assert.equal(config.nsis.deleteAppDataOnUninstall, false);
  assert.equal(config.directories.app, path.join(directory, 'stage'));
  assert.deepEqual(config.extraResources[0].filter, ['node.exe', 'LICENSE.node.txt']);
  const out = path.join(directory, 'output'), resources = path.join(out, 'resources');
  for (const name of ['electron/main.cjs', 'electron/preload.cjs', 'src/index.html', 'assets/logo.svg', 'scripts/blender-export.py', 'scripts/blender-alembic.py', 'node_modules/three/build/three.webgpu.js']) {
    const filename = path.join(resources, 'app', name); await fs.mkdir(path.dirname(filename), { recursive: true }); await fs.writeFile(filename, 'fixture');
  }
  await fs.mkdir(path.join(resources, 'updater')); await fs.writeFile(path.join(resources, 'updater/node.exe'), 'fixture');
  await fs.writeFile(path.join(resources, 'updater/LICENSE.node.txt'), 'fixture');
  for (const name of ['controls/OrbitControls.js', 'loaders/GLTFLoader.js', 'libs/draco/gltf/draco_decoder.wasm', 'libs/basis/basis_transcoder.wasm']) {
    const filename = path.join(config.directories.app, 'node_modules/three/examples/jsm', name); await fs.mkdir(path.dirname(filename), { recursive: true }); await fs.writeFile(filename, 'runtime addon');
  }
  await config.afterPack({ appOutDir: out });
  assert.deepEqual(JSON.parse(await fs.readFile(path.join(resources, 'app/package.json'))), value);
  assert.equal(JSON.parse(await fs.readFile(path.join(resources, 'blockage-distribution.json'))).updates, 'component-zips');
  await fs.writeFile(path.join(resources, 'app.asar'), 'unexpected');
  await assert.rejects(() => config.afterPack({ appOutDir: out }), /ASAR/);
}));

test('incomplete installer is never promoted over a previous output', temporary(async directory => {
  const build = path.join(directory, 'build'), dist = path.join(directory, 'dist'), name = 'Blockage-Setup-0.6.1-x64.exe';
  await fs.mkdir(build); await fs.mkdir(dist); await fs.writeFile(path.join(build, name), 'MZstub'); await fs.writeFile(path.join(dist, name), 'previous build');
  await assert.rejects(() => promoteOutput(build, dist, 'win32', false, '0.6.1'), /Incomplete/);
  assert.equal(await fs.readFile(path.join(dist, name), 'utf8'), 'previous build');
  const bytes = Buffer.alloc(1024 * 1024); bytes.write('MZ'); await fs.writeFile(path.join(build, name), bytes);
  assert.equal(await promoteOutput(build, dist, 'win32', false, '0.6.1'), path.join(dist, name));
  assert.equal((await fs.stat(path.join(dist, name))).size, bytes.length);
}));
