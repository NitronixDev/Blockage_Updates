# Blockage 0.6.1 · distribution desktop

| Ce que tu veux faire | Fichier ou commande |
| --- | --- |
| Mettre à jour les installations 0.6.0 existantes | Déposer `Update -0.6.1-.zip` intact à la racine du dépôt public. |
| Travailler sur le moteur ou générer un installateur | Extraire `Blockage_GitHub_0.6.1.zip` dans un dossier de développement. |
| Construire sous Windows x64, sans Node global | Ouvrir PowerShell dans ce dossier puis ` .\npm.cmd run dist `. Première construction avec Internet. |
| Construire avec Node x64 ≥ 26.11.1 et npm configurés | `npm ci` puis `npm run dist`. |
| Distribuer une nouvelle installation | Transmettre `dist/Blockage-Setup-0.6.1-x64.exe` produit sur Windows. L'utilisateur final n'a besoin ni de Node ni de npm. |
| Tester une version sans installeur | `npm run dist:dir`, puis `dist/win-unpacked/Blockage.exe`. Conserver **tout** le dossier. |
| Générer via GitHub sans publier | Avec les sources dans le dépôt et Actions activé : **Actions → Build Windows installer → Run workflow**. L'installateur est téléchargeable dans les artefacts du job réussi. |

L'installateur NSIS est par utilisateur, sans élévation demandée. Choisis un dossier accessible en écriture pour les mises à jour. Sans certificat de signature configuré, l'installateur est non signé : Windows peut afficher un avertissement. Le code ne désactive aucune protection Windows et ne contient aucun certificat privé. Le build local ne publie rien.

## Ce qui est réellement embarqué

L'exécutable Electron est accompagné de `resources/app` (éditeur, moteur, importeurs, addons et codecs Three.js) et d'un petit programme de mise à jour exécuté via `resources/updater/node.exe`. Le runtime d'exécution est indépendant de Node sur le PC de l'utilisateur. Les projets, caches, profils locaux, outils de build et anciens correctifs ne sont pas incorporés. Le convertisseur Blender se prépare au premier import qui en a besoin.

Les dossiers du moteur restent accessibles pour les correctifs par composants. Au redémarrage, l'outil attend la fermeture de l'application, vérifie les fichiers, sauvegarde les versions précédentes, applique les remplacements puis relance l'éditeur installé. Si un remplacement échoue, le mécanisme de restauration porte sur les fichiers du moteur, pas sur d'éventuels bogues du code installé. Garde les projets dans leur propre dossier.

## Vérifications reproductibles

`npm test` et `npm run check` contrôlent le code source. `node scripts/verify-distribution.mjs dist/win-unpacked` contrôle le paquet réel : en-têtes des exécutables, résolution des modules du renderer, chargement d'une scène glTF, modules WebAssembly Draco/KTX2 et convertisseurs. Ce n'est pas un test de performances GPU. Le workflow Windows vérifie aussi l'installation silencieuse dans un dossier temporaire sur un runner isolé.

Pour mesurer ton jeu, ouvre le Profiler, fixe la cible (60, 120 FPS…), réinitialise les échantillons et rejoue la même séquence à résolution et qualité identiques. Compare `Frame p99` et `Frames over budget` en plus de la moyenne. À 120 FPS, le budget est de **8,33 ms par image** ; le temps CPU de soumission ne mesure pas le temps GPU. L'export JSON contient ces mesures.
