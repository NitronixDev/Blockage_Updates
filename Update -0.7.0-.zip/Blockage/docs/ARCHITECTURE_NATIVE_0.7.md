# Blockage 0.7.0 | Architecture du moteur natif

**Décision : séparer l’outil d’auteur du produit livré.** Studio reste le moteur de prévisualisation existant. Le joueur final lance un exécutable Windows x64 C++20 indépendant. Ni V8, ni Electron, ni serveur local, ni vérification GitHub au lancement du jeu. La frontière stable est un format de données versionné, pas une interface binaire JavaScript/C++.

## Modules et responsabilités

| Module (depuis la racine des sources) | Propriété et contrat |
| --- | --- |
| `src/engine/native-cook.js` | Valide le document Studio, calcule les matrices mondiales, aplatit les groupes, audite les fonctionnalités et écrit BNS1. Même implémentation dans le menu et le générateur CLI. |
| `src/native/include/blockage/ecs.hpp` | Monde, identifiants `{slot, génération}`, réutilisation des slots, un ensemble dense par type de composant. Recherche O(1), suppression par échange avec le dernier élément. Aucun objet C++ de gameplay ne dépend d’un nœud de l’éditeur. |
| `src/native/include/blockage/engine.hpp` | API C++ : services, composants, banque de meshes, commandes de rendu, audio, interface du jeu, pas fixe et interpolation. |
| `src/native/core/physics.cpp` | Gravité, AABB dynamiques/statiques, masses inverses, restitution, friction, capteurs et masques. Balayage sur l’axe où les centres sont le plus dispersés. Budgets explicites de visites et de contacts. |
| `src/native/core/media.cpp`, `core/obj.cpp` | Géométries immuables indexées, primitifs et données personnalisées ; lecteur OBJ triangulé (positions, normales facultatives). Culling par sphère, interpolation et regroupement par géométrie. Mixeur PCM 48 kHz mono, 32 voix bornées. |
| `src/native/core/scene.cpp` | Encodage/décodage BNS1, contrôle de version, tailles, identités, transformations et CRC. Configuration empaquetée et surcharges utilisateur bornées. |
| `src/native/platform/` | Hôte headless ; fenêtre, clavier et audio WinMM sous Windows. Backend Direct3D 11, depth buffer, upload immuable d’un mesh à son premier dessin, instances dans un buffer dynamique, resize et recréation limitée du périphérique. WARP pour le test logiciel. |
| `src/native/sample/game.cpp` | **Beacon Run** : composant spécifique au jeu, mesh de balise créé en C++, déplacement, capteurs, condition de victoire, record et nouvelle partie. Aucun comportement de Beacon Run n’est codé dans les systèmes du moteur. |
| `scripts/native-export.mjs`, `scripts/native/pe.mjs` | Dossier de distribution par liste autorisée, audit des imports PE ordinaires et différés, sommes SHA-256, VDF SteamPipe facultatifs. Sorties préparées hors destination puis renommées. |
| `.github/workflows/native-game.yml` | Construction MSVC x64, tests headless, lecture de pixels via WARP, validation du paquet hors du dossier de build, job Linux avec sanitizers. Ce workflow ne publie pas sur Steam. |

### Boucle d’une image

1. L’hôte lit les entrées. L’horloge accumule le temps écoulé, limite le rattrapage à **8 ticks** et expose le temps abandonné.
2. À chaque tick de **1/60 s** : capture des positions précédentes → `Game::fixed` → collisions/contacts → `Game::afterPhysics`. La physique n’utilise pas le temps variable du rendu.
3. Le renderer interpole les positions avec le résidu, élimine les objets hors champ et émet un appel indexé instancié par mesh visible. Le mixer remplit des blocs audio réutilisés. Aucun des deux ne sérialise le monde.

### Écrire son jeu en C++

Fournis une classe dérivée de `blockage::Game` et définis `blockage::makeGame(const std::filesystem::path& userDirectory)`. Le corps complet de ces deux points d’entrée se trouve dans le jeu d’exemple. Dans `start` ou `fixed`, tu peux définir tes propres données :

```cpp
struct Health { int current; };
auto hero = s.world.create();
s.world.set(hero, Health{100});
s.world.set(hero, blockage::Transform{});
auto& health = s.world.pool<Health>();
for (auto& h : health.values()) h.current = std::min(100, h.current + 1);
```

Un `Entity` est conservable ; **un pointeur ou un span dans un pool ne l’est pas après modification structurelle de ce pool**. Termine l’itération avant de supprimer/créer des composants du même type. Il n’y a pas d’ordonnanceur multithread ni de promesse de déterminisme bit à bit entre CPU. Le pas fixe et les ordres explicites facilitent les tests.

Pour remplacer l’exemple : configure CMake avec `-DBLOCKAGE_GAME_SOURCE=C:/Jeux/MonJeu/game.cpp`, `-DBLOCKAGE_LEVEL=C:/Jeux/MonJeu/level.bns` et `-DBLOCKAGE_CONFIG=C:/Jeux/MonJeu/game.cfg`. Pour plusieurs unités de traduction, ajoute `target_sources(BlockageGame PRIVATE ...)` à ton projet CMake. La bibliothèque réutilisable est `Blockage::Core`. Le noyau n’impose aucun interpréteur ou DLL de script.

Un mesh de jeu peut être construit en C++ ou chargé via `s.meshes.add(blockage::loadTriangleOBJ(s.content / "assets/rocher.obj"))`. Associe l’ID retourné avec `s.world.set(entity, blockage::Surface{meshId, 0x92aabb})`. Pour inclure ce fichier, passe `--asset-root C:/MonJeu/assets --asset rocher.obj` à l’exporteur. Le chargeur OBJ minimal refuse les polygones non triangulés, UV et matériaux : il ne remplace pas les importeurs artistiques de Studio.

## Scènes, fichiers et configuration

- **Source éditable :** `.blockage` et ses sidecars restent inchangés. **Données de jeu :** `content/level.bns`. Des boîtes, sphères, cylindres et plans opaques passent par le profil natif. Les groupes sont aplatis en espace monde ; une matrice cisaillée, une piste animée, un comportement Studio, un matériau texturé ou un objet non pris en charge arrêtent l’export avec nom et ID. Seules les boîtes non tournées sont transférées en colliders. Les rebonds/sons/objectifs du jeu s’écrivent en C++.
- **BNS1 v1 :** en-tête de 16 octets (magic, version, nombre d’objets, CRC32 du payload), champs little-endian, transform en float32, identités de longueur bornée ; maximum 8 Mio / 20 000 objets. Le lecteur ne désérialise aucune structure mémoire brute. Le CRC détecte une corruption, ce n’est pas une signature.
- **Installation :** `BlockageGame.exe`, `game.cfg`, `content/level.bns`, licences et assets/DLL explicitement sélectionnés. Les chemins du jeu sont relatifs à l’exécutable, pas au répertoire de travail. Le rapport de construction et les scripts Steam restent **en dehors** du contenu destiné au joueur.
- **Profil Windows :** `%LOCALAPPDATA%/BlockageGames/<game_id>/`. L’exemple y écrit `best.sav` par remplacement de fichier temporaire. Un `settings.cfg` utilisateur peut surcharger `width`, `height`, `vsync`, `volume` (0–100), pas `game_id`. Exemple : `width=1920`, `height=1080`, `vsync=1` sur trois lignes.
- **Dépendances :** CRT statique en MSVC. La vérification PE accepte les DLL système connues et exige la déclaration des autres par `--dll nom.dll` (fichier à côté du binaire). Elle ne découvre pas un chargement optionnel via `LoadLibrary` : déclare ces bibliothèques toi-même et vérifie les droits de redistribution.

## SteamPipe : du paquet à une build candidate

```powershell
# D’abord construire le jeu Release (voir README), puis depuis les sources :
.\npm.cmd run native:export -- --binary build/native/Release/BlockageGame.exe --scene src/native/sample/beacon-run.blockage --out native-out/candidate-001 --app-id TON_APPID --depot-id TON_DEPOTID
```

Remplace les deux identifiants par ceux attribués à ton application dans Steamworks. `--scene` accepte également un `.bns` exporté par Studio. L’exporteur refuse une sortie existante et ne demande ni mot de passe ni clé. Cette commande **n’envoie rien**.

1. Dans Steamworks, configure le lancement de `BlockageGame.exe` pour Windows et le dépôt associé.
2. Dans une session SteamCMD authentifiée par **toi**, utilise `run_app_build` avec le chemin absolu de `steam/app_preview.vdf`. Cette configuration contient `Preview 1` : contrôle la liste sans envoyer la build.
3. Après vérification, `steam/app_candidate.vdf` permet un upload explicite (`Preview 0`). Aucun script ne contient `SetLive` : l’upload ne sélectionne pas automatiquement une branche publique.
4. Affecte la build à une branche de test, installe-la depuis le client Steam sur un Windows propre et teste lancement, sauvegarde, mises à jour, contrôles, affichage et audio. La publication et la revue Valve restent distinctes. Aucun SDK Steamworks propriétaire, AppID emprunté ou fichier de connexion n’est livré.

Documentation Valve : [Uploading to Steam / SteamPipe](https://partner.steamgames.com/doc/sdk/uploading) et [Releasing](https://partner.steamgames.com/doc/store/releasing).

## Nettoyage, mesures et limites

Dans Studio, la projection des particules de tissu sur une boîte ne construit plus deux tableaux de bornes et des tableaux de faces dans sa boucle interne. L’historique ne parse plus chaque instantané au moment où on le prend : la copie modifiable est reconstruite à l’undo/redo ; le calcul du budget d’une pile n’est effectué qu’une fois par purge. Les importeurs, l’ancien logo et les scènes utilisateur ont été conservés.

Test de charge reproductible : `blockage_tests CHEMIN/level.bns DOSSIER_TEST --bench`. Sur **4 096 corps espacés sur Z**, le balayage soumet **0 paire** au test détaillé au lieu des **8 386 560** paires du parcours exhaustif. Ce cas synthétique mesure l’élagage, pas les FPS. Un amas dense peut rester quadratique ; par défaut, les plafonds de 2 millions de visites et 65 536 contacts signalent explicitement une saturation. Pas de CCD, de solveur de joints ni de collision triangle/triangle.

Le backend natif est un forward renderer D3D11 avec éclairage par sommet et profondeur, **pas** le pipeline PBR de Studio. Le mixeur lit du PCM en mémoire ; ni streaming musical, ni spatialisation HRTF. L’hôte Linux sert aux tests sans fenêtre ; aucun support graphique Linux/Steam Deck n’est revendiqué. Le format de scène natif n’inclut pas encore les squelettes, le tissu, l’eau ni les shaders de modèles GLB de Studio.

**Contrôles de cette livraison :** exécutable PE32+ Windows x64 compilé et table des dépendances inspectée ; build Linux Release, parcours collecte → victoire → sauvegarde → nouvelle partie, aller-retour binaire JS/C++, config invalide et corruptions testés. Tests ASan/UBSan Linux sans détection de fuites (LeakSanitizer ne peut pas inspecter les processus dans cet environnement). Le lancement Windows réel, la sortie audio physique, le rendu sur RTX et le parcours Steam authentifié restent à valider avant sortie commerciale. Ni FPS garantis, ni certification AAA.

Priorité pour la suite : cooker de meshes et matériaux GLB partagé avec Studio ; animations skinnées ; mesure GPU et budgets de streaming ; tests de régression visuels sur plusieurs pilotes avant d’élargir le profil d’export.
