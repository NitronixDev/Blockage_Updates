# Blockage 0.6 — guide et périmètre réel

## Commencer

1. Extraire le ZIP complet, puis lancer START_BLOCKAGE.bat. Conserver START_BLOCKAGE_COMPAT.bat en cas de refus du pilote WebGPU.
2. Ouvrir **File → Studio Lighting Lab…** pour tester la scène originale intégrée. L'éditeur propose de sauvegarder la scène actuelle avant le remplacement.
3. Choisir **Balanced** dans Quality, puis **Cinematic** pour activer l'occlusion ambiante GTAO. Les réglages d'exposition, de remplissage et les matériaux ne sont pas écrasés par les profils.
4. Ouvrir **World Settings** avec la roue dentée. Pour un modèle sombre, vérifier d'abord Exposure, Hemisphere Fill, Environment IBL et les lumières. L'échelle de l'objet influence aussi le brouillard et le rayon d'occlusion.
5. Ouvrir **Profiler**, réinitialiser les échantillons une fois les shaders chargés, puis comparer la même caméra à la même résolution. L'export JSON contient les réglages et les derniers échantillons.

## Graphismes

| Contrôle | Effet réel |
| --- | --- |
| Spot Light | Cône orientable selon l'axe local −Z ; demi-angle, pénombre, portée et intensité en candela. |
| Environment IBL | Intensité de l'environnement de studio préfiltré intégré. Pas d'import HDRI ni de capture de réflexion dynamique dans cette version. |
| Hemisphere Fill | Remplissage diffus hémisphérique, distinct de l'IBL. Un réglage trop fort aplatit le contraste. |
| Tone Mapping | AgX, ACES Filmic ou Neutral ; ne crée pas de détails absents des textures. |
| Bloom | Intensité, seuil lumineux et rayon ; circuit de post-traitement supprimé lorsqu'aucun effet n'est actif. |
| GTAO | Occlusion de l'éclairage indirect calculée en espace écran, à demi-résolution, 8 échantillons avec débruitage. Prépass normales/profondeur supplémentaire. Ni ray tracing ni GI ; des effets de bord d'écran restent possibles. |
| Shadow Quality | Cartes directionnelles/spot 512, 1024 ou 2048 ; cartes ponctuelles 256, 512 ou 512 par face. |
| Max Shadow Lights | Priorité à l'ordre de la scène. Les lumières hors budget continuent d'éclairer, sans ombre. |

Le cache d'ombres est utilisé uniquement lorsque la simulation est arrêtée. Les éditions et changements de scène l'invalident. Lecture reprend les mises à jour à chaque image ; les ombres ne sont pas figées sur les personnages animés.

## Performances et mesures

- Les instances statiques compatibles partagent leurs dessins GPU. Les groupes sont découpés en cellules 3D de 32 m pour conserver un culling spatial utile. Les originaux gardent leurs IDs, hiérarchie et données de collision ; sélectionner un objet l'exclut temporairement du batch pour l'éditer.
- Les limites de la sélection ne sont plus recalculées pendant une caméra immobile ou en mouvement si l'objet n'a pas changé.
- La résolution adaptative est optionnelle. Elle observe les intervalles entre images et les coûts CPU, diminue le nombre de pixels par petits paliers lors d'une surcharge persistante non dominée par le CPU, et remonte plus lentement. Elle reste entre Minimum Scale et Render Scale. Elle ne remplace ni la simplification des meshes, ni un moteur de streaming, ni DLSS/FSR.
- La cible FPS est une cible du contrôleur, pas un limiteur d'images ni une promesse de performance.
- Le profiler conserve 240 échantillons récents, dont les longues images visibles. Le p95 indique un temps d'image dépassé par environ 5 % des échantillons ; ce n'est pas le « 1 % low ».
- CPU update mesure la logique du rendu/éditeur et la simulation ; CPU submit mesure le temps de soumission de la scène. Aucun de ces compteurs ne mesure l'exécution des commandes sur le GPU.
- Les compteurs dessins/triangles incluent les passes d'ombres et les effets. Les nombres de textures/géométries ne sont pas des octets de VRAM. La résolution affichée est celle du tampon rendu, pas celle du bureau.

### Vérification de cette livraison

108 tests Node, dont 13 nouveaux tests ciblés : migration de scènes, validation des réglages, profils, hystérésis, statistiques, spotlights/prefabs, batching/exclusions, nommage, audit et scène de démonstration. Vérification syntaxique de tous les fichiers JavaScript.

Application Electron réellement lancée sous Linux / WebGL 2 / SwiftShader : changement de profils et tone mapping, activation/désactivation GTAO/bloom, profiler, audit, création de spotlight, sauvegarde logique des réglages par validation et cycle Lecture/Arrêt. Aucune erreur JavaScript ou console dans ce parcours. Ce test ne remplace pas une validation Windows sur ton nouveau PC RTX 5060 / Ryzen 7 5700X.

Le chemin WebGPU de cet environnement headless échoue avec « Instance dropped in popErrorScope ». Il n'est donc pas validé ici sur GPU matériel. Le lanceur de compatibilité reste disponible ; les FPS observés avec le rasteriseur logiciel ne prédisent pas ceux de ta carte graphique.

Test isolé de rendu : 256 instances opaques d'un même GLB, 257 dessins sans batching, 2 avec batching. Ce n'est pas un benchmark AAA ni un résultat sur ta scène Poppy Playtime.

## Compatibilité

Format scène 7, lecture des formats 1 à 6. Les valeurs artistiques existantes sont conservées. Les nouvelles scènes utilisent un remplissage plus modéré. L'ancien logo, les chemins d'import automatiques et le dépôt NitronixDev/Blockage_Updates restent inchangés. Le patch 0.6 s'applique à partir de 0.5.1 ; garder les ZIP intermédiaires sur GitHub.

Les limites d'import et de simulation restent celles documentées dans README.md. Les augmenter arbitrairement ne garantirait pas de meilleures performances.

## Ce qui manque encore pour viser un grand studio

Pas de prétention à « toutes les fonctions de tous les moteurs ». Restent notamment : partition/streaming du monde, génération de LOD et géométrie virtualisée, occlusion GPU à grande échelle, GI dynamique/ray tracing, import HDRI et probes de réflexion locales, système de navigation/IA, réseau/réplication, graphe de matériaux et scripts, animation graph/retargeting/IK avancés, light baking, cook d'assets et builds autonomes multiplateformes, collaboration multi-utilisateur et intégration de contrôle de versions, certification consoles et couverture matérielle étendue. Les systèmes de physique existants restent des solveurs simplifiés, pas un équivalent de PhysX/Chaos/Havok.

Le prochain chantier pertinent dépend des profils enregistrés sur des scènes représentatives : séparer limites CPU, GPU, mémoire et chargement avant de choisir l'optimisation.

Références techniques de l'intégration : [Three.js GTAONode](https://threejs.org/docs/pages/GTAONode.html), [RenderPipeline](https://threejs.org/docs/pages/RenderPipeline.html), [InstancedMesh](https://threejs.org/docs/pages/InstancedMesh.html), [SpotLight](https://threejs.org/docs/pages/SpotLight.html). Les APIs ont aussi été vérifiées dans la dépendance locale verrouillée 0.186.1.
