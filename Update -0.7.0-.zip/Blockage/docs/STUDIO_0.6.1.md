# Blockage 0.6.1 — Studio Workspace

Éditeur 3D desktop Windows : imports de modèles, rigging, contrôleur de joueur, animations, physique, terrain, eau avec ripples, particules, audio et scènes portables. Le logo existant est conservé.

Cette version améliore concrètement l'éditeur, l'éclairage et les coûts de rendu. **Blockage reste un moteur expérimental Electron / Three.js : ce n'est pas encore un moteur AAA complet ou certifié pour de grands studios.** Voir [STUDIO_0.6.md](docs/STUDIO_0.6.md) pour les nouveautés, mesures et limites.

## Créer l’application Electron Windows

Depuis le dossier **des sources** qui contient `package.json`, sur Windows x64 :

```sh
npm ci
npm run dist
```

Avec le runtime portable plutôt qu'une installation globale de Node, utilise directement ` .\npm.cmd run dist ` dans PowerShell. Le premier build télécharge ses outils ; le résultat est **dist/Blockage-Setup-0.6.1-x64.exe**, installable pour l’utilisateur courant. L'utilisateur final n'a pas besoin de npm. `npm run dist:dir` produit le dossier complet de l'application sans installateur. Ne copie pas `Blockage.exe` seul. La construction ne publie rien. Voir [la distribution desktop](docs/DISTRIBUTION.md).

## Mettre à jour sans décompresser à la main

Pour mettre à jour **Blockage 0.6.0**, dépose uniquement **Update -0.6.1-.zip**, tel quel, à la racine de **NitronixDev/Blockage_Updates**. Dans l'éditeur Windows : **Help → Check for updates → Download Update → Save & Restart**. Il télécharge, décompresse et vérifie le correctif, puis remplace les composants après fermeture. Garde les anciens ZIP pour les installations plus anciennes.

À partir de **0.6.1**, tu peux aussi choisir un correctif ultérieur déjà téléchargé : **Help → Install Update ZIP…**. Utilise uniquement une archive de confiance. Ce sélecteur n'existe pas encore dans la 0.6.0. Ne lui donne pas l'archive de sources **Blockage_GitHub_0.6.1.zip**.

Dans le **Profiler**, `Frame p99` et `Frames over budget` indiquent les pointes et la part des dernières images qui dépassent la cible (8,33 ms à 120 FPS). Ces mesures sont aussi exportées en JSON ; elles ne promettent aucun débit sur un matériel précis.

## Nouveautés studio de la série 0.6

- Interface sombre harmonisée : Scene Hierarchy, Inspector, Content Browser, Sequencer, Output Log et Profiler. Les noms de tes objets existants restent inchangés ; les nouveaux objets reçoivent des noms lisibles et uniques.
- Profils Performance, Balanced et Cinematic, résolution adaptative optionnelle avec limites et hystérésis, résolution réelle visible dans la barre d'état.
- Profiler : historique des temps d'image, médiane/p95, coûts CPU de mise à jour et de soumission, dessins GPU, triangles, instances, ressources et export JSON. Ce ne sont pas des mesures du temps GPU ou de VRAM.
- Projecteurs Spot Light orientables, contrôle indépendant de l'environnement IBL et du remplissage, AgX / ACES Filmic / Neutral, bloom réglable et GTAO débruitée optionnelle pour l'occlusion de l'éclairage indirect.
- Cartes d'ombres réglables, budget de lumières avec ombres, cache automatique à l'arrêt dans l'éditeur, mises à jour continues pendant la simulation.
- Instancing des meshes opaques statiques de modèles répétés, partition spatiale, boîte de sélection mise à jour uniquement quand nécessaire, circuit direct sans post-traitement si bloom et GTAO sont désactivés.
- **File → Studio Lighting Lab…** : scène originale intégrée, sans téléchargement. **Scene Audit** : diagnostic consultatif, sans modification automatique.

## Fichiers à mettre sur GitHub

Pour publier **seulement la mise à jour**, un seul fichier : **Update -0.6.1-.zip**, non extrait. Si tu souhaites aussi héberger le code et construire des installateurs depuis GitHub, extrais **Blockage_GitHub_0.6.1.zip** à la racine du dépôt. L'archive de sources contient le correctif et les trois précédents. Aucun fichier n'a été publié automatiquement sur GitHub.

Le dépôt des mises à jour est fixé dans le code : https://github.com/NitronixDev/Blockage_Updates. Aucun lien ni chemin Blender à renseigner dans les préférences. Le dépôt doit être public pour le téléchargement intégré.

Pour passer manuellement une installation 0.4.x à la version 0.5.0 : ferme Blockage, ouvre **Update -0.5.0-.zip**, puis copie le contenu de son dossier **Blockage** dans l'installation existante en remplaçant les fichiers. Les mises à jour suivantes se préparent dans **Help → Check for updates**, puis s'appliquent avec **Save & Restart**.

## Démarrage Windows corrigé

Extrais toute l'archive dans un dossier, puis double-clique sur **START_BLOCKAGE.bat**. Les lanceurs normal, compatibilité, Vulkan et joueur préparent automatiquement les composants manquants. Le premier démarrage peut prendre plusieurs minutes et demande Internet. Aucune installation globale de Node ni aucun droit administrateur n'est nécessaire.

Le runtime portable est téléchargé depuis nodejs.org et vérifié par SHA-256. Les dépendances exactes de package-lock.json et Electron sont préparés dans un dossier temporaire avant de remplacer les composants manquants ou incomplets. Les projets et scènes restent dans leurs dossiers. Une installation prête démarre directement, sans téléchargement.

En cas d'installation interrompue, relance **START_BLOCKAGE.bat**. Pour réinstaller les dépendances, utilise **scripts/INSTALL_DEPENDENCIES.bat**. Le diagnostic est enregistré dans **blockage-install.log**. L'archive **Update -VERSION-.zip** reste un correctif à appliquer dans une installation existante ; pour installer depuis zéro, utilise le ZIP GitHub complet ou la distribution Windows.

Le ZIP de mise à jour remplace les dossiers inclus sur place, sauvegarde leur ancienne version et les restaure si le remplacement échoue. Il conserve les autres dossiers de l'installation, les projets et le cache des modèles. Les ZIP sont vérifiés avant leur application.

## Imports et limites

**23 extensions** : GLB, GLTF, OBJ, FBX, STL, PLY, DAE, 3MF, 3DS, AMF, MD2, VTK, VTP, XYZ, PCD, VOX, DRC, BLEND, ABC, USD, USDA, USDC et USDZ.

- Desktop : **1 Gio par modèle et ses fichiers associés**, **8 Gio d'assets par projet**, **2 000 assets** et **20 000 entités**.
- Textures et audio : **128 Mio par fichier**.
- Navigateur : **200 Mio par modèle**, **300 Mio d'assets intégrés**, conversions BLEND/USD/ABC dans l'application desktop.
- Scènes et prefabs JSON : **450 Mio**. Les nouveaux imports desktop sont des binaires séparés et ne gonflent pas le JSON.
- Modèle rendu : **10 millions de vertices, 8 192 meshes, 1 024 os, 1 024 clips**. Ces budgets sont des plafonds d'import ; le GPU et la RAM restent déterminants.

L'import multiple et l'import de dossier restent disponibles. Les matériaux et textures compagnons sont retrouvés automatiquement dans le dossier choisi. Draco, Meshopt et KTX2 sont pris en charge pour GLTF/GLB. XYZ et PCD s'affichent comme des nuages de points.

BLEND, USD et Alembic utilisent Blender détecté automatiquement. S'il manque, Blockage télécharge une version portable 4.5.9 depuis le serveur officiel, vérifie son SHA-256 et la conserve pour les prochains imports. Le premier téléchargement demande une connexion ; les suivants utilisent le convertisseur local. L'exécution automatique des scripts contenus dans les BLEND est désactivée.

Les formats propriétaires MAX, C4D, SKP, MA et MB demandent un export dans un format pris en charge. Les contraintes, shaders propres à un logiciel et caches dont la topologie change ne sont pas tous transposables dans un moteur de jeu.

## Sauvegarder et déplacer un projet

La scène est enregistrée dans **Nom.blockage** et ses nouveaux binaires dans **Nom.blockage.assets/**. Déplace ou partage les deux ensemble. Un prefab utilise **Nom.blockageprefab** et **Nom.blockageprefab.assets/**. Le cache de récupération reste indépendant de l'installation du moteur.

Le format de scène **7** lit les versions **1 à 6** sans changer leurs noms, transformations ou valeurs d'éclairage existantes. Les scènes nouvellement enregistrées nécessitent **Blockage 0.6.0**. Conserve une copie de tes scènes avant de les réenregistrer si tu veux pouvoir revenir à 0.5.x. Les anciens assets intégrés en Base64 continuent à fonctionner.

## Performances

Le moteur regroupe les primitives opaques immobiles et les meshes compatibles des modèles répétés par géométrie, matériau et cellules de 32 m. Les meshes animés, skinnés, transparents, miroirs, morphés ou sélectionnés restent séparés. Les colliders sont gardés en cache, les recherches spatiales sont indexées et seules les entités actives sont évaluées pendant la simulation. Deux importeurs de modèles travaillent au maximum en parallèle. Les textures et sons inutilisés sont décodés lorsqu'ils sont affectés à une entité.

Les rigs réutilisent leurs buffers et possèdent des limites spatiales conservatrices pour le culling. Le joueur et les animations proches restent évalués à 60 Hz ; les rigs éloignés passent à 30 ou 15 Hz. Les lectures GLB évitent les portions BIN inutilisées.

Une scène de **1 600 cubes avec un joueur**, testée avec Electron Linux / WebGL / SwiftShader, est passée de **1 509 à 6 appels de dessin GPU**. Son pas de simulation mesuré est passé d'environ **37,4 ms à moins de 1 ms**. Les FPS d'un autre jeu dépendent de ses scripts, physiques, lumières, meshes et du matériel.

Nouveau test 0.6 : **256 instances du même GLB**, même scène sans ombres ni post-traitement : **257 appels de dessin sans regroupement, 2 avec regroupement** (1 batch de 256 meshes). Sur dix images immobiles, la boîte de sélection n'a été recalculée **aucune fois**, puis s'est bien actualisée après une modification. Ce test isolé mesure des coûts évités, pas un gain de FPS universel.

## Développer et construire

Dépendances conservées : Node 26.11.1, npm 12.2.0, Electron 44.7.0, Three.js 0.186.1.

```sh
npm ci
npm test
npm run check
npm run examples
npm start
```

Pour créer un ZIP ne contenant que les composants modifiés par rapport à une ancienne copie :

```sh
npm run update -- --base /chemin/ancienne-version
```

La version de package.json détermine le nom **Update -VERSION-.zip**. Si les dépendances ou le moteur Node changent, le générateur inclut respectivement node_modules ou runtime ; ils doivent alors contenir les binaires Windows. Les options --include-dependencies et --include-runtime permettent de les inclure explicitement.

Le workflow GitHub construit la distribution Windows et le ZIP de composants lors d'un tag vVERSION. Conserve les anciennes mises à jour pour permettre aux clients de les appliquer dans l'ordre. Voir [GITHUB_UPDATES.md](docs/GITHUB_UPDATES.md) et [IMPORTS_AND_CHARACTERS.md](docs/IMPORTS_AND_CHARACTERS.md).
