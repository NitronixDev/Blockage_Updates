# Imports, rigs et personnages

Importe plusieurs fichiers par **File → Import Assets**, ou choisis **File → Import Model Folder**. Le dossier est parcouru sur huit niveaux, avec au plus 100 modèles et 4 000 entrées. Les symlinks sont ignorés. Double-clique un modèle dans Assets pour l'ajouter à la scène.

## Formats

| Import natif | Conversion automatique |
| --- | --- |
| GLB, GLTF, OBJ, FBX, STL, PLY, DAE, 3MF | BLEND |
| 3DS, AMF, MD2, VTK, VTP | USD, USDA, USDC, USDZ |
| XYZ, PCD, VOX, DRC | ABC (Alembic) |

GLTF/GLB disposent de décodeurs Draco, Meshopt et KTX2 inclus dans les dépendances du moteur. Les modèles OBJ peuvent utiliser MTL, PNG, JPEG, WebP, BMP, TGA et DDS. Les ressources locales restent dans le dossier sélectionné, y compris au-dessus d'un sous-dossier de modèles lors d'un import de dossier.

Le convertisseur détecte Blender normalement installé ou runtime/blender, puis télécharge et vérifie une version portable s'il manque sur Windows x64/ARM64 ou Linux x64. Sur macOS, Blender installé dans Applications est détecté. Les formats MAX, C4D, SKP, MA et MB doivent être exportés par leur logiciel dans un format listé.

Alembic conserve les transformations et les déformations à topologie constante en les convertissant en clés et morph targets. Le baking est limité à 600 frames et 32 millions d'échantillons de vertices ; les caches volumineux doivent être découpés en clips. Les changements de nombre ou de connexions des vertices sont signalés.

## Gros fichiers

Desktop : 1 Gio par bundle de modèle, 128 fichiers compagnons, 8 Gio d'assets et 2 000 assets par projet. Une scène supporte 20 000 entités. Les budgets de cloth, fluides, particules et rigid bodies restent contrôlés pour éviter des allocations excessives ; augmente la complexité progressivement.

Les nouveaux fichiers natifs sont conservés sous une empreinte SHA-256. Une sauvegarde copie les binaires nécessaires dans le dossier .assets associé à la scène ou au prefab. Annuler une action ne recopie pas les modèles. L'import ne dépend plus de chaînes Base64 gigantesques.

Le renderer accepte jusqu'à 10 millions de vertices, 8 192 meshes, 1 024 os et 1 024 clips par modèle. Le navigateur conserve une limite de 200 Mio et les conversions utilisent le desktop.

## Rigging et animations

Les skins, os, clips et morph targets importés sont conservés lorsque le format ou sa conversion les fournit. Pour un mesh statique, **Create Rig** crée une chaîne ou un humanoïde approximatif. Cette génération est limitée à 100 000 vertices ; inspecte et ajuste les poids pour un personnage de production.

**Show Skeleton**, le sélecteur d'os et **Use Bone Gizmo** permettent de manipuler un os. Les poses s'enregistrent dans des clés avec interpolation linéaire, smooth ou step. Les réglages de clip contrôlent lecture, vitesse, boucle et fondu.

Les skins possèdent des limites conservatrices calculées à partir des influences des os. Elles permettent le culling sans recalculer tous les vertices à chaque frame. Les animations proches et le joueur utilisent 60 Hz ; les rigs éloignés utilisent 30 ou 15 Hz.

## Joueur

Ajoute **Player**, ou active **Player Controller** sur un modèle avec clips. Une seule entité de la scène peut avoir ce contrôleur actif. Affecte les clips Idle, Walk, Run et Jump, puis règle accélération, freinage, rotation, hauteur/rayon de capsule et durée des transitions.

Lance **Play**, passe en **Game**, puis clique le viewport. WASD/ZQSD déplacent le personnage, Shift fait courir, Space saute et RMB + souris oriente la caméra. Les collisions utilisent les primitives, plans et terrains. Place des colliders simples autour des modèles complexes.

La caméra peut être à la première ou à la troisième personne. Stop restaure les transforms et poses éditées. Les prefabs conservent le rig, les clips, la configuration du joueur et les liens internes ; leur import désactive un deuxième contrôleur actif.
