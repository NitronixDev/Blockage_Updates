# Mises à jour Blockage

Le dépôt est intégré au moteur : **NitronixDev/Blockage_Updates**. L'utilisateur dispose seulement d'une case de vérification au démarrage, jamais d'un champ de lien ou de chemin.

## Publier le ZIP

Pour cette version, dépose **Update -0.7.0-.zip** sans le décompresser à la racine du dépôt public. Le correctif part de **0.6.1** ; garde les ZIP des versions précédentes afin que les clients puissent avancer dans l’ordre. Le dépôt et le blob téléchargé sont vérifiés comme auparavant. Ce circuit met à jour l’éditeur et ses sources : le jeu natif distribué n’embarque pas l’updater GitHub.

Une Release GitHub peut aussi porter ce même fichier. Son digest SHA-256 fourni par GitHub, ou le fichier SHA256SUMS.json généré avec le ZIP, valide le téléchargement. Les releases stables sont proposées dans l'ordre croissant ; conserve les versions intermédiaires lorsque les patchs dépendent d'elles.

Le ZIP contient un dossier **Blockage/**, les composants à remplacer et **update.json**. Chaque dossier inclus est une copie complète de sa nouvelle version. Un dossier absent reste intact. Les dossiers src, electron, scripts, assets, docs, tests, .github, runtime et node_modules sont les seuls dossiers remplaçables ; quelques fichiers racine du moteur sont également autorisés.

Le manifeste annonce la version, la version minimale et les SHA-256 de chaque fichier. Le moteur refuse les fichiers non annoncés, les liens symboliques, les chemins sortant de l'archive, les doublons, un changement de dépendances sans node_modules et un changement de Node sans runtime.

## Installer sur place

1. Check for updates découvre les ZIP sans configuration.
2. Download Update télécharge, extrait et contrôle les fichiers hors de l'installation.
3. Save & Restart sauvegarde la scène et lance un petit programme de remplacement.
4. Le programme attend la fermeture de Blockage, copie les fichiers sur le volume de l'installation, sauvegarde les anciens composants, remplace les dossiers et relance cette même installation.
5. Une erreur de remplacement déclenche une restauration. Les sauvegardes sont conservées dans **.blockage-updates/**.

Les dossiers des projets, les scènes, leurs assets et les données utilisateur ne figurent pas dans les composants remplaçables. Le runtime de lancement du programme de remplacement est copié hors de l'installation afin de pouvoir mettre runtime à jour sur Windows.

En 0.6.1 et au-delà, **Help → Install Update ZIP…** ouvre un sélecteur de fichier pour un correctif ultérieur au format **Update -VERSION-.zip**. Une confirmation rappelle que ce ZIP contient du code exécutable. Le nom, la version courante, le manifeste, les chemins et les SHA-256 sont contrôlés ; les sommes de contrôle internes ne constituent pas une signature d'auteur. L'original sélectionné reste intact. Annuler n'applique rien. Seuls les composants inclus seront remplacés, **en entier** : garde les projets hors de `src`, `assets`, `scripts`, etc.

Une application installée par **Setup.exe** redémarre via son propre `Blockage.exe`. Elle accepte les correctifs de code mais refuse un ZIP contenant `runtime` ou `node_modules` : utilise le nouvel installateur pour changer le runtime ou les dépendances. Les sauvegardes du moteur ne remplacent pas des sauvegardes de projet.

## Générer la prochaine version

Modifie package.json et package-lock.json, puis lance :

```sh
npm test
npm run check
npm run update -- --base /chemin/Blockage-0.6.1
```

Le générateur compare les dossiers par contenu et ajoute seulement les composants modifiés, plus package.json. **--min-version VERSION** permet d'annoncer une base compatible plus ancienne lorsqu'elle a été vérifiée. Sans --base, tous les composants source sont inclus. **--include-runtime** et **--include-dependencies** permettent d'inclure les binaires si nécessaire.

Le workflow de release taggé construit l'installateur Windows et le ZIP portable, puis prépare le correctif à partir du tag précédent. Le workflow manuel **Build Windows installer** génère l'installateur sans publier de release. L'installation automatique des correctifs et le redémarrage visent Windows.

Références API : [contenu des dépôts](https://docs.github.com/en/rest/repos/contents) et [assets de Releases](https://docs.github.com/en/rest/releases/assets). Les appels de contenu brut utilisent application/vnd.github.raw+json.
