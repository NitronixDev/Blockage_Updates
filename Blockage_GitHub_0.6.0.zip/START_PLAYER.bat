@echo off
setlocal
call "%~dp0scripts\launch-windows.cmd" player
exit /b %errorlevel%
