const fs = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');
const { createReadStream } = require('node:fs');
const REPOSITORY = 'NitronixDev/Blockage_Updates';
const DIRECTORIES = ['src','electron','scripts','assets','runtime','node_modules','docs','tests','.github'];
const ROOT_FILES = ['package.json','package-lock.json','README.md','LICENSE','.gitignore','START_BLOCKAGE.bat','START_BLOCKAGE_COMPAT.bat','START_BLOCKAGE_VULKAN.bat','START_PLAYER.bat','start.sh','npm.cmd'];
function version(value) {
  const match = /^v?(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/.exec(String(value));
  if (!match || match.slice(1).some(n => !Number.isSafeInteger(Number(n)) || Number(n) > 999999)) throw new Error('Use a stable semantic version.');
  return match.slice(1).map(Number);
}
function newer(a,b) { const x=version(a),y=version(b);for(let i=0;i<3;i++)if(x[i]!==y[i])return x[i]>y[i];return false; }
const updateName = value => { version(value); return `Update -${value.replace(/^v/,'')}-.zip`; };
async function hashFile(filename) { const hash=crypto.createHash('sha256');for await(const chunk of createReadStream(filename))hash.update(chunk);return hash.digest('hex'); }
async function listFiles(root, prefix='') {
  const files=[];
  async function walk(directory, relative) {
    for(const entry of await fs.readdir(directory,{withFileTypes:true})) {
      const name=relative?relative+'/'+entry.name:entry.name;
      if(entry.isSymbolicLink())throw new Error('Update contains a symbolic link.');
      if(entry.isDirectory())await walk(path.join(directory,entry.name),name);
      else if(entry.isFile())files.push(name);else throw new Error('Unsupported update file.');
      if(files.length>10000)throw new Error('Update contains too many files.');
    }
  }
  await walk(root,prefix);return files.sort();
}
async function validatePatch(root,{expectedVersion,currentVersion,installationRoot}={}) {
  const stat=await fs.lstat(path.join(root,'update.json'));
  if(!stat.isFile()||stat.isSymbolicLink()||stat.size>2*1048576)throw new Error('Invalid update manifest.');
  const manifest=JSON.parse(await fs.readFile(path.join(root,'update.json'),'utf8'));
  if(manifest.format!=='blockage.update'||manifest.schema!==1||manifest.repository!==REPOSITORY)throw new Error('This is not a Blockage update ZIP.');
  version(manifest.version);version(manifest.minVersion);
  if(expectedVersion&&manifest.version!==expectedVersion)throw new Error('Update version does not match GitHub.');
  if(currentVersion&&(!newer(manifest.version,currentVersion)||newer(manifest.minVersion,currentVersion)))throw new Error('This update does not support the installed Blockage version.');
  if(!Array.isArray(manifest.components)||!manifest.components.length||manifest.components.length>DIRECTORIES.length+ROOT_FILES.length||!manifest.components.includes('package.json')||new Set(manifest.components).size!==manifest.components.length)throw new Error('Invalid update components.');
  for(const component of manifest.components) {
    if(!DIRECTORIES.includes(component)&&!ROOT_FILES.includes(component))throw new Error('Update may replace only Blockage engine folders.');
    const info=await fs.lstat(path.join(root,component));
    if(info.isSymbolicLink()||DIRECTORIES.includes(component)!==info.isDirectory())throw new Error('Invalid update component type.');
  }
  if(!Array.isArray(manifest.files)||!manifest.files.length||manifest.files.length>10000)throw new Error('Invalid update file list.');
  const names=new Set();let total=0;
  for(const file of manifest.files) {
    if(typeof file.path!=='string'||file.path.length>500||file.path.includes('\\')||file.path.startsWith('/')||file.path.split('/').some(p=>!p||p==='.'||p==='..')||/[\x00-\x1f:]/.test(file.path)||!manifest.components.some(c=>file.path===c||file.path.startsWith(c+'/'))||names.has(file.path.toLowerCase())||!Number.isSafeInteger(file.bytes)||file.bytes<0||file.bytes>600*1048576||!/^[a-f0-9]{64}$/.test(file.sha256))throw new Error('Invalid update file entry.');
    names.add(file.path.toLowerCase());total+=file.bytes;if(total>2*1073741824)throw new Error('Update exceeds 2 GiB after extraction.');
    const filename=path.join(root,...file.path.split('/')),info=await fs.lstat(filename);
    if(!info.isFile()||info.isSymbolicLink()||info.size!==file.bytes||await hashFile(filename)!==file.sha256)throw new Error('Update file SHA-256 verification failed: '+file.path);
  }
  const actual=(await listFiles(root)).filter(n=>n!=='update.json');
  if(actual.length!==manifest.files.length||actual.some(n=>!names.has(n.toLowerCase())))throw new Error('Update contains unannounced files.');
  const pkg=JSON.parse(await fs.readFile(path.join(root,'package.json'),'utf8'));
  if(pkg.name!=='blockage-engine'||pkg.version!==manifest.version||pkg.main!=='electron/main.cjs')throw new Error('Update package identity does not match.');
  if(installationRoot) {
    const installed=JSON.parse(await fs.readFile(path.join(installationRoot,'package.json'),'utf8'));
    if(installed.name!=='blockage-engine'||installed.main!=='electron/main.cjs'||installed.version!==currentVersion)throw new Error('The installed Blockage version changed. Check for updates again.');
    for(const key of ['dependencies','devDependencies'])if(JSON.stringify(installed[key]||{})!==JSON.stringify(pkg[key]||{})&&!manifest.components.includes('node_modules'))throw new Error('Changed dependencies require a node_modules component.');
    if(JSON.stringify(installed.engines||{})!==JSON.stringify(pkg.engines||{})&&!manifest.components.includes('runtime'))throw new Error('A changed Node runtime requires a runtime component.');
  }
  return manifest;
}
module.exports={REPOSITORY,DIRECTORIES,ROOT_FILES,version,newer,updateName,hashFile,listFiles,validatePatch};
