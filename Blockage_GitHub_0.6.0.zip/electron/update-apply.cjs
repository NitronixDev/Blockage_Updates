const fs=require('node:fs/promises');
const path=require('node:path');
const crypto=require('node:crypto');
const {validatePatch,DIRECTORIES,ROOT_FILES}=require('./update-manifest.cjs');
const delay=ms=>new Promise(resolve=>setTimeout(resolve,ms));
async function rename(from,to) { for(let attempt=0;;attempt++){try{return await fs.rename(from,to);}catch(error){if(!['EACCES','EPERM','EBUSY'].includes(error.code)||attempt>=45)throw error;await delay(300);}} }
async function writeJournal(directory,journal) { const temporary=path.join(directory,'journal.tmp');await fs.writeFile(temporary,JSON.stringify(journal,null,2));await fs.rename(temporary,path.join(directory,'journal.json')); }
async function rollback(directory,journal) {
  journal.status='rolling-back';await writeJournal(directory,journal);
  for(const entry of [...journal.entries].reverse()) {
    if(!DIRECTORIES.includes(entry.path)&&!ROOT_FILES.includes(entry.path))throw new Error('Unsafe rollback component.');
    const backup=path.join(directory,'backup',entry.path),target=path.join(journal.root,entry.path),staged=path.join(directory,'new',entry.path);
    if(await fs.lstat(backup).catch(()=>null)) { await fs.rm(target,{recursive:true,force:true});await rename(backup,target); }
    else if(!entry.hadOriginal&&!(await fs.lstat(staged).catch(()=>null)))await fs.rm(target,{recursive:true,force:true});
  }
  journal.status='rolled-back';await writeJournal(directory,journal);
}
/** Copy to the installation volume before swapping; backups cover every replaced component. */
async function applyPatch({stagedRoot,installationRoot,currentVersion,expectedVersion,onSwap=()=>{}}) {
  const root=await fs.realpath(installationRoot);
  if(root===path.parse(root).root||root!==path.resolve(installationRoot))throw new Error('Invalid Blockage installation folder.');
  const manifest=await validatePatch(stagedRoot,{expectedVersion,currentVersion,installationRoot:root});
  const directory=path.join(root,'.blockage-updates',crypto.randomUUID()),fresh=path.join(directory,'new'),backup=path.join(directory,'backup');
  await fs.mkdir(fresh,{recursive:true});await fs.mkdir(backup);
  const journal={root,version:manifest.version,previousVersion:currentVersion,status:'preparing',entries:[]};
  try {
    // package.json is swapped last so its version describes a completed engine replacement.
    const components=[...manifest.components.filter(c=>c!=='package.json'),'package.json'];
    for(const component of components) {
      const old=await fs.lstat(path.join(root,component)).catch(()=>null);
      if(old?.isSymbolicLink())throw new Error('Installed engine components may not be symbolic links.');
      await fs.cp(path.join(stagedRoot,component),path.join(fresh,component),{recursive:true,dereference:false,errorOnExist:true,force:false});
      journal.entries.push({path:component,hadOriginal:!!old});
    }
    await fs.copyFile(path.join(stagedRoot,'update.json'),path.join(fresh,'update.json'));
    await validatePatch(fresh,{expectedVersion,currentVersion,installationRoot:root});
    journal.status='applying';await writeJournal(directory,journal);
    for(const entry of journal.entries) {
      if(entry.hadOriginal)await rename(path.join(root,entry.path),path.join(backup,entry.path));
      await rename(path.join(fresh,entry.path),path.join(root,entry.path));
      await onSwap(entry.path);
    }
    journal.status='committed';await writeJournal(directory,journal);await fs.rm(fresh,{recursive:true,force:true});
    return {ok:true,version:manifest.version,path:root,backup};
  } catch(error) {
    if(journal.status==='applying') { try { await rollback(directory,journal); } catch(restoreError) { throw new Error(error.message+' Automatic restore failed: '+restoreError.message+'. Backup: '+backup); } }
    else await fs.rm(directory,{recursive:true,force:true});
    throw error;
  }
}
async function recoverInterrupted(installationRoot) {
  const root=await fs.realpath(installationRoot),base=path.join(root,'.blockage-updates');let recovered=0;
  for(const name of await fs.readdir(base).catch(()=>[])) {
    if(!/^[a-f0-9-]{36}$/.test(name))continue;
    const directory=path.join(base,name),journal=JSON.parse(await fs.readFile(path.join(directory,'journal.json'),'utf8').catch(()=>'null'));
    if(journal?.root===root&&['applying','rolling-back'].includes(journal.status)){await rollback(directory,journal);recovered++;}
  }
  return recovered;
}
module.exports={applyPatch,recoverInterrupted};
