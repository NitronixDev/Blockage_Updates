const fs=require('node:fs/promises'),path=require('node:path'),{atomicWrite}=require('./files.cjs');
const defaults={autoCheck:true};
function validatePreferences(input){if(!input||typeof input.autoCheck!=='boolean')throw new Error('Invalid preferences.');return{autoCheck:input.autoCheck};}
class Preferences{constructor(directory){this.filename=path.join(directory,'preferences.json');this.value={...defaults};}async load(){try{this.value=validatePreferences(JSON.parse(await fs.readFile(this.filename,'utf8')));}catch{this.value={...defaults};}return this.value;}async save(input){const value=validatePreferences(input);await atomicWrite(this.filename,JSON.stringify(value,null,2));this.value=value;return value;}}
module.exports={Preferences,validatePreferences};
