const fs = require('node:fs');
const fsp = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');
const { Readable } = require('node:stream');
const { atomicWrite } = require('./files.cjs');

const validHash = hash => typeof hash === 'string' && /^[a-f0-9]{64}$/.test(hash);
function references(document) {
  return [...new Map((document.assets || []).flatMap(a => [a, ...(a.resources || [])])
    .filter(a => a.storage).map(a => [a.storage.hash, a.storage])).values()];
}
async function digest(filename) {
  const hash = crypto.createHash('sha256');
  for await (const chunk of fs.createReadStream(filename)) hash.update(chunk);
  return hash.digest('hex');
}
/** Immutable content-addressed binaries; scene history contains only small references. */
class AssetStore {
  constructor(directory) { this.directory = path.resolve(directory); this.verified = new Map(); }
  filename(hash, directory = this.directory) {
    if (!validHash(hash)) throw new Error('Invalid model asset hash.');
    return path.join(directory, hash + '.bin');
  }
  async check(reference, directory = this.directory) {
    const filename = this.filename(reference.hash, directory), stat = await fsp.lstat(filename).catch(() => null);
    if (!stat?.isFile() || stat.isSymbolicLink() || stat.size !== reference.bytes) throw new Error('Missing or damaged model asset: ' + reference.hash.slice(0, 12));
    const signature = `${stat.size}:${stat.mtimeMs}:${stat.ctimeMs}`;
    if (this.verified.get(filename) !== signature) {
      if (await digest(filename) !== reference.hash) throw new Error('Model asset SHA-256 verification failed.');
      this.verified.set(filename, signature);
    }
    return filename;
  }
  async put(buffer) {
    const reference = { hash: crypto.createHash('sha256').update(buffer).digest('hex'), bytes: buffer.length };
    await fsp.mkdir(this.directory, { recursive: true });
    try { await this.check(reference); } catch { await atomicWrite(this.filename(reference.hash), buffer); }
    await this.check(reference);
    return reference;
  }
  async putFile(filename, bytes) {
    const reference={hash:await digest(filename),bytes};await fsp.mkdir(this.directory,{recursive:true});
    try { await this.check(reference);return reference; } catch { /* A new immutable binary. */ }
    const target=this.filename(reference.hash),temporary=target+'.'+crypto.randomUUID()+'.tmp';
    try { await fsp.copyFile(filename,temporary,fs.constants.COPYFILE_EXCL);await fsp.rename(temporary,target);await this.check(reference);return reference; }
    finally { await fsp.rm(temporary,{force:true}); }
  }
  async copy(reference, directory) {
    const source = await this.check(reference), target = this.filename(reference.hash, directory);
    if (source === target) return;
    await fsp.mkdir(directory, { recursive: true });
    try { await this.check(reference, directory); return; } catch { /* Replace only our immutable hash-named file. */ }
    const temporary = target + '.' + crypto.randomUUID() + '.tmp';
    try {
      await fsp.copyFile(source, temporary, fs.constants.COPYFILE_EXCL);
      await fsp.rename(temporary, target);
      await this.check(reference, directory);
    } finally { await fsp.rm(temporary, { force: true }); }
  }
  async save(filename, document, text) {
    for (const reference of references(document)) await this.copy(reference, filename + '.assets');
    await atomicWrite(filename, text);
  }
  async restore(filename, document) {
    for (const reference of references(document)) {
      try { await this.check(reference); continue; } catch { /* Portable sidecar is the authoritative fallback. */ }
      const source = await this.check(reference, filename + '.assets');
      await fsp.mkdir(this.directory, { recursive: true });
      const temporary = this.filename(reference.hash) + '.' + crypto.randomUUID() + '.tmp';
      try { await fsp.copyFile(source, temporary); await fsp.rename(temporary, this.filename(reference.hash)); }
      finally { await fsp.rm(temporary, { force: true }); }
      await this.check(reference);
    }
    return document;
  }
  async response(request) {
    const url = new URL(request.url), hash = url.pathname.slice('/model-assets/'.length);
    if (url.hostname !== 'app' || url.search || url.hash || !validHash(hash)) return new Response('Not found', { status: 404 });
    const filename = this.filename(hash), stat = await fsp.lstat(filename).catch(() => null);
    if (!stat?.isFile() || stat.isSymbolicLink()) return new Response('Asset unavailable', { status: 404 });
    const range = request.headers.get('range');
    let start = 0, end = stat.size - 1, status = 200;
    const headers = { 'content-type': 'application/octet-stream', 'accept-ranges': 'bytes', 'cache-control': 'private, max-age=31536000, immutable' };
    if (range) {
      const match = /^bytes=(\d+)-(\d*)$/.exec(range);
      if (!match) return new Response(null, { status: 416, headers: { 'content-range': 'bytes */' + stat.size } });
      start = Number(match[1]); end = match[2] ? Math.min(Number(match[2]), end) : end;
      if (!Number.isSafeInteger(start) || !Number.isSafeInteger(end) || start > end || start >= stat.size) return new Response(null, { status: 416, headers: { 'content-range': 'bytes */' + stat.size } });
      status = 206; headers['content-range'] = `bytes ${start}-${end}/${stat.size}`;
    }
    headers['content-length'] = String(end - start + 1);
    return new Response(Readable.toWeb(fs.createReadStream(filename, { start, end })), { status, headers });
  }
}
module.exports = { AssetStore, references, digest, validHash };
