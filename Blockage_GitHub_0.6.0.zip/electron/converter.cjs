const fs = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');
const { spawn } = require('node:child_process');
const { extractZip } = require('./zip-reader.cjs');
const { findBlender } = require('./model-import.cjs');

const BLENDER_VERSION = '4.5.9';
const TARGETS = {
  'win32-x64': { archive: 'blender-4.5.9-windows-x64.zip', hash: '41da973b9bf95bb312cbeff4d1982feb13259b43c821686b9bafea4dfe5477cf', folder: 'blender-4.5.9-windows-x64', executable: 'blender.exe' },
  'win32-arm64': { archive: 'blender-4.5.9-windows-arm64.zip', hash: '1415f53f483a8d9040f459ab8c3a330c4523ef8f76f5f2db5a95fb2d5be54d4d', folder: 'blender-4.5.9-windows-arm64', executable: 'blender.exe' },
  'linux-x64': { archive: 'blender-4.5.9-linux-x64.tar.xz', hash: 'dcdc3eca6c9825bb35a8033b689c053f3cb5a9b0cd2a61b2eac2a49436b4ad3d', folder: 'blender-4.5.9-linux-x64', executable: 'blender' }
};
function unpackTar(archive, destination) {
  return new Promise((resolve, reject) => {
    const child = spawn('tar', ['-xf', archive, '-C', destination, '--no-same-owner'], { shell: false, windowsHide: true, stdio: ['ignore', 'ignore', 'pipe'] });
    let message = ''; child.stderr.on('data', data => { message = (message + data).slice(-2000); });
    child.once('error', reject); child.once('close', code => code === 0 ? resolve() : reject(new Error('Converter extraction failed: ' + message)));
  });
}
/** First use provisions a verified portable converter, never asks for executable paths. */
class Converter {
  constructor({ directory, root, fetchImpl = fetch, onProgress = () => {}, platform = process.platform, arch = process.arch, findImpl = findBlender }) {
    this.directory = path.join(directory, 'converters'); this.root = root; this.fetch = fetchImpl; this.onProgress = onProgress;
    this.platform = platform; this.target = TARGETS[platform + '-' + arch]; this.find = findImpl; this.pending = null;
  }
  progress(event){const percent=Math.max(0,Math.min(100,Math.round(event.percent))),key=event.stage+percent;if(this.lastProgress===key)return;this.lastProgress=key;this.onProgress({...event,percent});}
  async ensure() { return this.pending ||= this.install().catch(error => { this.pending = null; throw error; }); }
  async install() {
    const detected = await this.find(this.root); if (detected) return detected;
    if (!this.target) throw new Error('Install Blender on this operating system, then import again. Detection is automatic.');
    const target = this.target, installed = path.join(this.directory, target.folder), executable = path.join(installed, target.executable);
    if ((await fs.stat(executable).catch(() => null))?.isFile() && (await fs.readFile(path.join(installed, 'blockage-converter.json'), 'utf8').catch(() => '')) === target.hash) return executable;
    await fs.mkdir(this.directory, { recursive: true });
    const staging = path.join(this.directory, 'install-' + crypto.randomUUID()), archive = path.join(staging, target.archive);
    await fs.mkdir(staging);
    try {
      this.progress({ stage: 'Installing model converter', percent: 0 });
      // A pinned vendor checksum also covers the Linux archive before calling tar.
      const response = await this.fetch('https://download.blender.org/release/Blender4.5/' + target.archive + '?blockage=1', { redirect: 'error', headers: { 'User-Agent': 'Mozilla/5.0 Blockage Model Import' }, signal: AbortSignal.timeout(15 * 60 * 1000) });
      if (!response.ok) throw new Error('Converter download returned HTTP ' + response.status + '.');
      const announced = Number(response.headers.get('content-length')) || 500 * 1048576;
      const hash = crypto.createHash('sha256'), file = await fs.open(archive, 'wx'); let bytes = 0;
      try {
        for await (const chunk of response.body) {
          bytes += chunk.length; if (bytes > 1024 * 1048576) throw new Error('Converter download exceeds 1 GiB.');
          hash.update(chunk); await file.writeFile(chunk);
          this.progress({ stage: 'Installing model converter', percent: Math.min(75, Math.floor(bytes / announced * 75)) });
        }
      } finally { await file.close(); }
      if (hash.digest('hex') !== target.hash) throw new Error('Model converter SHA-256 verification failed.');
      const extracted = path.join(staging, 'extracted');
      if (target.archive.endsWith('.zip')) await extractZip(archive, extracted, p => this.progress({ stage: 'Extracting model converter', percent: 75 + Math.floor(p * 24) }), { prefix: target.folder + '/', maxExpanded: 4 * 1073741824 });
      else { await fs.mkdir(extracted); await unpackTar(archive, extracted); }
      const folder = path.join(extracted, target.folder), binary = path.join(folder, target.executable);
      if (!(await fs.stat(binary).catch(() => null))?.isFile()) throw new Error('Converter archive is missing Blender.');
      if (this.platform !== 'win32') await fs.chmod(binary, 0o755);
      await fs.writeFile(path.join(folder, 'blockage-converter.json'), target.hash);
      await fs.rm(installed, { recursive: true, force: true }); await fs.rename(folder, installed);
      this.progress({ stage: 'Model converter ready', percent: 100 }); return executable;
    } catch (error) { throw new Error(error.message + ' Import again when online, or install Blender normally; no path setting is required.'); }
    finally { await fs.rm(staging, { recursive: true, force: true }); }
  }
}
module.exports = { Converter, TARGETS, BLENDER_VERSION };
