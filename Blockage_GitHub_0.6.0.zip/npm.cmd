@echo off
setlocal
call "%~dp0scripts\launch-windows.cmd" setup
if errorlevel 1 exit /b 1
set "PATH=%~dp0runtime\node;%PATH%"
"%~dp0runtime\node\node.exe" "%~dp0runtime\node\node_modules\npm\bin\npm-cli.js" %*
exit /b %errorlevel%
