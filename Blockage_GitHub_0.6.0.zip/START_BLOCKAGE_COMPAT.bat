@echo off
setlocal
call "%~dp0scripts\launch-windows.cmd" compat
exit /b %errorlevel%
