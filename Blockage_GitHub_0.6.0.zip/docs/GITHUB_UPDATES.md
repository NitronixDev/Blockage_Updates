# Mises à jour Blockage

Le dépôt est intégré au moteur : **NitronixDev/Blockage_Updates**. L'utilisateur dispose seulement d'une case de vérification au démarrage, jamais d'un champ de lien ou de chemin.

## Publier le ZIP

Le fichier s'appelle exactement **Update -0.6.0-.zip** pour cette version et demande une installation **0.5.1**. Dépose-le à la racine du dépôt public en conservant **Update -0.5.0-.zip** et **Update -0.5.1-.zip** pour les anciens clients. Blockage lit la liste des fichiers, choisit la première version stable supérieure à celle installée, télécharge le ZIP et vérifie son identifiant de blob Git.

Une Release GitHub peut aussi porter ce même fichier. Son digest SHA-256 fourni par GitHub, ou le fichier SHA256SUMS.json généré avec le ZIP, valide le téléchargement. Les releases stables sont proposées dans l'ordre croissant ; conserve les versions intermédiaires lorsque les patchs dépendent d'elles.

Le ZIP contient un dossier **Blockage/**, les composants à remplacer et **update.json**. Chaque dossier inclus est une copie complète de sa nouvelle version. Un dossier absent reste intact. Les dossiers src, electron, scripts, assets, docs, tests, .github, runtime et node_modules sont les seuls dossiers remplaçables ; quelques fichiers racine du moteur sont également autorisés.

Le manifeste annonce la version, la version minimale et les SHA-256 de chaque fichier. Le moteur refuse les fichiers non annoncés, les liens symboliques, les chemins sortant de l'archive, les doublons, un changement de dépendances sans node_modules et un changement de Node sans runtime.

## Installer sur place

1. Check for updates découvre les ZIP sans configuration.
2. Download Update télécharge, extrait et contrôle les fichiers hors de l'installation.
3. Save & Restart sauvegarde la scène et lance un petit programme de remplacement.
4. Le programme attend la fermeture de Blockage, copie les fichiers sur le volume de l'installation, sauvegarde les anciens composants, remplace les dossiers et relance cette même installation.
5. Une erreur de remplacement déclenche une restauration. Les sauvegardes sont conservées dans **.blockage-updates/**.

Les dossiers des projets, les scènes, leurs assets et les données utilisateur ne figurent pas dans les composants remplaçables. Le runtime de lancement du programme de remplacement est copié hors de l'installation afin de pouvoir mettre runtime à jour sur Windows.

## Générer la prochaine version

Modifie package.json et package-lock.json, puis lance :

```sh
npm test
npm run check
npm run update -- --base /chemin/Blockage-0.5.1
```

Le générateur compare les dossiers par contenu et ajoute seulement les composants modifiés, plus package.json. **--min-version VERSION** permet d'annoncer une base compatible plus ancienne lorsqu'elle a été vérifiée. Sans --base, tous les composants source sont inclus. **--include-runtime** et **--include-dependencies** permettent d'inclure les binaires si nécessaire.

Le workflow taggé construit Windows, récupère le tag précédent comme base et publie les deux ZIP. L'installation automatique et son redémarrage visent la distribution Windows ; les sources restent utilisables pour développer sous Linux/macOS.

Références API : [contenu des dépôts](https://docs.github.com/en/rest/repos/contents) et [assets de Releases](https://docs.github.com/en/rest/releases/assets). Les appels de contenu brut utilisent application/vnd.github.raw+json.
