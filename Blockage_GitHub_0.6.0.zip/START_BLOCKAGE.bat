@echo off
setlocal
call "%~dp0scripts\launch-windows.cmd" editor
exit /b %errorlevel%
