@echo off
setlocal
call "%~dp0scripts\launch-windows.cmd" vulkan
exit /b %errorlevel%
