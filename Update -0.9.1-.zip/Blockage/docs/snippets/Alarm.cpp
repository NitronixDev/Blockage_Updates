
#include "blockage.hpp"

constexpr float PERIODE = 1.2f;  // Secondes pour un aller-retour.
constexpr float MINIMUM = 0.0f;
constexpr float MAXIMUM = 80.0f;
static_assert(PERIODE >= 0.05f, "Periode trop courte");

int lampe = 0;
float phase = 0.0f;

BG_START {
    lampe = bg::find("Alarme");
    phase = 0.0f;
    if (!lampe) {
        bg::hud("Lumiere Alarme introuvable");
        return;
    }
    bg::setLightIntensity(lampe, MINIMUM);
}

BG_UPDATE {
    if (!lampe) return;

    phase += dt / PERIODE;
    if (phase >= 1.0f) phase -= 1.0f;

    // Monte de 0 a 1, puis redescend de 1 a 0.
    float t = phase < 0.5f ? phase * 2.0f : (1.0f - phase) * 2.0f;
    float douceur = t * t * (3.0f - 2.0f * t);

    bg::setLightIntensity(lampe, MINIMUM + (MAXIMUM - MINIMUM) * douceur);
}
