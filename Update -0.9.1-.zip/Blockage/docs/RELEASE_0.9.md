# Blockage Studio 0.9.0 — du mesh peint au jeu exporté

**Si tu utilises Studio 0.8.0 :** prends `Update -0.9.0-.zip` intact. Soit tu le mets à la racine de **NitronixDev/Blockage_Updates**, soit tu le sélectionnes dans **Help → Install Update ZIP…**. Studio le décompresse, vérifie son contenu et remplace les composants du moteur au redémarrage. Pas de lien à configurer. Le grand ZIP de sources n’est pas un fichier de mise à jour.

**Avant de réenregistrer ton jeu**, copie sa scène `.blockage` et son dossier `.assets` s’il existe. Studio lit les anciennes scènes, mais les nouvelles sauvegardes sont au format 9 ; la 0.8.0 ne les relit pas.

## Tissu sur un modèle importé

1. Sélectionne le modèle, puis **Inspector → Select / edit cloth region**. Pas besoin de créer une surface de démonstration.
2. Choisis le sous-mesh et trace la zone en rectangle. Cyan = tissu ; gris = zone non simulée. Le rectangle sélectionne à travers le modèle. **Shift** ajoute ; **Subtract** retire.
3. Utilise **Pin** ou Alt + rectangle pour fixer les sommets (orange). **Unpin** libère les épingles sans retirer le tissu. **All cloth**, **Clear** et **Pin top edge** sont des raccourcis.
4. Clique **Apply**, puis **Play**. Pour reprendre le masque, utilise le même bouton des propriétés. En lecture, **Stop & edit cloth region** restaure la pose de travail avant édition : ce n’est pas une modification sur une simulation qui continue de tourner.

| Effet recherché | Réglage |
| --- | --- |
| Le pan d’une veste reste fixé au torse | Laisse le torse hors sélection ou épingle la couture. Les parties non simulées suivent les os et la pose du modèle. |
| Un rideau reste suspendu | Peins la partie mobile et choisis **Top edge + painted pins**, ou peins précisément la rangée d’accroche. |
| Un panneau à quatre sommets doit pouvoir plier | Essaie **Refinement 2**. Les triangles sélectionnés sont subdivisés sur une copie temporaire ; l’asset et ses UV sont conservés. |
| Le mesh est déjà dense | Commence avec **Refinement 0** ; augmente seulement si le pli en a besoin. |
| Limiter le déplacement de la toile | Ajuste **Max displacement** en mètres ; 0 = aucune limite supplémentaire. Bending règle la résistance à la flexion. |
| Fixer le solide à un autre objet | Weld **Solid only** suit la cible et laisse la toile libre. **All vertices** fixe aussi le tissu. |

**Le comportement de vêtement ne crée pas de rigid body et ne translate pas l’objet.** Une zone vide ne simule rien. À l’inverse, si toute la géométrie est libre et sans aucune attache, elle tombe : c’est une différence importante pour diagnostiquer un vêtement qui « glisse ». Le mode double face évite la disparition du revers de la toile.

Les anciens masques sont conservés avec subdivision 0 et leur mode d’attache antérieur. La limite est de 16 384 sommets mobiles après subdivision par scène. Collisions contre les sphères/boîtes prises en charge ; pas d’auto-collision, de déchirure ni de contacts exacts triangle contre triangle.

## Particules : contrôler un effet, pas choisir un modèle d’explosion

Ajoute **Particle Emitter** comme comportement. Oriente la source en tournant son objet. Pour un effet ponctuel, choisis un débit de 0 et un burst ; pour une traînée continue, un débit positif et l’espace **World**. En **Local**, les particules suivent le déplacement de la source.

- Sources sphère, cône, disque ou boîte : rayon, dimensions XYZ, ouverture ; graine reproductible.
- Débit, burst, délai, durée d’un cycle et répétition. Durée 0 = émission continue. Rotation de départ, vitesse de rotation, gravité, forces XYZ, traînée, vitesse et durée de vie.
- **Edit lifetime curves…** : 2 à 8 clés déplaçables directement sur le graphe (ou saisie des valeurs, point ou virgule) pour la taille, la vitesse et l’opacité. Temps 0 = naissance, 1 = mort. Taille et vitesse multiplient les valeurs de base ; opacité entre 0 et 1.
- Texture de sprite importée, colonnes/lignes et FPS pour une planche d’animation. Lecture de gauche à droite et de haut en bas. Couleurs de début/fin, mélange alpha ou additif.
- Capacité explicite et réutilisation des particules ; les naissances excédentaires sont ignorées. Maximum : 8 192 par émetteur, 32 768 réservées par scène. La simulation est CPU à pas fixe ; le dessin est instancié sur le GPU. Pas de fumée volumétrique ni de collisions de particules.

## Eau

La géométrie combine sept vagues de longueurs, directions et phases différentes. **Wave seed** change la disposition ; **Wind direction** l’oriente ; **Directional spread** règle le croisement des vagues. Les phases spatiales sont mises en cache pour ne pas recalculer sept sinus par sommet à chaque image. La flottabilité échantillonne le même spectre que le rendu.

Les petites ondulations utilisent deux échelles, deux orientations et des déplacements distincts : une seule petite texture ne défile plus uniformément comme un papier peint. Ajuste **Detail scale**, **Fine ripples**, la rugosité, la teinte et la profondeur optique. Les impacts et rides restent simulés en temps réel. La réfraction a besoin d’un fond et d’un éclairage à regarder ; le mode **Alpha · fast** garde un coût de rendu plus faible. Ce n’est pas une simulation d’océan volumétrique : profondeur optique manuelle, pas de caustiques ou d’écume de rivage simulées.

## Sons et Play

- **Add → Sound…** : ajoute directement une musique ou ambiance 2D à la scène.
- **Inspector → Sounds → + Add sound…** : attache un WAV, MP3 ou OGG au modèle sélectionné, sans objet audio dans la hiérarchie. Un double-clic sur un son déjà importé fait de même. Sans sélection, il va dans la scène.
- Plusieurs sons par hôte ; volume, hauteur, boucle, démarrage automatique, spatialisation 3D et atténuation. Les anciens objets audio restent compatibles. Un trigger Sound ciblant un objet déclenche ses sons.
- **Play** prend la vue du Player actif et visible, y compris sur un modèle importé muni d’un contrôleur. Un squelette seul n’est pas un Player. Sans joueur, Studio reste en vue d’édition. Le jeu exporté peut aussi utiliser une caméra de scène.
- **Pause → Step** avance d’un pas de simulation ; **Stop / Échap** rend la caméra à l’éditeur et arrête le son. Plus de bouton Game indépendant.

## Livrer le jeu

**Scene Audit** aide à repérer les masques vides ou entièrement libres, les coûts de subdivision, les pools de particules trop petits et les scènes sans Player/Camera. Les avertissements sont des indices, pas un verdict sur ton jeu.

Utilise **File → Export Windows Game (.exe)…** depuis Studio sous Windows x64. Distribue **le dossier entier** (EXE, DLL, locales et resources). `npm run dist` construit Studio, pas ton jeu. Le lecteur natif expérimental BNS1 est distinct : il refuse les effets/sons qu’il ne sait pas reproduire. Les scripts de Studio sont compilés en C++17 vers WebAssembly et exécutés dans le Player.

**Recette avant une sortie :** jouer ton niveau depuis l’EXE sur un PC sans les outils de développement ; vérifier les entrées, le son, les changements de scène et les sauvegardes de ton jeu ; observer les temps d’image du pire passage et la mémoire après plusieurs reprises. Aucune garantie de FPS sur la RTX 5060, ni de certification Steam, n’est déduite des tests du moteur.
## Ce qui a été vérifié

153 tests automatisés. Dans Studio en WebGL 2, un GLB importé de 24 sommets source donne 150 sommets sur le proxy et 105 mobiles après sélection, subdivision et épinglage. Une courbe d’opacité éditée sur le graphe conserve la clé (0,5 ; 0,75). La lecture, l’avance d’un pas et le retour au masque préservent les réglages du jeu.

L’export de cette scène produit un exécutable PE x64 et son dossier de distribution. Le contenu de ce dossier a été lancé séparément dans Chromium, via le même gestionnaire de ressources que le Player : démarrage en vue joueur, deux sons et confirmation à l’écran par un script C++ compilé. L’exécutable lui-même n’a pas été joué sur Windows dans cet environnement.
