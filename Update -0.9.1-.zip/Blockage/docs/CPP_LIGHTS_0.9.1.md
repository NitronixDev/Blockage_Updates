
# Blockage 0.9.1 — intensité lumineuse en C++

Correctif ciblé pour Studio **0.9.0** : installe `Update -0.9.1-.zip`
intact avec **Help → Install Update ZIP…**, puis redémarre Studio.
Sauvegarde ton projet avant mise à jour. Le ZIP peut aussi être publié
intact à la racine de **NitronixDev/Blockage_Updates**.

Cette API n'existe pas dans la 0.9.0. Le correctif ajoute :
`bg::setLightIntensity(entite, intensite)` dans `blockage.hpp`, son transport
Worker et sa prise en charge dans le runtime et l'export du jeu.
Les dépendances, le runtime Electron et le format des scènes ne changent pas.

## Alarme douce

1. Ajoute une **Point Light**, nomme-la exactement **Alarme**, avec un nom unique
   dans l'Explorer. Garde-la visible et mets sa couleur en rouge dans l'Inspector.
2. Dans le C++ Workspace, crée un **World Script**, active-le et colle
   [snippets/Alarm.cpp](snippets/Alarm.cpp).
3. Compile avec **Build**, puis lance **Play**.
4. `PERIODE` est la durée d'un cycle (1,2 s). Une valeur plus grande ralentit
   l'alarme. `MINIMUM` / `MAXIMUM` règlent ses intensités, pas sa couleur.
   Un minimum de zéro éteint l'émission entre les impulsions.
5. **Stop** restaure l'intensité qui existait avant le script.

`BG_UPDATE` est appelé par le moteur à chaque pas de simulation (1/60 s).
N'ajoute pas de `while(true)`, de pause bloquante ou de thread. Le triangle
de phase est lissé par un polynôme smoothstep : la pente devient nulle
au minimum et au maximum, sans saut brutal et sans dépendance à `<cmath>`.
Aucune animation précalculée n'est utilisée.

Un **Object Script** attaché à la lumière peut utiliser `bg::self()` à la
place de `bg::find("Alarme")`.

## Contrat

- Point Light, Spot Light et Directional Light acceptées ; autres objets ignorés.
- Valeurs finies bornées entre 0 et 10 000 ; valeurs non finies refusées
  par le Worker. Les limites de commandes du Worker restent actives.
- Aucun changement du document de scène ou du champ sauvegardé de l'Inspector
  pendant Play. Seule la lumière rendue change ; Stop annule l'override.
- Un nom absent donne le handle 0 ; l'exemple affiche alors un message.
  Utilise des noms uniques pour éviter de sélectionner une autre entité.
- Si plusieurs scripts pilotent la même intensité, la dernière commande
  traitée gagne : préfère un seul script par lumière.
- Dans l'export Electron, les scripts C++17 restent compilés en WebAssembly.
  L'export natif expérimental est distinct et n'est pas étendu par ce correctif.

Le script d'exemple et la chaîne compilateur → Worker → lumière réelle
Three.js → restauration sont couverts par les tests de régression.
Le comportement du Player exporté est vérifié sur son contenu ; l'EXE
Windows lui-même reste à exécuter sur Windows.
