import {
  uniform,
  vec2,
  positionLocal,
  texture,
  normalMap,
  sin,
} from 'three/tsl';
import * as T from 'three/webgpu';
export const OPTICS = Object.freeze({
  waterQuality: 'refractive',
  tint: '#398c91',
  clarity: 0.91,
  opticalDepth: 1.6,
  absorptionDistance: 8,
  microWaves: 0.19,
  waterRoughness: 0.095,
  detailScale: 3,
  seed: 2389,
  windDirection: 25,
  directionalSpread: 65,
});
export function waterSettings(c) {
  for (const [k, v] of Object.entries(OPTICS)) if (c[k] === undefined) c[k] = v;
  return c;
}
export function checkOptics(c) {
  waterSettings(c);
  for (const [k, a, b] of [
    ['clarity', 0, 1],
    ['opticalDepth', 0.02, 50],
    ['absorptionDistance', 0.1, 150],
    ['microWaves', 0, 1],
    ['waterRoughness', 0.025, 0.95],
    ['detailScale', 0.1, 50],
    ['seed', 0, 4294967295],
    ['windDirection', -360, 360],
    ['directionalSpread', 0, 180],
  ])
    if (!Number.isFinite(c[k]) || c[k] < a || c[k] > b)
      throw Error('Invalid water setting: ' + k);
  if (!Number.isInteger(c.seed)) throw Error('Invalid water seed');
  if (
    !/^#[0-9a-f]{6}$/i.test(c.tint) ||
    !['refractive', 'fast'].includes(c.waterQuality)
  )
    throw Error('Invalid water optics');
}
function normalTile(seed) {
  const n = 96,
    a = new Uint8Array(4 * n * n),
    tau = Math.PI * 2;
  const waves = Array.from({ length: 20 }, (_, i) => {
    seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
    const a = (seed / 4294967296) * tau,
      k = 1 + i * 0.7;
    return [
      Math.round(Math.cos(a) * k),
      Math.round(Math.sin(a) * k),
      0.18 / (1 + i) ** 1.4,
    ];
  });
  for (let j = 0; j < n; j++)
    for (let i = 0; i < n; i++) {
      let x = (i * tau) / n,
        y = (j * tau) / n,
        p = 0,
        q = 0;
      for (const [kx, ky, w] of waves) {
        const c = w * Math.cos(kx * x + ky * y + 0.6 * ky);
        p += kx * c;
        q += ky * c;
      }
      const l = Math.hypot(p, q, 1),
        k = 4 * (j * n + i);
      a[k] = Math.round(127.5 * (1 - p / l));
      a[k + 1] = Math.round(127.5 * (1 - q / l));
      a[k + 2] = Math.round(127.5 * (1 + 1 / l));
      a[k + 3] = 255;
    }
  const t = new T.DataTexture(a, n, n, T.RGBAFormat);
  t.wrapS = t.wrapT = T.RepeatWrapping;
  t.minFilter = T.LinearMipmapLinearFilter;
  t.magFilter = T.LinearFilter;
  t.generateMipmaps = true;
  t.needsUpdate = true;
  return t;
}
export function applyWater(material, config) {
  const c = waterSettings(config),
    real = c.waterQuality === 'refractive';
  material.userData.water = true;
  material.color.set(real ? '#eefafa' : c.tint);
  material.metalness = 0;
  material.roughness = c.waterRoughness;
  material.ior = 1.333;
  material.clearcoat = 0;
  material.transmission = real ? c.clarity : 0;
  material.thickness = c.opticalDepth;
  material.attenuationColor.set(c.tint);
  material.attenuationDistance = c.absorptionDistance;
  material.opacity = real ? 1 : 1 - c.clarity * 0.78;
  material.transparent = !real;
  material.depthWrite = real;
  material.side = T.DoubleSide;
  material.forceSinglePass = !real;
  if (!material.normalMap) {
    material.normalMap = normalTile(c.seed);
    material.needsUpdate = true;
  }
  material.normalMap.repeat.set(
    c.width / c.detailScale,
    c.depth / c.detailScale,
  );
  material.normalScale.setScalar(c.microWaves);
  if (material.isNodeMaterial) {
    const clock = uniform(0);
    material.userData.waterTime = clock;
    const p = positionLocal.xz.div(c.detailScale),
      angle = (c.windDirection * Math.PI) / 180,
      flow = vec2(Math.cos(angle), Math.sin(angle)).mul(clock).mul(0.027);
    const a = p
        .add(flow)
        .add(vec2(sin(p.y.mul(0.173)), sin(p.x.mul(0.193))).mul(0.23)),
      b = vec2(
        p.x.mul(0.731).sub(p.y.mul(0.912)),
        p.x.mul(0.912).add(p.y.mul(0.731)),
      )
        .mul(1.731)
        .sub(flow.mul(0.63));
    material.normalNode = normalMap(
      texture(material.normalMap, a)
        .xyz.mul(0.58)
        .add(texture(material.normalMap, b).xyz.mul(0.42)),
      vec2(c.microWaves, c.microWaves),
    );
  }
  return material;
}
export function advanceWater(material, time) {
  if (material.userData.waterTime) material.userData.waterTime.value = time;
  if (material.normalMap)
    material.normalMap.offset.set((time * 0.019) % 1, (time * 0.012) % 1);
}
