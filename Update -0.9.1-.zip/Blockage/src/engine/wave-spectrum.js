// Cache spatial phases; at runtime only two trigonometric calls per wave are required for the grid.
export class WaveSpectrum {
  constructor(c) {
    let seed = c.seed >>> 0;
    const rand = () => {
      seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
      return seed / 4294967296;
    };
    this.w = Array.from({ length: 7 }, (_, i) => {
      const scale = c.wavelength * 0.61 ** i * (1 + 0.25 * rand()),
        angle =
          ((c.windDirection + (rand() - 0.5) * c.directionalSpread) * Math.PI) /
          180,
        k = (2 * Math.PI) / scale;
      return {
        x: Math.cos(angle) * k,
        z: Math.sin(angle) * k,
        p: rand() * Math.PI * 2,
        a: c.amplitude * 0.48 ** i,
        v: Math.sqrt(9.81 * k) * c.speed,
      };
    });
    const n = c.resolution;
    this.s = new Float32Array((n + 1) ** 2 * 7);
    this.c = new Float32Array(this.s.length);
    this.t = new Float64Array(14);
    for (let z = 0; z <= n; z++)
      for (let x = 0; x <= n; x++)
        for (let j = 0; j < 7; j++) {
          const w = this.w[j],
            k = (z * (n + 1) + x) * 7 + j,
            p =
              (x / n - 0.5) * c.width * w.x +
              (z / n - 0.5) * c.depth * w.z +
              w.p;
          this.s[k] = Math.sin(p) * w.a;
          this.c[k] = Math.cos(p) * w.a;
        }
  }
  at(x, z, time) {
    let y = 0;
    for (const w of this.w)
      y += w.a * Math.sin(w.x * x + w.z * z + w.p - time * w.v);
    return y;
  }
  time(time) {
    for (let j = 0; j < 7; j++) {
      this.t[2 * j] = Math.cos(time * this.w[j].v);
      this.t[2 * j + 1] = Math.sin(time * this.w[j].v);
    }
  }
  vertex(i) {
    let y = 0;
    for (let j = 0; j < 7; j++)
      y +=
        this.s[i * 7 + j] * this.t[2 * j] -
        this.c[i * 7 + j] * this.t[2 * j + 1];
    return y;
  }
}
