import * as T from 'three/webgpu';
export function topPins(g, ids) {
  const p = g.attributes.position,
    lo = [Infinity, Infinity, Infinity],
    hi = [-Infinity, -Infinity, -Infinity];
  for (const i of ids)
    for (let j = 0; j < 3; j++) {
      const x = p.getComponent(i, j);
      lo[j] = Math.min(lo[j], x);
      hi[j] = Math.max(hi[j], x);
    }
  const extent = hi.map((v, i) => v - lo[i]);
  const axis = extent[1] > 1e-5 ? 1 : extent[2] > extent[0] ? 2 : 0;
  return new Set(
    [...ids].filter(
      (i) =>
        p.getComponent(i, axis) >=
        hi[axis] - Math.max(1e-6, extent[axis] * 0.03),
    ),
  );
}
// Each temporary vertex remembers its source barycentric weights, allowing pinned fabric
// to follow animated bones and morph targets without rewriting the imported geometry.
export function clothTopology(source, ids, levels = 0) {
  const n = source.attributes.position.count,
    weights = Array.from({ length: n }, (_, i) => [[i, 1]]);
  const ix = source.index,
    length = ix?.count || n;
  let tris = [];
  for (let k = 0; k + 2 < length; k += 3)
    tris.push([
      ix ? ix.getX(k) : k,
      ix ? ix.getX(k + 1) : k + 1,
      ix ? ix.getX(k + 2) : k + 2,
      k,
    ]);
  const active = (w) => w.some(([id]) => ids.has(id));
  for (let level = 0; level < levels; level++) {
    const mid = new Map(),
      next = [];
    const half = (a, b) => {
      const key = Math.min(a, b) * 100000 + Math.max(a, b);
      if (mid.has(key)) return mid.get(key);
      if (weights.length >= 100000)
        throw Error(
          'Refinement exceeds 100,000 vertices. Reduce Refinement or the selected area.',
        );
      const m = new Map();
      for (const i of [a, b])
        for (const [id, w] of weights[i]) m.set(id, (m.get(id) || 0) + w * 0.5);
      const id = weights.length;
      weights.push([...m]);
      mid.set(key, id);
      return id;
    };
    for (const [a, b, c, k] of tris) {
      if (![a, b, c].some((i) => active(weights[i]))) {
        next.push([a, b, c, k]);
        continue;
      }
      const ab = half(a, b),
        bc = half(b, c),
        ca = half(c, a);
      next.push(
        [a, ab, ca, k],
        [ab, b, bc, k],
        [ca, bc, c, k],
        [ab, bc, ca, k],
      );
    }
    tris = next;
  }
  const geo = new T.BufferGeometry();
  for (const [name, attr] of Object.entries(source.attributes)) {
    if (['skinIndex', 'skinWeight', 'tangent'].includes(name)) continue;
    const data = new Float32Array(weights.length * attr.itemSize);
    for (let i = 0; i < weights.length; i++)
      for (const [id, w] of weights[i])
        for (let j = 0; j < attr.itemSize; j++)
          data[i * attr.itemSize + j] += attr.getComponent(id, j) * w;
    geo.setAttribute(name, new T.BufferAttribute(data, attr.itemSize));
  }
  geo.setIndex(tris.flatMap((t) => t.slice(0, 3)));
  if (source.groups.length) {
    let from = 0,
      last = -1;
    for (let i = 0; i < tris.length; i++) {
      const k = tris[i][3],
        m =
          source.groups.find((g) => k >= g.start && k < g.start + g.count)
            ?.materialIndex || 0;
      if (last !== m) {
        if (i) geo.addGroup(from, 3 * i - from, last);
        last = m;
        from = 3 * i;
      }
    }
    if (tris.length) geo.addGroup(from, 3 * tris.length - from, last);
  }
  return { geo, weights };
}
