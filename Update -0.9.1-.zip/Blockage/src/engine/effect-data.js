export const effectDefaults = {
  seed: 12345,
  space: 'world',
  radius: 0,
  boxX: 1,
  boxY: 1,
  boxZ: 1,
  rotationMin: 0,
  rotationMax: 0,
  spin: 0,
  delay: 0,
  duration: 0,
  loop: false,
  windX: 0,
  windY: 0,
  windZ: 0,
  texture: null,
  columns: 1,
  rows: 1,
  flipbookFPS: 12,
  curves: {
    size: [
      [0, 1],
      [1, 1],
    ],
    opacity: [
      [0, 1],
      [1, 0],
    ],
    speed: [
      [0, 1],
      [1, 1],
    ],
  },
};
export function effectSettings(c) {
  for (const [k, v] of Object.entries(effectDefaults))
    if (c[k] === undefined) c[k] = structuredClone(v);
  return c;
}
export function curve(points, t) {
  if (t <= points[0][0]) return points[0][1];
  for (let i = 1; i < points.length; i++) {
    const [x, y] = points[i],
      [a, b] = points[i - 1];
    if (t <= x) return b + ((y - b) * (t - a)) / (x - a);
  }
  return points.at(-1)[1];
}
export function checkCurve(points, max = 8) {
  if (!Array.isArray(points) || points.length < 2 || points.length > 8)
    throw Error('A curve needs 2–8 keys.');
  let prev = -1;
  for (const p of points) {
    if (
      !Array.isArray(p) ||
      p.length !== 2 ||
      !p.every(Number.isFinite) ||
      p[0] < 0 ||
      p[0] > 1 ||
      p[0] <= prev ||
      p[1] < 0 ||
      p[1] > max
    )
      throw Error('Curve time must increase and values must be in range.');
    prev = p[0];
  }
  if (points[0][0] !== 0 || points.at(-1)[0] !== 1)
    throw Error('Curve endpoints must be at 0 and 1.');
}
export function checkEffect(c, assets) {
  effectSettings(c);
  for (const [k, a, z] of [
    ['seed', 0, 4294967295],
    ['radius', 0, 100],
    ['boxX', 0.001, 200],
    ['boxY', 0.001, 200],
    ['boxZ', 0.001, 200],
    ['rotationMin', -360, 360],
    ['rotationMax', -360, 360],
    ['spin', -3600, 3600],
    ['delay', 0, 60],
    ['duration', 0, 600],
    ['windX', -100, 100],
    ['windY', -100, 100],
    ['windZ', -100, 100],
    ['columns', 1, 16],
    ['rows', 1, 16],
    ['flipbookFPS', 0, 120],
  ])
    if (!Number.isFinite(c[k]) || c[k] < a || c[k] > z)
      throw Error('Invalid emitter ' + k);
  if (
    !['world', 'local'].includes(c.space) ||
    typeof c.loop !== 'boolean' ||
    !['seed', 'columns', 'rows'].every((k) => Number.isInteger(c[k])) ||
    c.rotationMin > c.rotationMax ||
    (c.duration > 0 && c.duration < 0.02)
  )
    throw Error('Invalid particle cycle / rotation range.');
  if (
    c.texture !== null &&
    !assets.some((a) => a.id === c.texture && a.type === 'texture')
  )
    throw Error('Missing sprite texture.');
  for (const k of ['size', 'opacity', 'speed'])
    checkCurve(c.curves?.[k], k === 'opacity' ? 1 : 8);
}
