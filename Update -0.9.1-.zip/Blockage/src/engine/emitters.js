import { effectSettings, curve } from './effect-data.js';
import * as T from 'three/webgpu';
import { attribute, texture, uv, vec2 } from 'three/tsl';
export class Emitter {
  constructor(config, scene, sprite = null) {
    const c = (this.c = effectSettings({ ...config }));
    this.ownsTexture = !sprite;
    this.seed = c.seed >>> 0;
    this.time = 0;
    this.cycle = -1;
    this.dropped = 0;
    this.sortMatrix = new T.Matrix4();
    this.rotation = new Float32Array(c.capacity);
    this.roll = new T.Quaternion();
    this.z = new T.Vector3(0, 0, 1);
    this.count = 0;
    this.carry = 0;
    this.p = new Float32Array(c.capacity * 3);
    this.v = new Float32Array(this.p.length);
    this.age = new Float32Array(c.capacity);
    this.life = new Float32Array(c.capacity);
    this.d = new T.Object3D();
    this.quat = new T.Quaternion();
    this.tmp = new T.Vector3();
    this.order = [];
    this.color = new T.Color();
    this.a = new T.Color(c.startColor);
    this.b = new T.Color(c.endColor);
    if (sprite) this.tex = sprite;
    else {
      const n = 32,
        tex = new Uint8Array(n * n * 4);
      for (let y = 0; y < n; y++)
        for (let x = 0; x < n; x++)
          tex.set(
            [
              255,
              255,
              255,
              Math.round(
                255 *
                  Math.max(
                    0,
                    1 - (((x + 0.5) / 16 - 1) ** 2 + ((y + 0.5) / 16 - 1) ** 2),
                  ) **
                    2,
              ),
            ],
            (y * n + x) * 4,
          );
      this.tex = new T.DataTexture(tex, n, n);
      this.tex.minFilter = this.tex.magFilter = T.LinearFilter;
      this.tex.needsUpdate = true;
    }
    const g = new T.PlaneGeometry(1, 1),
      m = new T.MeshBasicNodeMaterial({
        transparent: true,
        depthWrite: false,
        blending: c.blend === 'alpha' ? T.NormalBlending : T.AdditiveBlending,
      });
    this.alpha = new T.InstancedBufferAttribute(
      new Float32Array(c.capacity),
      1,
    ).setUsage(T.DynamicDrawUsage);
    g.setAttribute('fxAlpha', this.alpha);
    this.frames = new T.InstancedBufferAttribute(
      new Float32Array(c.capacity * 2),
      2,
    ).setUsage(T.DynamicDrawUsage);
    g.setAttribute('fxFrame', this.frames);
    const texel = texture(
      this.tex,
      uv().div(vec2(c.columns, c.rows)).add(attribute('fxFrame', 'vec2')),
    );
    m.colorNode = texel.rgb;
    m.opacityNode = attribute('fxAlpha', 'float').mul(texel.a);
    this.mesh = new T.InstancedMesh(g, m, c.capacity);
    this.mesh.count = 0;
    this.mesh.instanceMatrix.setUsage(T.DynamicDrawUsage);
    this.mesh.frustumCulled = false;
    this.mesh.userData.runtimeVisual = true;
    this.mesh.raycast = () => {};
    scene.add(this.mesh);
  }
  random() {
    this.seed = (Math.imul(this.seed, 1664525) + 1013904223) >>> 0;
    return this.seed / 4294967296;
  }
  start(o) {
    this.auto = true;
    this.advance(0, 0, o);
  }
  advance(from, to, o) {
    const c = this.c,
      start = Math.max(0, from - c.delay),
      end = to - c.delay;
    if (end < 0) return;
    const dur = c.duration || Infinity;
    for (let i = Math.floor(start / dur); i <= Math.floor(end / dur); i++) {
      if (i && !c.loop) break;
      const a = i ? i * dur : 0;
      if (i > this.cycle) {
        this.cycle = i;
        if (c.autoplay) this.emit(c.burst, o);
      }
      this.carry +=
        Math.max(0, Math.min(end, a + dur) - Math.max(start, a)) * c.rate;
      const n = Math.floor(this.carry + 1e-9);
      this.carry -= n;
      if (n) this.emit(n, o);
    }
  }
  emit(n, o) {
    const c = this.c,
      r = () => this.random(),
      wanted = Math.max(0, Math.floor(n)),
      count = Math.min(wanted, c.capacity - this.count);
    this.dropped += wanted - count;
    this.owner = o;
    o.updateWorldMatrix(true, false);
    o.getWorldQuaternion(this.quat);
    for (let j = 0; j < count; j++) {
      const i = this.count++,
        k = 3 * i,
        y =
          c.shape === 'sphere'
            ? 2 * r() - 1
            : 1 - r() * (1 - Math.cos((c.spread * Math.PI) / 180)),
        ang = r() * Math.PI * 2,
        h = Math.sqrt(Math.max(0, 1 - y * y)),
        dx = h * Math.cos(ang),
        dz = h * Math.sin(ang);
      if (c.shape === 'box')
        this.tmp.set(
          (r() - 0.5) * c.boxX,
          (r() - 0.5) * c.boxY,
          (r() - 0.5) * c.boxZ,
        );
      else if (c.shape === 'disc' || c.shape === 'cone') {
        const rr = c.radius * Math.sqrt(r()),
          a = r() * Math.PI * 2;
        this.tmp.set(Math.cos(a) * rr, 0, Math.sin(a) * rr);
      } else this.tmp.set(dx, y, dz).multiplyScalar(c.radius * Math.cbrt(r()));
      if (c.space === 'world') this.tmp.applyMatrix4(o.matrixWorld);
      this.tmp.toArray(this.p, k);
      this.tmp.set(
        c.shape === 'disc' ? 0 : dx,
        c.shape === 'disc' ? 1 : y,
        c.shape === 'disc' ? 0 : dz,
      );
      if (c.space === 'world') this.tmp.applyQuaternion(this.quat);
      this.tmp
        .multiplyScalar(c.speedMin + r() * (c.speedMax - c.speedMin))
        .toArray(this.v, k);
      this.age[i] = 0;
      this.life[i] = c.lifeMin + r() * (c.lifeMax - c.lifeMin);
      this.rotation[i] =
        ((c.rotationMin + r() * (c.rotationMax - c.rotationMin)) * Math.PI) /
        180;
    }
    return count;
  }
  step(dt, o) {
    this.owner = o;
    this.time += dt;
    if (this.auto) this.advance(this.time - dt, this.time, o);
    else {
      this.carry += this.c.rate * dt;
      const n = Math.floor(this.carry);
      this.carry -= n;
      if (n) this.emit(n, o);
    }
    const drag = Math.exp(-this.c.drag * dt);
    for (let i = this.count - 1; i >= 0; i--) {
      if ((this.age[i] += dt) >= this.life[i]) {
        const j = --this.count;
        if (i !== j) {
          this.p.copyWithin(3 * i, 3 * j, 3 * j + 3);
          this.v.copyWithin(3 * i, 3 * j, 3 * j + 3);
          this.age[i] = this.age[j];
          this.life[i] = this.life[j];
          this.rotation[i] = this.rotation[j];
        }
        continue;
      }
      this.v[i * 3] += this.c.windX * dt;
      this.v[i * 3 + 1] += (this.c.gravity + this.c.windY) * dt;
      this.v[i * 3 + 2] += this.c.windZ * dt;
      const speed = curve(this.c.curves.speed, this.age[i] / this.life[i]);
      for (let k = 3 * i; k < 3 * i + 3; k++)
        this.p[k] += (this.v[k] *= drag) * dt * speed;
    }
  }
  draw(camera) {
    const { mesh, d, c } = this;
    mesh.count = this.count;
    this.order.length = this.count;
    for (let i = 0; i < this.count; i++) this.order[i] = i;
    if (c.blend === 'alpha') {
      this.sortMatrix.copy(camera.matrixWorldInverse);
      if (c.space === 'local' && this.owner)
        this.sortMatrix.multiply(this.owner.matrixWorld);
      const a = this.sortMatrix.elements,
        z = (i) =>
          a[2] * this.p[3 * i] +
          a[6] * this.p[3 * i + 1] +
          a[10] * this.p[3 * i + 2];
      this.order.sort((a, b) => z(a) - z(b));
    }
    camera.getWorldQuaternion(this.quat);
    for (let j = 0; j < this.count; j++) {
      const i = this.order[j],
        t = this.age[i] / this.life[i];
      d.position.fromArray(this.p, i * 3);
      if (c.space === 'local' && this.owner)
        d.position.applyMatrix4(this.owner.matrixWorld);
      d.quaternion
        .copy(this.quat)
        .multiply(
          this.roll.setFromAxisAngle(
            this.z,
            this.rotation[i] + (c.spin * this.age[i] * Math.PI) / 180,
          ),
        );
      d.scale.setScalar(
        (c.sizeStart + (c.sizeEnd - c.sizeStart) * t) * curve(c.curves.size, t),
      );
      d.updateMatrix();
      mesh.setMatrixAt(j, d.matrix);
      mesh.setColorAt(j, this.color.copy(this.a).lerp(this.b, t));
      this.alpha.setX(j, c.opacity * curve(c.curves.opacity, t));
      const f = Math.floor(this.age[i] * c.flipbookFPS) % (c.columns * c.rows);
      this.frames.setXY(
        j,
        (f % c.columns) / c.columns,
        (c.rows - 1 - Math.floor(f / c.columns)) / c.rows,
      );
    }
    mesh.instanceMatrix.needsUpdate = true;
    if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
    this.alpha.needsUpdate = true;
    this.frames.needsUpdate = true;
  }
  dispose() {
    this.mesh.removeFromParent();
    this.mesh.dispose();
    this.mesh.geometry.dispose();
    this.mesh.material.dispose();
    if (this.ownsTexture) this.tex.dispose();
  }
}
