/** Advisory checks only. Never rewrites assets, objects or lighting. */
export function auditScene(doc, stats = null) {
  const issues = [], s = doc.settings, add = (level, message) => issues.push({ level, message });
  const lights = doc.entities.filter(e => /Light$/.test(e.kind) && e.visible && e.light.intensity > 0);
  const shadows = lights.filter(e => e.castShadow);
  if (s.exposure < .35) add('warning', 'Exposure is very low. Dark materials may lose detail; inspect lighting before replacing textures.');
  if (s.ambient > 1.2) add('warning', 'Strong hemisphere fill can flatten surface contrast. Lower it before increasing direct light.');
  if (s.fog > .025) add('warning', 'Dense exponential fog can obscure large scenes. Check the imported model scale.');
  if (!lights.length && s.ambient === 0 && s.environmentIntensity === 0) add('warning', 'No direct or environment lighting. Only emissive materials will remain visible.');
  if (s.shadows && shadows.length > s.maxShadowLights) add('warning', `${shadows.length} shadow lights requested; only the first ${s.maxShadowLights} in scene order receive shadow maps. The others still illuminate.`);
  if (shadows.some(e => e.kind === 'pointLight')) add('info', 'Point-light shadows require six views per light. Prefer spot lights for directed indoor lighting.');
  const names = new Set(); let duplicates = 0;
  for (const e of doc.entities) { if (names.has(e.name.toLowerCase())) duplicates++; names.add(e.name.toLowerCase()); }
  if (duplicates) add('info', `${duplicates} duplicate object name(s). IDs are distinct; clearer names make large hierarchies easier to navigate.`);
  if(!doc.entities.some(e=>e.player?.enabled||e.kind==='camera'))add('warning','No Player or Camera: the exported game uses the saved editor viewpoint.');
  for(const e of doc.entities){const g=e.behaviors.garment,f=e.behaviors.emitter;if(g){if(!g.regions.some(r=>r.ranges.length))add('warning',e.name+': cloth has no selected vertices.');for(const r of g.regions)if(g.pinMode!=='top'&&!r.pins?.length&&r.ranges.reduce((n,[a,b])=>n+b-a+1,0)===r.count)add('warning',e.name+': fully free cloth will fall. Paint pins or choose Top edge.');if(g.subdivisions>1)add('info',e.name+': reduce Refinement on dense meshes to lower cloth cost.');}if(f&&f.rate*f.lifeMax+f.burst>f.capacity)add('warning',e.name+': particle pool may fill; excess births are dropped.');}
  const modelCounts = new Map();
  for (const e of doc.entities) if (e.kind === 'model') modelCounts.set(e.assetId, (modelCounts.get(e.assetId) || 0) + 1);
  if ([...modelCounts.values()].some(n => n >= 4)) add('info', 'Repeated opaque static model meshes can share instanced draws. Animated, transparent, mirrored and selected objects are excluded.');
  if (stats?.calls > 1000) add('warning', 'More than 1,000 GPU draw submissions including shadow/post passes. Reuse meshes and materials, and reduce shadow lights.');
  if (stats?.triangles > 3000000) add('warning', 'More than 3 million submitted triangles including shadow passes. Consider lower-detail assets; automatic mesh LOD generation is not implemented.');
  if (stats?.updateMs + stats?.submitMs > 1000 / s.targetFPS * .8) add('warning', 'CPU update/submission is near the frame budget. Lowering resolution alone may not help.');
  if (!issues.length) add('ok', 'No issue detected by these basic checks. This is not a certification of performance or production readiness.');
  return issues;
}
