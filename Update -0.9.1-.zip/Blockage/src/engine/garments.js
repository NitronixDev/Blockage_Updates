import { clothTopology, topPins } from './cloth-topology.js';
import * as T from 'three/webgpu';
const tmp = new T.Vector3(),
  stamps = new WeakMap();
export function parts(root, id) {
  const out = [];
  function visit(o, p) {
    if (
      o.userData.editorOnly ||
      o.userData.runtimeVisual ||
      (o.userData.entityId && o.userData.entityId !== id)
    )
      return;
    if (o.isMesh && !o.isInstancedMesh && o.geometry?.attributes.position)
      out.push({
        mesh: o,
        path: p || '.',
        name: o.name || 'Mesh ' + (out.length + 1),
      });
    o.children.forEach((c, i) => visit(c, p ? p + '/' + i : String(i)));
  }
  if (root) visit(root, '');
  return out;
}
export function stamp(g) {
  if (stamps.has(g)) return stamps.get(g);
  const pos = g.attributes.position,
    idx = g.index;
  if (pos.count > 100000 || (idx?.count || pos.count) > 600000)
    throw Error('Submesh exceeds 100,000 vertices / 200,000 triangles');
  let h = 2166136261;
  const mix = (x) => {
      h = Math.imul(h ^ x, 16777619);
    },
    f = new Float32Array(1),
    bits = new Uint32Array(f.buffer);
  mix(pos.count);
  mix(idx?.count || 0);
  for (let i = 0; i < pos.count; i++)
    for (const v of [pos.getX(i), pos.getY(i), pos.getZ(i)]) {
      f[0] = v;
      mix(bits[0]);
    }
  if (idx) for (let i = 0; i < idx.count; i++) mix(idx.getX(i));
  const s = (h >>> 0).toString(16).padStart(8, '0');
  stamps.set(g, s);
  return s;
}
export function ranges(ids) {
  const r = [];
  for (const i of [...ids].sort((a, b) => a - b)) {
    const last = r.at(-1);
    if (last && last[1] + 1 === i) last[1] = i;
    else r.push([i, i]);
  }
  return r;
}
export function selected(rr) {
  const s = new Set();
  for (const [a, b] of rr) for (let i = a; i <= b; i++) s.add(i);
  return s;
}
export function projected(mesh, camera, w, h) {
  mesh.updateWorldMatrix(true, false);
  camera.updateWorldMatrix(true, false);
  const mat = new T.Matrix4()
      .multiplyMatrices(camera.projectionMatrix, camera.matrixWorldInverse)
      .multiply(mesh.matrixWorld),
    v = new T.Vector4(),
    out = [];
  for (let i = 0; i < mesh.geometry.attributes.position.count; i++) {
    mesh.getVertexPosition(i, tmp);
    v.set(tmp.x, tmp.y, tmp.z, 1).applyMatrix4(mat);
    if (v.w <= 0 || Math.abs(v.z / v.w) > 1) continue;
    out.push([i, ((1 + v.x / v.w) * w) / 2, ((1 - v.y / v.w) * h) / 2]);
  }
  return out;
}
export class Cloth {
  constructor(mesh, mask, c) {
    const source = mesh.geometry;
    if (
      source.attributes.position.count !== mask.count ||
      stamp(source) !== mask.stamp
    )
      throw Error('Mesh topology changed. Repaint cloth mask.');
    this.mesh = mesh;
    this.c = {
      bending: 0.025,
      subdivisions: 0,
      pinMode: 'boundary',
      thickness: 0.012,
      friction: 0.25,
      maxDistance: 0,
      ...c,
    };
    const chosen = selected(mask.ranges),
      pins = selected(mask.pins || []),
      auto = this.c.pinMode === 'top' ? topPins(source, chosen) : new Set();
    const { geo: g, weights } = clothTopology(
        source,
        chosen,
        this.c.subdivisions,
      ),
      p = g.attributes.position;
    this.weights = weights;
    this.sourcePose = new Float32Array(mask.count * 3);
    this.active = Uint8Array.from(weights, (w) =>
      w.some(([i]) => chosen.has(i)) &&
      !w.every(([i]) => pins.has(i) || !chosen.has(i)) &&
      !w.every(([i]) => auto.has(i))
        ? 1
        : 0,
    );
    this.ids = Int32Array.from(this.active.keys()).filter(
      (i) => this.active[i],
    );
    if (this.ids.length > 16384) {
      g.dispose();
      throw Error(
        'Cloth exceeds 16,384 moving vertices after refinement. Reduce Refinement.',
      );
    }
    this.base = new Float32Array(p.count * 3);
    this.sample();
    this.p = this.base.slice();
    this.old = this.p.slice();
    const idx = g.index,
      n = idx?.count || p.count,
      seen = new Set();
    this.edges = [];
    this.bends = [];
    this.pins = new Set();
    const adj = new Map();
    const edge = (a, b, bend = false) => {
      const k = Math.min(a, b) * p.count + Math.max(a, b);
      if (
        a === b ||
        !(this.active[a] || this.active[b]) ||
        (!bend && seen.has(k))
      )
        return;
      if (!bend) seen.add(k);
      const d = Math.hypot(
        ...[0, 1, 2].map((j) => this.p[3 * a + j] - this.p[3 * b + j]),
      );
      (bend ? this.bends : this.edges).push([a, b, d]);
      if (!this.active[a]) this.pins.add(a);
      if (!this.active[b]) this.pins.add(b);
    };
    for (let i = 0; i + 2 < n; i += 3) {
      const [a, b, d] = [0, 1, 2].map((k) => (idx ? idx.getX(i + k) : i + k));
      for (const [i, j, op] of [
        [a, b, d],
        [b, d, a],
        [d, a, b],
      ]) {
        edge(i, j);
        const k = Math.min(i, j) * p.count + Math.max(i, j);
        if (adj.has(k)) edge(op, adj.get(k), true);
        else adj.set(k, op);
      }
    }
    const seams = new Map();
    for (let i = 0; i < p.count; i++) {
      const key = [p.getX(i), p.getY(i), p.getZ(i)]
        .map((v) => Math.round(v * 1e5))
        .join('/');
      if (seams.has(key)) edge(i, seams.get(key));
      else seams.set(key, i);
    }
    this.original = mesh.material;
    this.hidden = new T.MeshBasicMaterial({ visible: false });
    const geo = g;
    geo.morphAttributes = {};
    geo.deleteAttribute('skinIndex');
    geo.deleteAttribute('skinWeight');
    this.draw = new T.BufferAttribute(
      new Float32Array(p.count * 3),
      3,
    ).setUsage(T.DynamicDrawUsage);
    geo.setAttribute('position', this.draw);
    this.materials = (
      Array.isArray(this.original) ? this.original : [this.original]
    ).map((m) => {
      const mat = m.clone();
      mat.side = T.DoubleSide;
      return mat;
    });
    this.proxy = new T.Mesh(
      geo,
      Array.isArray(this.original) ? this.materials : this.materials[0],
    );
    this.proxy.userData.runtimeVisual = true;
    this.proxy.frustumCulled = false;
    this.proxy.castShadow = mesh.castShadow;
    this.proxy.receiveShadow = mesh.receiveShadow;
    this.proxy.raycast = () => {};
    this.inv = new T.Matrix4();
    mesh.material = this.hidden;
    mesh.add(this.proxy);
    this.refresh();
  }
  sample() {
    const m = this.mesh;
    m.updateWorldMatrix(true, false);
    if (!m.isSkinnedMesh && !m.morphTargetInfluences?.length) {
      const version = m.geometry.attributes.position.version;
      if (
        this.poseMatrix?.equals(m.matrixWorld) &&
        this.poseVersion === version
      )
        return;
      this.poseMatrix ??= new T.Matrix4();
      this.poseMatrix.copy(m.matrixWorld);
      this.poseVersion = version;
    }
    for (let i = 0; i < m.geometry.attributes.position.count; i++)
      m.getVertexPosition(i, tmp)
        .applyMatrix4(m.matrixWorld)
        .toArray(this.sourcePose, i * 3);
    this.base.set(this.sourcePose);
    for (let i = this.sourcePose.length / 3; i < this.weights.length; i++) {
      const k = 3 * i;
      this.base[k] = this.base[k + 1] = this.base[k + 2] = 0;
      for (const [id, w] of this.weights[i])
        for (let j = 0; j < 3; j++)
          this.base[k + j] += w * this.sourcePose[3 * id + j];
    }
  }
  step(dt, all, colliders = []) {
    this.sample();
    const { p, old, base, c } = this;
    if (all) {
      p.set(base);
      old.set(base);
      return;
    }
    for (const i of this.pins)
      for (let j = 0; j < 3; j++)
        p[3 * i + j] = old[3 * i + j] = base[3 * i + j];
    for (const i of this.ids)
      for (let j = 0; j < 3; j++) {
        const k = 3 * i + j,
          prev = p[k];
        p[k] +=
          (prev - old[k]) * (1 - c.drag) +
          (j === 1 ? -c.gravity : j === 2 ? c.wind : 0) * dt * dt;
        old[k] = prev;
      }
    for (let s = 0; s < c.iterations; s++) {
      for (const [constraints, strength] of [
        [this.edges, c.stiffness],
        [this.bends, c.bending],
      ])
        for (const [a, b, d] of constraints) {
          const x = a * 3,
            y = b * 3,
            dx = p[y] - p[x],
            dy = p[y + 1] - p[x + 1],
            dz = p[y + 2] - p[x + 2],
            len = Math.hypot(dx, dy, dz);
          if (len < 1e-8) continue;
          const wa = this.active[a],
            wb = this.active[b],
            f = (((len - d) / len) * strength) / (wa + wb);
          p[x] += dx * f * wa;
          p[x + 1] += dy * f * wa;
          p[x + 2] += dz * f * wa;
          p[y] -= dx * f * wb;
          p[y + 1] -= dy * f * wb;
          p[y + 2] -= dz * f * wb;
        }
      for (const i of this.ids) {
        const k = i * 3;
        if (c.maxDistance > 0) {
          const d = Math.hypot(
            p[k] - base[k],
            p[k + 1] - base[k + 1],
            p[k + 2] - base[k + 2],
          );
          if (d > c.maxDistance)
            for (let j = 0; j < 3; j++)
              p[k + j] =
                base[k + j] + ((p[k + j] - base[k + j]) * c.maxDistance) / d;
        }
        for (const b of colliders) {
          let contact = false;
          if (b.type === 'sphere') {
            const dx = p[k] - b.center[0],
              dy = p[k + 1] - b.center[1],
              dz = p[k + 2] - b.center[2],
              len = Math.hypot(dx, dy, dz),
              r = b.radius + c.thickness;
            if (len < r) {
              const f = len > 1e-6 ? r / len : 0;
              p[k] = b.center[0] + dx * f;
              p[k + 1] = b.center[1] + (f ? dy * f : r);
              p[k + 2] = b.center[2] + dz * f;
              contact = true;
            }
          } else if (
            b.type === 'box' &&
            [0, 1, 2].every(
              (j) =>
                p[k + j] > b.min[j] - c.thickness &&
                p[k + j] < b.max[j] + c.thickness,
            )
          ) {
            let d = Infinity,
              axis = 0,
              face = 0;
            for (let j = 0; j < 3; j++)
              for (const side of [
                b.min[j] - c.thickness,
                b.max[j] + c.thickness,
              ])
                if (Math.abs(side - p[k + j]) < d) {
                  d = Math.abs(side - p[k + j]);
                  axis = j;
                  face = side;
                }
            p[k + axis] = face;
            contact = true;
          }
          if (contact)
            for (let j = 0; j < 3; j++)
              old[k + j] += (p[k + j] - old[k + j]) * c.friction;
        }
      }
    }
  }
  refresh() {
    this.inv.copy(this.mesh.matrixWorld).invert();
    for (let i = 0; i < this.active.length; i++)
      tmp
        .fromArray(this.active[i] ? this.p : this.base, i * 3)
        .applyMatrix4(this.inv)
        .toArray(this.draw.array, i * 3);
    this.draw.needsUpdate = true;
    this.proxy.geometry.computeVertexNormals();
  }
  dispose() {
    this.mesh.material = this.original;
    this.proxy.removeFromParent();
    this.proxy.geometry.dispose();
    for (const m of this.materials) m.dispose();
    this.hidden.dispose();
  }
}
export function bind(source, target) {
  source.updateWorldMatrix(true, false);
  target.updateWorldMatrix(true, false);
  if (Math.abs(target.matrixWorld.determinant()) < 1e-9)
    throw Error('Invalid weld target transform');
  return target.matrixWorld
    .clone()
    .invert()
    .multiply(source.matrixWorld)
    .toArray();
}
export class Welds {
  constructor(entities, objects) {
    this.links = [];
    this.fixed = new Set();
    const done = new Set(),
      by = new Map(entities.map((e) => [e.id, e]));
    const visit = (e) => {
      if (!e || done.has(e.id)) return;
      done.add(e.id);
      visit(by.get(e.parent));
      const links = e.behaviors.weld?.links || [];
      for (const l of links) visit(by.get(l.target));
      for (const l of [...links].sort(
        (a, b) =>
          (a.part === '@root' ? -1 : a.part.split('/').length) -
          (b.part === '@root' ? -1 : b.part.split('/').length),
      )) {
        const root = objects.get(e.id),
          src =
            l.part === '@root'
              ? root
              : parts(root, e.id).find((p) => p.path === l.part)?.mesh,
          t = objects.get(l.target);
        if (!src || !t || (l.stamp && stamp(src.geometry) !== l.stamp))
          throw Error('Weld part changed: ' + e.name);
        this.links.push({
          src,
          t,
          off: new T.Matrix4().fromArray(l.offset),
          m: src.matrix.clone(),
          auto: src.matrixAutoUpdate,
        });
        if (l.mode === 'all') this.fixed.add(e.id + ':' + l.part);
      }
    };
    for (const e of entities) visit(e);
    this.m = new T.Matrix4();
    this.inv = new T.Matrix4();
  }
  all(id, p) {
    if (this.fixed.has(id + ':@root') || this.fixed.has(id + ':.')) return true;
    for (;;) {
      if (this.fixed.has(id + ':' + p)) return true;
      const j = p.lastIndexOf('/');
      if (j < 0) return false;
      p = p.slice(0, j);
    }
  }
  step() {
    for (const { src, t, off } of this.links) {
      t.updateWorldMatrix(true, false);
      src.parent?.updateWorldMatrix(true, false);
      this.m.multiplyMatrices(t.matrixWorld, off);
      if (src.parent)
        this.m.premultiply(this.inv.copy(src.parent.matrixWorld).invert());
      src.matrixAutoUpdate = false;
      src.matrix.copy(this.m);
      this.m.decompose(src.position, src.quaternion, src.scale);
      src.matrixWorldNeedsUpdate = true;
      src.updateWorldMatrix(false, true);
    }
  }
  dispose() {
    for (const l of this.links) {
      l.src.matrixAutoUpdate = l.auto;
      l.src.matrix.copy(l.m);
      l.m.decompose(l.src.position, l.src.quaternion, l.src.scale);
      l.src.matrixWorldNeedsUpdate = true;
    }
  }
}
