
/** Runtime-only overrides: scripts must not modify the saved scene settings. */
export class ScriptLights {
  constructor() {
    this.original = new Map();
  }
  set(object, value) {
    if (
      !object ||
      !(object.isPointLight || object.isSpotLight || object.isDirectionalLight) ||
      !Number.isFinite(value)
    ) return false;
    if (!this.original.has(object)) this.original.set(object, object.intensity);
    object.intensity = Math.max(0, Math.min(10000, value));
    return true;
  }
  restore() {
    for (const [object, value] of this.original) object.intensity = value;
    this.original.clear();
  }
}
