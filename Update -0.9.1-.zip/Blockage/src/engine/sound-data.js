export function soundTrack(asset, spatial = false) {
  return {
    id: crypto.randomUUID(),
    name: asset.name,
    asset: asset.id,
    volume: 0.7,
    pitch: 1,
    distance: 3,
    rolloff: 1,
    loop: false,
    autoplay: true,
    spatial,
  };
}
export function tracks(doc) {
  return [
    ...(doc.sounds || []).map((c) => ({ id: c.id, owner: null, c })),
    ...doc.entities.flatMap((e) => [
      ...(e.sounds || []).map((c) => ({ id: c.id, owner: e.id, c })),
      ...(e.kind === 'audio'
        ? [{ id: e.id, owner: e.id, c: { ...e.audio, spatial: true } }]
        : []),
    ]),
  ];
}
export function validateSounds(d) {
  const ids = new Set(d.entities.map((e) => e.id)),
    assets = new Map(d.assets.map((a) => [a.id, a]));
  let n = 0;
  for (const [owner, list] of [
    [null, d.sounds],
    ...d.entities.map((e) => [e, e.sounds ?? []]),
  ]) {
    if (!Array.isArray(list) || list.length > 64)
      throw Error('Maximum 64 sounds per object or scene.');
    for (const c of list) {
      if (
        !c ||
        typeof c.id !== 'string' ||
        !c.id.length ||
        c.id.length > 200 ||
        ids.has(c.id) ||
        typeof c.name !== 'string' ||
        !c.name.length ||
        c.name.length > 200 ||
        assets.get(c.asset)?.type !== 'audio'
      )
        throw Error('Invalid sound / missing audio asset.');
      ids.add(c.id);
      for (const [k, a, b] of [
        ['volume', 0, 1],
        ['pitch', 0.25, 4],
        ['distance', 0.1, 1000],
        ['rolloff', 0, 5],
      ])
        if (!Number.isFinite(c[k]) || c[k] < a || c[k] > b)
          throw Error('Invalid sound ' + k);
      for (const k of ['loop', 'autoplay', 'spatial'])
        if (typeof c[k] !== 'boolean') throw Error('Invalid sound ' + k);
      if (!owner && c.spatial)
        throw Error('Attach a spatial sound to an object.');
      n++;
    }
  }
  if (n > 256) throw Error('Scene sound budget exceeded (256).');
}
