import { assetBytes } from './asset-source.js';
import { tracks } from './sound-data.js';
import * as T from 'three/webgpu';
export class AudioRuntime {
  constructor(camera, log = () => {}) {
    this.camera = camera;
    this.log = log;
    this.sounds = new Map();
    this.buffers = new Map();
    this.pending = new Map();
    this.epoch = 0;
    this.generation = 0;
  }
  clearSources() {
    for (const s of this.sounds.values()) {
      s.disconnect();
      s.gain.disconnect();
      s.removeFromParent();
    }
    this.sounds.clear();
  }
  async load(doc, objects) {
    this.stop();
    this.generation++;
    const gen = this.generation;
    this.clearSources();
    this.buffers.clear();
    this.pending.clear();
    this.doc = doc;
    this.objects = objects;
    this.entries = tracks(doc);
    this.assets = new Map(
      doc.assets.filter((a) => a.type === 'audio').map((a) => [a.id, a]),
    );
    if (!this.entries.some((t) => t.c.asset)) return;
    this.listener ??= new T.AudioListener();
    if (!this.listener.parent) this.camera.add(this.listener);
    await Promise.all(
      [...new Set(this.entries.map((t) => t.c.asset).filter(Boolean))].map(
        (id) =>
          this.ensureBuffer(id).catch((e) =>
            this.log('error', 'Audio: ' + e.message),
          ),
      ),
    );
    if (gen === this.generation)
      for (const t of this.entries) this.configureTrack(t);
  }
  async ensureBuffer(id) {
    if (this.buffers.has(id)) return this.buffers.get(id);
    if (this.pending.has(id)) return this.pending.get(id);
    const a = this.assets.get(id);
    if (!a) return null;
    const gen = this.generation;
    const p = assetBytes(a)
      .then((bytes) =>
        this.listener.context.decodeAudioData(
          bytes.buffer.slice(
            bytes.byteOffset,
            bytes.byteOffset + bytes.byteLength,
          ),
        ),
      )
      .then((b) => {
        if (gen === this.generation) this.buffers.set(id, b);
        return b;
      })
      .finally(() => {
        if (gen === this.generation) this.pending.delete(id);
      });
    this.pending.set(id, p);
    return p;
  }
  configureTrack({ id, c, owner }) {
    const b = this.buffers.get(c.asset);
    let s = this.sounds.get(id);
    if (s && (!b || s.userData.spatial !== c.spatial)) {
      if (s.isPlaying) s.stop();
      s.disconnect();
      s.gain.disconnect();
      s.removeFromParent();
      this.sounds.delete(id);
      s = null;
    }
    if (!b) return;
    if (!s) {
      s = c.spatial
        ? new T.PositionalAudio(this.listener)
        : new T.Audio(this.listener);
      s.userData.runtimeVisual = true;
      s.userData.spatial = c.spatial;
      (owner ? this.objects.get(owner) : this.camera)?.add(s);
      this.sounds.set(id, s);
    }
    if (s.buffer !== b) {
      if (s.isPlaying) s.stop();
      s.setBuffer(b);
    }
    s.setVolume(c.volume);
    s.setPlaybackRate(c.pitch);
    s.setLoop(c.loop);
    if (c.spatial) {
      s.setRefDistance(c.distance);
      s.setRolloffFactor(c.rolloff);
    }
  }
  configure(e) {
    if (!this.doc) return;
    this.entries = tracks(this.doc);
    for (const t of this.entries.filter((t) => t.owner === e.id)) {
      if (t.c.asset && !this.buffers.has(t.c.asset) && this.listener) {
        const gen = this.generation;
        this.ensureBuffer(t.c.asset)
          .then(() => {
            if (
              gen === this.generation &&
              this.entries.find((x) => x.id === t.id)?.c.asset === t.c.asset
            )
              this.configureTrack(t);
          })
          .catch((err) => this.log('error', 'Audio: ' + err.message));
      }
      this.configureTrack(t);
    }
  }
  configureScene() {
    this.entries = tracks(this.doc);
    for (const t of this.entries) if (!t.owner) this.configureTrack(t);
  }
  visible(id) {
    if (!id) return true;
    for (let o = this.objects.get(id); o; o = o.parent)
      if (!o.visible) return false;
    return true;
  }
  autoplay() {
    if (!this.active || this.paused || !this.pendingStart) return;
    this.pendingStart = false;
    for (const t of this.entries)
      if (t.c.autoplay && this.visible(t.owner)) {
        const s = this.sounds.get(t.id);
        if (s && !s.isPlaying) s.play();
      }
  }
  async start() {
    this.stop();
    this.active = true;
    this.pendingStart = true;
    const epoch = this.epoch;
    if (!this.listener) return;
    try {
      await this.listener.context.resume();
      if (epoch === this.epoch) this.autoplay();
    } catch (e) {
      this.log('warn', 'Audio: ' + e.message);
    }
  }
  async trigger(id) {
    const epoch = this.epoch;
    if (!this.active || this.paused) return;
    try {
      await this.listener?.context.resume();
      if (epoch !== this.epoch || !this.active || this.paused) return;
      for (const t of this.entries)
        if ((t.id === id || t.owner === id) && this.visible(t.owner)) {
          const s = this.sounds.get(t.id);
          if (s && !s.isPlaying) s.play();
        }
    } catch (e) {
      this.log('warn', 'Audio: ' + e.message);
    }
  }
  pause(paused) {
    this.paused = paused;
    const epoch = this.epoch;
    if (this.listener)
      (paused
        ? this.listener.context.suspend()
        : this.listener.context.resume()
      )
        .then(() => {
          if (epoch === this.epoch && !paused) this.autoplay();
        })
        .catch((e) => this.log('warn', e.message));
  }
  stop() {
    this.epoch++;
    this.active = this.paused = this.pendingStart = false;
    for (const s of this.sounds.values()) if (s.isPlaying) s.stop();
  }
  dispose() {
    this.stop();
    this.generation++;
    this.clearSources();
    this.buffers.clear();
    this.pending.clear();
    this.listener?.removeFromParent();
  }
}
