import { curve, checkCurve } from '../engine/effect-data.js';
export function editCurves(ed, e) {
  const keys = ['size', 'opacity', 'speed'],
    draft = structuredClone(e.behaviors.emitter.curves);
  ed.showModal(
    'Particle lifetime curves',
    '<p>Drag a key in the graph, or enter its time and value. Time 0 = birth, 1 = death. Size and speed multiply the base value; opacity is 0–1.</p><div id="curve-editor"></div>',
    [
      { label: 'Cancel', action: () => ed.closeModal() },
      {
        label: 'Apply curves',
        primary: true,
        action: async () => {
          try {
            for (const input of root.querySelectorAll('input[data-key]')) {
              if (!input.value.trim())
                throw Error('Enter a value for each key.');
              draft[input.dataset.key][Number(input.dataset.index)][
                Number(input.dataset.axis)
              ] = Number(input.value.replace(',', '.'));
            }
            for (const k of keys) checkCurve(draft[k], k === 'opacity' ? 1 : 8);
          } catch (err) {
            ed.toast(err.message, true);
            return;
          }
          ed.closeModal();
          await ed.mutate(
            'Updated lifetime curves.',
            () => {
              e.behaviors.emitter.curves = draft;
            },
            false,
          );
        },
      },
    ],
  );
  const root = document.querySelector('#curve-editor');
  function render() {
    root.innerHTML = keys
      .map((key) => {
        const points = draft[key],
          max = key === 'opacity' ? 1 : Math.max(1, ...points.map((p) => p[1])),
          path = points
            .map(
              ([x, y], i) =>
                (i ? 'L' : 'M') + x * 240 + ',' + (68 - (y / max) * 62),
            )
            .join(' ');
        return (
          '<section class="curve-section"><strong>' +
          key +
          '</strong><svg data-curve="' +
          key +
          '" viewBox="0 0 240 76" role="img" aria-label="' +
          key +
          ' curve"><path d="' +
          path +
          '" fill="none" stroke="#61d6bd" stroke-width="3"/>' +
          points
            .map(
              ([x, y]) =>
                '<circle cx="' +
                x * 240 +
                '" cy="' +
                (68 - (y / max) * 62) +
                '" r="5" fill="#b9ffde"/>',
            )
            .join('') +
          '</svg>' +
          points
            .map(
              ([x, y], i) =>
                '<div class="curve-key"><label>Time<input type="text" inputmode="decimal" min="0" max="1" step=".01" data-key="' +
                key +
                '" data-index="' +
                i +
                '" data-axis="0" value="' +
                x +
                '" ' +
                (i === 0 || i === points.length - 1 ? 'disabled' : '') +
                '></label><label>Value<input type="text" inputmode="decimal" min="0" max="' +
                (key === 'opacity' ? 1 : 8) +
                '" step=".05" data-key="' +
                key +
                '" data-index="' +
                i +
                '" data-axis="1" value="' +
                y +
                '"></label>' +
                (i && i < points.length - 1
                  ? '<button data-delete="' +
                    key +
                    '" data-index="' +
                    i +
                    '">−</button>'
                  : '') +
                '</div>',
            )
            .join('') +
          '<button data-add="' +
          key +
          '" ' +
          (points.length >= 8 ? 'disabled' : '') +
          '>+ Key</button></section>'
        );
      })
      .join('');
  }
  root.oninput = (ev) => {
    const b = ev.target,
      k = b.dataset.key;
    if (!k || !b.value.trim()) return;
    const a = draft[k],
      i = Number(b.dataset.index),
      j = Number(b.dataset.axis),
      v = Number(b.value.replace(',', '.'));
    if (!Number.isFinite(v)) return;
    a[i][j] = v;
    const max = k === 'opacity' ? 1 : Math.max(1, ...a.map((p) => p[1]));
    b.closest('.curve-section')
      .querySelector('path')
      .setAttribute(
        'd',
        a
          .map(
            ([x, y], n) =>
              (n ? 'L' : 'M') + x * 240 + ',' + (68 - (y / max) * 62),
          )
          .join(' '),
      );
  };
  let drag = null;
  function updatePoint(ev) {
    if (!drag) return;
    const { key, i, ctm, max } = drag,
      a = draft[key],
      p = new DOMPoint(ev.clientX, ev.clientY).matrixTransform(ctm),
      round = (v) => Math.round(v * 1000) / 1000;
    const y = round(Math.max(0, Math.min(max, ((68 - p.y) * max) / 62)));
    a[i][1] = y;
    if (i > 0 && i < a.length - 1)
      a[i][0] = Math.max(
        a[i - 1][0] + 0.00001,
        Math.min(a[i + 1][0] - 0.00001, round(p.x / 240)),
      );
    render();
  }
  root.onpointerdown = (ev) => {
    const svg = ev.target.closest('svg[data-curve]');
    if (!svg || ev.button !== 0) return;
    const key = svg.dataset.curve,
      a = draft[key],
      ctm = svg.getScreenCTM().inverse(),
      p = new DOMPoint(ev.clientX, ev.clientY).matrixTransform(ctm);
    let i = 0;
    for (let j = 1; j < a.length; j++)
      if (Math.abs(a[j][0] - p.x / 240) < Math.abs(a[i][0] - p.x / 240)) i = j;
    drag = {
      key,
      i,
      ctm,
      max:
        key === 'opacity' ? 1 : Math.min(8, Math.max(1, ...a.map((k) => k[1]))),
    };
    ev.preventDefault();
    root.setPointerCapture(ev.pointerId);
    updatePoint(ev);
  };
  root.onpointermove = updatePoint;
  root.onpointerup = (ev) => {
    if (drag) updatePoint(ev);
    drag = null;
  };
  root.onpointercancel = () => {
    drag = null;
  };
  root.onclick = (ev) => {
    const b = ev.target.closest('button');
    if (!b) return;
    if (b.dataset.delete) draft[b.dataset.delete].splice(+b.dataset.index, 1);
    if (b.dataset.add) {
      const a = draft[b.dataset.add];
      let i = 0;
      for (let j = 1; j < a.length - 1; j++)
        if (a[j + 1][0] - a[j][0] > a[i + 1][0] - a[i][0]) i = j;
      const x = (a[i][0] + a[i + 1][0]) / 2;
      a.splice(i + 1, 0, [x, curve(a, x)]);
    }
    render();
  };
  render();
}
