import { bridge } from './bridge.js';
import { soundTrack } from '../engine/sound-data.js';
const esc = (v) =>
  String(v).replace(
    /[&<>"']/g,
    (c) =>
      ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[
        c
      ],
  );
export function installSounds(Editor) {
  const p = Editor.prototype,
    settings = p.renderSettings,
    inspector = p.renderInspector,
    action = p.action,
    events = p.installEvents,
    add = p.addMenu;
  p.soundFields = function (owner) {
    const scene = !owner,
      list = (owner || this.doc).sounds || [],
      prefix = scene ? 'world.sounds.' : 'sounds.';
    return (
      '<p class="small-note">' +
      (scene
        ? 'Scene music and ambience (2D).'
        : 'Sounds play directly on this object. No helper object needed.') +
      '</p>' +
      list
        .map((c, i) => {
          const k = prefix + i + '.';
          return (
            '<div class="sound-track"><strong>' +
            esc(c.name) +
            '</strong><button data-sound-remove="' +
            i +
            '" data-sound-scene="' +
            scene +
            '">Remove</button>' +
            this.rangeField('Volume', k + 'volume', c.volume) +
            this.numberField('Pitch', k + 'pitch', c.pitch, 0.25, 4, 0.01) +
            this.checkField('Loop', k + 'loop', c.loop) +
            this.checkField('Play on Start', k + 'autoplay', c.autoplay) +
            (scene
              ? ''
              : this.checkField('Spatial (3D)', k + 'spatial', c.spatial) +
                this.numberField(
                  'Distance (m)',
                  k + 'distance',
                  c.distance,
                  0.1,
                  1000,
                  0.1,
                ) +
                this.numberField(
                  'Rolloff',
                  k + 'rolloff',
                  c.rolloff,
                  0,
                  5,
                  0.1,
                )) +
            '</div>'
          );
        })
        .join('') +
      '<button data-action="' +
      (scene ? 'sceneSound' : 'objectSound') +
      '">+ Add sound…</button>'
    );
  };
  p.renderSettings = function () {
    settings.call(this);
    document
      .querySelector('#inspector-content>div:last-child')
      ?.insertAdjacentHTML(
        'beforeend',
        '<section class="inspector-section"><div class="section-title">Sounds</div>' +
          this.soundFields(null) +
          '</section>',
      );
  };
  p.renderInspector = function () {
    inspector.call(this);
    if (!this.settingsView && this.selected)
      document
        .querySelector('#inspector-content>div:last-child')
        ?.insertAdjacentHTML(
          'beforeend',
          this.group('sounds', 'Sounds', this.soundFields(this.selected)),
        );
  };
  p.attachSound = async function (
    id,
    owner = this.settingsView ? null : this.selected,
  ) {
    if (owner?.locked || this.playing || this.busy) return;
    const asset = this.doc.assets.find(
      (a) => a.id === id && a.type === 'audio',
    );
    if (!asset) return;
    await this.mutate('Added sound: ' + asset.name, () => {
      const host = owner || this.doc;
      host.sounds ??= [];
      host.sounds.push(soundTrack(asset, !!owner));
      this.propertyOpen.add('sounds');
      if (!owner) this.settingsView = true;
    });
  };
  p.importSound = async function (owner = null) {
    if (this.playing || this.busy || owner?.locked || this.importing) return;
    const doc = this.doc;
    this.importing = true;
    let result;
    try {
      result = await bridge.importAssets(false, true);
    } finally {
      this.importing = false;
    }
    if (!result.ok) return this.toast(result.error, true);
    if (result.canceled || doc !== this.doc) return;
    if (result.assets.some((a) => a.type !== 'audio'))
      return this.toast('Choose WAV, MP3 or OGG sounds.', true);
    await this.mutate('Added ' + result.assets.length + ' sound(s).', () => {
      doc.assets.push(...result.assets);
      const host = owner || doc;
      host.sounds ??= [];
      host.sounds.push(...result.assets.map((a) => soundTrack(a, !!owner)));
      this.propertyOpen.add('sounds');
      if (!owner) this.settingsView = true;
    });
  };
  p.addMenu = function (a) {
    add.call(this, a);
    this.showDropdown(a, [
      ...this.dropdownEntries,
      {
        label: 'Sound…',
        icon: 'waveform',
        action: () => this.importSound(null),
      },
    ]);
  };
  p.action = function (id, a) {
    if (id === 'sceneSound') return this.importSound(null);
    if (id === 'objectSound') return this.importSound(this.selected);
    return action.call(this, id, a);
  };
  p.installEvents = function () {
    events.call(this);
    document.addEventListener('click', (ev) => {
      const b = ev.target.closest('[data-sound-remove]');
      if (!b) return;
      const host = b.dataset.soundScene === 'true' ? this.doc : this.selected;
      if (!host || host.locked) return;
      this.mutate('Removed sound.', () =>
        host.sounds.splice(+b.dataset.soundRemove, 1),
      );
    });
  };
}
