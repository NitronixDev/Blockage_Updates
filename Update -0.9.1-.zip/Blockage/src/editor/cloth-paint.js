import { topPins } from '../engine/cloth-topology.js';
import {
  parts,
  stamp,
  selected,
  ranges,
  projected,
} from '../engine/garments.js';
import { garment } from '../engine/workshop-data.js';
export function paint(editor, e) {
  editor.closePaint?.();
  const list = parts(editor.engine.objects.get(e.id), e.id);
  if (!list.length) throw Error('Select a model with a triangle mesh.');
  const view = document.querySelector('#viewport'),
    panel = document.createElement('section');
  panel.className = 'cloth-paint';
  panel.innerHTML =
    '<canvas aria-label="Select garment vertices"></canvas><div><b>Garment mask</b><select aria-label="Submesh"></select><select aria-label="Operation"><option>Replace</option><option>Add</option><option>Subtract</option><option>Pin</option><option>Unpin</option></select><span></span><button class="all">All cloth</button><button class="clear">Clear</button><button class="top">Pin top edge</button><button class="apply">Apply</button><button class="cancel">Cancel</button><small>Drag through the mesh · Cyan = cloth · Amber = pinned · Shift adds · Alt pins</small></div>';
  view.append(panel);
  const [choice, operation] = panel.querySelectorAll('select'),
    can = panel.querySelector('canvas'),
    ctx = can.getContext('2d'),
    label = panel.querySelector('span'),
    draft = new Map(
      (e.behaviors.garment?.regions || []).map((r) => [
        r.path,
        structuredClone(r),
      ]),
    );
  list.forEach((v, i) => choice.add(new Option(v.name + ' · ' + v.path, i)));
  let mesh,
    path,
    signature,
    ids,
    pins,
    points = [],
    start,
    end,
    changed = false;
  function store() {
    if (!changed) return;
    if (ids.size)
      draft.set(path, {
        path,
        stamp: signature,
        count: mesh.geometry.attributes.position.count,
        ranges: ranges(ids),
        pins: ranges([...pins].filter((i) => ids.has(i))),
      });
    else draft.delete(path);
    changed = false;
  }
  function draw() {
    const r = can.getBoundingClientRect();
    const d = Math.min(devicePixelRatio, 2);
    can.width = Math.ceil(r.width * d);
    can.height = Math.ceil(r.height * d);
    ctx.setTransform(d, 0, 0, d, 0, 0);
    for (const [i, x, y] of points) {
      ctx.fillStyle =
        pins.has(i) && ids.has(i)
          ? '#ffb84d'
          : ids.has(i)
            ? '#53ffdc'
            : '#c3d1d690';
      const s = ids.has(i) ? 3 : 1.5;
      ctx.fillRect(x - s / 2, y - s / 2, s, s);
    }
    if (start) {
      ctx.strokeStyle = '#55ffce';
      ctx.fillStyle = '#31c7a92a';
      ctx.fillRect(...start, end[0] - start[0], end[1] - start[1]);
      ctx.strokeRect(...start, end[0] - start[0], end[1] - start[1]);
    }
    label.textContent =
      ids.size +
      ' cloth · ' +
      [...pins].filter((i) => ids.has(i)).length +
      ' pinned / ' +
      mesh.geometry.attributes.position.count;
  }
  function measure() {
    if (!mesh) return;
    const r = can.getBoundingClientRect();
    points = signature
      ? projected(mesh, editor.engine.camera, r.width, r.height)
      : [];
    draw();
  }
  function choose() {
    store();
    ({ mesh, path } = list[+choice.value]);
    ids = new Set();
    pins = new Set();
    signature = null;
    try {
      signature = stamp(mesh.geometry);
      const r = draft.get(path);
      if (r && r.stamp === signature) {
        ids = selected(r.ranges);
        pins = selected(r.pins || []);
      } else if (r) {
        draft.delete(path);
        editor.toast('Topology changed. Repaint this submesh.', true);
      }
    } catch (err) {
      editor.toast(err.message, true);
    }
    measure();
  }
  const pt = (ev) => {
    const b = can.getBoundingClientRect();
    return [ev.clientX - b.left, ev.clientY - b.top];
  };
  can.onpointerdown = (ev) => {
    if (ev.button || !signature) return;
    can.setPointerCapture(ev.pointerId);
    end = start = pt(ev);
    draw();
  };
  can.onpointermove = (ev) => {
    if (start) {
      end = pt(ev);
      draw();
    }
  };
  can.onpointerup = (ev) => {
    if (!start) return;
    end = pt(ev);
    const op = ev.altKey ? 'Pin' : ev.shiftKey ? 'Add' : operation.value;
    if (op === 'Replace') ids.clear();
    for (const [i, x, y] of points)
      if (
        x >= Math.min(start[0], end[0]) - 2 &&
        x <= Math.max(start[0], end[0]) + 2 &&
        y >= Math.min(start[1], end[1]) - 2 &&
        y <= Math.max(start[1], end[1]) + 2
      ) {
        if (op === 'Pin') {
          ids.add(i);
          pins.add(i);
        } else if (op === 'Unpin') pins.delete(i);
        else if (op === 'Subtract') {
          ids.delete(i);
          pins.delete(i);
        } else ids.add(i);
      }
    start = end = null;
    changed = true;
    draw();
  };
  can.onpointercancel = () => {
    start = end = null;
    draw();
  };
  const ctrl = editor.engine.controls,
    prev = ctrl.enabled;
  ctrl.enabled = false;
  const ro = new ResizeObserver(measure);
  ro.observe(can);
  const close = () => {
    ro.disconnect();
    ctrl.enabled = prev;
    panel.remove();
    editor.closePaint = null;
  };
  editor.closePaint = close;
  choice.onchange = choose;
  panel.querySelector('.all').onclick = () => {
    if (!signature) return;
    ids = new Set(
      Array.from(
        { length: mesh.geometry.attributes.position.count },
        (_, i) => i,
      ),
    );
    changed = true;
    draw();
  };
  panel.querySelector('.clear').onclick = () => {
    ids.clear();
    pins.clear();
    changed = true;
    draw();
  };
  panel.querySelector('.top').onclick = () => {
    for (const i of topPins(mesh.geometry, ids)) pins.add(i);
    changed = true;
    draw();
  };
  panel.querySelector('.cancel').onclick = close;
  panel.querySelector('.apply').onclick = async () => {
    store();
    close();
    await editor.mutate('Updated garment mask.', () => {
      e.behaviors.garment ??= structuredClone(garment);
      if ([...draft.values()].some((r) => r.pins?.length))
        e.behaviors.garment.pinMode = 'boundary';
      e.behaviors.garment.regions = [...draft.values()];
      editor.propertyOpen.add('garment');
    });
  };
  choose();
}
