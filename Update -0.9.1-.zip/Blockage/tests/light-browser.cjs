
/* Optional integration test. Requires Playwright; starts its own local preview. */
const fs=require('node:fs/promises'),path=require('node:path'),assert=require('node:assert/strict');
const {spawn}=require('node:child_process');
const {chromium}=require(process.env.PLAYWRIGHT_MODULE||(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/playwright'));
(async()=>{
 const preview=process.env.BLOCKAGE_TEST_URL?null:spawn(process.execPath,[path.join(__dirname,'../scripts/preview.mjs')],{env:{...process.env,BLOCKAGE_PREVIEW_PORT:'4189'},stdio:['ignore','pipe','pipe']});
 if(preview)await new Promise((resolve,reject)=>{const timer=setTimeout(()=>{preview.kill();reject(Error('Preview did not start'));},10000);preview.once('error',e=>{clearTimeout(timer);reject(e);});preview.stdout.once('data',()=>{clearTimeout(timer);resolve();});preview.once('exit',code=>{clearTimeout(timer);reject(Error('Preview exited: '+code));});});
 let browser;
 try{
  browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH,headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'],env:{...process.env}});
  const page=await browser.newPage({viewport:{width:1280,height:800}}),errors=[];
  page.on('pageerror',e=>errors.push(e.message));
  await page.goto(process.env.BLOCKAGE_TEST_URL||'http://127.0.0.1:4189/src/index.html?compat');console.log('Page loaded');
  await page.waitForFunction(()=>window.blockageEditor&&!window.blockageEditor.busy,{},{timeout:120000});
  console.log('Editor ready');
  const source=await fs.readFile(path.join(__dirname,'../docs/snippets/Alarm.cpp'),'utf8');
  await page.evaluate(async source=>{
    const {createDocument,createEntity}=await import('/src/engine/document.js');
    const d=createDocument('Alarm verification'),plane=createEntity('box',{id:'wall',name:'Wall'}),light=createEntity('pointLight',{id:'alarm',name:'Alarme'});
    plane.transform.position=[0,1,0];plane.transform.scale=[4,3,.3];plane.material.color='#ffffff';plane.material.metalness=0;plane.material.roughness=1;
    light.transform.position=[0,1,2];light.light.intensity=37;light.light.color='#ff0000';
    d.entities.push(plane,light);d.scripts=[{id:'alarm-code',name:'Alarm',type:'world',owner:null,enabled:true,source}];
    Object.assign(d.settings,{ambient:0,environmentIntensity:0,background:'#070707',fog:0,grid:false,bloom:false,shadows:false,maxPixelRatio:1,dynamicResolution:false});
    d.camera={position:[4,2,7],target:[0,1,0]};
    const e=window.blockageEditor;await e.replaceDocument(d);e.select(null);
    window.alarmSamples=[];
    const frame=e.engine.frame;
    e.engine.frame=function(now){const result=frame.call(this,now);if(this.simulation.running)window.alarmSamples.push(this.objects.get('alarm').intensity);return result;};
    await e.play();
  },source);
  console.log('Play returned');
  await page.waitForFunction(()=>window.alarmSamples?.some(v=>v>75)&&window.alarmSamples.some(v=>v<2),{},{timeout:60000});
  const result=await page.evaluate(()=>{const e=window.blockageEditor,values=window.alarmSamples;const data={backend:e.engine.backend,samples:values.length,min:Math.min(...values),max:Math.max(...values),draws:e.engine.renderer.info.render.drawCalls,savedIntensity:e.doc.entities.find(x=>x.id==='alarm').light.intensity,errors:e.logs.filter(x=>x.level==='error')};e.stop();data.restored=e.engine.objects.get('alarm').intensity;return data;});
  assert(result.max>75);assert(result.min<2);assert(result.draws>0);assert.equal(result.savedIntensity,37);assert.equal(result.restored,37);assert.deepEqual(errors,[]);assert.deepEqual(result.errors,[]);
  console.log(JSON.stringify(result));
 }catch(e){console.error('Browser test failure:',e);throw e;}finally{preview?.kill();await browser?.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
