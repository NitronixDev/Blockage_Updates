
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {Worker} from 'node:worker_threads';
import * as T from 'three/webgpu';
import {ScriptLights} from '../src/engine/script-lights.js';
import {Live} from '../src/engine/workshop-runtime.js';
import {createDocument,createEntity} from '../src/engine/document.js';
import {compileCpp} from '../src/compiler/compiler.js';
import {exportGame} from '../electron/export-game.cjs';
import {AssetStore} from '../electron/asset-store.cjs';
const read=n=>fs.readFile(new URL('../src/compiler/toolchain/'+n+'.wasm',import.meta.url));
const source=await fs.readFile(new URL('../docs/snippets/Alarm.cpp',import.meta.url),'utf8');
const program=compileCpp(source,[],read);
function worker(){
  const url=new URL('../src/engine/script-worker.js',import.meta.url).href;
  const shim='import {parentPort} from "node:worker_threads";globalThis.self={postMessage:m=>parentPort.postMessage(m)};await import('+JSON.stringify(url)+');parentPort.on("message",data=>self.onmessage({data}));';
  const w=new Worker(new URL('data:text/javascript,'+encodeURIComponent(shim)));
  return {w,send:m=>new Promise((resolve,reject)=>{
    const timer=setTimeout(()=>{w.off('message',done);reject(Error('Worker timed out'));},5000);
    const done=v=>{clearTimeout(timer);resolve(v);};w.once('message',done);
    w.postMessage({...m,state:new Float32Array(8),keys:[]});
  })};
}
test('intensity overrides accept only supported lights, clamp values and restore once',()=>{
  const values=new ScriptLights(),point=new T.PointLight('#ff0000',37),spot=new T.SpotLight('#ffffff',22),sun=new T.DirectionalLight('#ffffff',3),mesh=new T.Mesh();
  assert(values.set(point,80));assert.equal(point.intensity,80);assert(values.set(point,10));
  assert(values.set(spot,-2));assert.equal(spot.intensity,0);
  assert(values.set(sun,99999));assert.equal(sun.intensity,10000);
  assert.equal(values.set(mesh,20),false);assert.equal(mesh.intensity,undefined);
  assert.equal(values.set(point,NaN),false);assert.equal(values.set(point,Infinity),false);assert.equal(values.set(null,3),false);
  values.restore();assert.equal(point.intensity,37);assert.equal(spot.intensity,22);assert.equal(sun.intensity,3);
  values.restore();assert.equal(values.original.size,0);
});
test('real compiled alarm passes through Worker and Live to a PointLight, then Stop restores settings',async()=>{
  const bytes=await program,wk=worker(),doc=createDocument(),ent=createEntity('pointLight',{id:'alarm',name:'Alarme'});ent.light.intensity=37;doc.entities.push(ent);
  const point=new T.PointLight('#ff0000',37),e={doc,objects:new Map([['alarm',point]]),events:{hud(){}}};
  const live=new Live(e,[]);live.ids=[null,'alarm'];live.w={terminate(){}};live.busy=true;
  const drain=m=>{assert.equal(m.error,undefined);live.commands.push(...m.commands);live.scripts();return point.intensity;};
  try{
    assert.equal(drain(await wk.send({type:'init',names:[['Alarme',1]],units:[{name:'Alarm',owner:0,bytes}]})),0);
    const samples=[];
    for(let i=0;i<144;i++)samples.push(drain(await wk.send({type:'tick',steps:1,events:[]})));
    assert(samples.every(v=>Number.isFinite(v)&&v>=0&&v<=80));
    assert(samples[35]>79.99);assert(samples[71]<.001);assert(samples[107]>79.99);assert(samples[143]<.001);
    for(let i=1;i<samples.length;i++)assert(Math.abs(samples[i]-samples[i-1])<4);
    for(let i=1;i<35;i++)assert(samples[i]>=samples[i-1]);
    for(let i=36;i<71;i++)assert(samples[i]<=samples[i-1]);
    assert.equal(ent.light.intensity,37,'saved scene must remain unchanged');
  }finally{live.dispose();await wk.w.terminate();}
  assert.equal(point.intensity,37);
  assert.equal(live.lights.original.size,0);
});
test('alarm without its named light returns a readable error and sends no intensity command',async()=>{
  const wk=worker();try{
    const m=await wk.send({type:'init',names:[],units:[{name:'Alarm',owner:0,bytes:await program}]});
    assert.deepEqual(m.commands,[['hud',0,'Lumiere Alarme introuvable']]);
    assert.deepEqual((await wk.send({type:'tick',steps:60,events:[]})).commands,[]);
  }finally{await wk.w.terminate();}
});
test('worker rejects non-finite intensity without changing a light',async()=>{
  const bytes=await compileCpp('#include "blockage.hpp"\nBG_START { bg::setLightIntensity(bg::self(),0.0f/0.0f); }',[],read),wk=worker();
  try{const m=await wk.send({type:'init',names:[],units:[{name:'BadLight',owner:1,bytes}]});assert.equal(m.commands.length,1);assert.equal(m.commands[0][0],'error');assert.match(m.commands[0][2],/Invalid number/);}finally{await wk.w.terminate();}
});
test('game export allows the new import and includes the exact light runtime',async()=>{
  const temp=await fs.mkdtemp(path.join(os.tmpdir(),'blockage-light-export-'));
  try{
    // Stub PE is only an export fixture, never a deliverable or a Windows launch test.
    const runtime=path.join(temp,'runtime');await fs.mkdir(path.join(runtime,'locales'),{recursive:true});
    const pe=Buffer.alloc(512);pe.writeUInt16LE(0x5a4d);pe.writeUInt32LE(128,60);pe.writeUInt32LE(0x4550,128);pe.writeUInt16LE(0x8664,132);await fs.writeFile(path.join(runtime,'fixture.exe'),pe);
    for(const n of ['resources.pak','icudtl.dat','ffmpeg.dll','locales/en-US.pak'])await fs.writeFile(path.join(runtime,n),'fixture');
    const doc=createDocument('LightExport');doc.entities.push(createEntity('pointLight',{id:'alarm',name:'Alarme'}));
    doc.scripts.push({id:'code',name:'Alarm',type:'world',owner:null,enabled:true,source});
    const r=await exportGame({root:path.resolve(import.meta.dirname,'..'),scene:doc,units:[{id:'code',data:Buffer.from(await program).toString('base64')}],assetStore:new AssetStore(path.join(temp,'assets')),runtimeExe:path.join(runtime,'fixture.exe'),parent:temp});
    const pub=path.join(path.dirname(r.executable),'resources/app/public');
    assert.deepEqual(await fs.readFile(path.join(pub,'scripts/0.wasm')),Buffer.from(await program));
    assert.deepEqual(await fs.readFile(path.join(pub,'engine/script-lights.js')),await fs.readFile(new URL('../src/engine/script-lights.js',import.meta.url)));
  }finally{await fs.rm(temp,{recursive:true,force:true});}
});
