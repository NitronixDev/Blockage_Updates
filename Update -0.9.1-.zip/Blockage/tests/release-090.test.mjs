import test from 'node:test';
import assert from 'node:assert/strict';
import * as T from 'three/webgpu';
import {
  createDocument,
  createEntity,
  validateDocument,
  duplicateEntities,
} from '../src/engine/document.js';
import { garment, vfx } from '../src/engine/workshop-data.js';
import { Cloth, stamp } from '../src/engine/garments.js';
import { topPins } from '../src/engine/cloth-topology.js';
import { Simulation } from '../src/engine/simulation.js';
import { WaterSolver, WATER_DEFAULTS } from '../src/engine/water.js';
import { Emitter } from '../src/engine/emitters.js';
import { curve, checkCurve } from '../src/engine/effect-data.js';
import { soundTrack } from '../src/engine/sound-data.js';
import { AudioRuntime } from '../src/engine/audio.js';
import { createPrefab, instantiatePrefab } from '../src/engine/prefab.js';
import { WorldRenderer } from '../src/engine/renderer.js';
const near = (a, b) => assert(Math.abs(a - b) < 1e-5, a + ' vs ' + b);
const fixture = () => {
  const g = new T.PlaneGeometry(3, 3).rotateX(-Math.PI / 2),
    m = new T.Mesh(g, new T.MeshBasicMaterial());
  m.position.set(2, 3, 1);
  return { g, m, mask: { count: 4, stamp: stamp(g), ranges: [[0, 3]] } };
};
test('refinement produces draping on four-vertex flat mesh without translating the host', () => {
  const { g, m, mask } = fixture(),
    before = g.attributes.position.array.slice(),
    root = m.position.toArray(),
    pins = topPins(g, [0, 1, 2, 3]),
    s = new Cloth(m, mask, { ...garment, wind: 1 });
  assert.equal(pins.size, 2);
  assert.equal(s.draw.count, 25);
  assert.equal(s.ids.length, 20);
  for (let i = 0; i < 120; i++) s.step(1 / 60, false);
  s.refresh();
  assert(s.ids.some((i) => Math.abs(s.p[i * 3 + 1] - s.base[i * 3 + 1]) > 0.1));
  for (const i of pins) near(s.draw.getY(i), g.attributes.position.getY(i));
  assert.deepEqual(root, m.position.toArray());
  assert.deepEqual(g.attributes.position.array, before);
  s.dispose();
  assert.equal(m.children.length, 0);
});
test('no painted area adds neither rigid body nor motion; Stop restores mesh and transform', () => {
  const { g, m, mask } = fixture(),
    e = createEntity('plane'),
    sim = new Simulation(),
    initial = m.position.clone(),
    mat = m.material;
  e.behaviors.garment = { ...garment, regions: [] };
  sim.start([e], new Map([[e.id, m]]));
  for (let i = 0; i < 80; i++) sim.step();
  assert(m.position.equals(initial));
  assert(!sim.rigidWorld);
  sim.stop();
  const s = new Cloth(m, { ...mask, ranges: [] }, garment);
  assert.equal(s.ids.length, 0);
  s.step(1 / 60, false);
  s.refresh();
  for (let i = 0; i < s.draw.array.length; i++)
    near(s.draw.array[i], g.attributes.position.array[i]);
  s.dispose();
  assert.equal(m.material, mat);
  assert(m.position.equals(initial));
});
test('explicit pins travel with a moving host, while an all-weld locks the entire cloth', () => {
  const { g, m, mask } = fixture(),
    s = new Cloth(
      m,
      { ...mask, pins: [[0, 1]] },
      { ...garment, pinMode: 'boundary' },
    );
  m.position.y = 5;
  for (let i = 0; i < 180; i++) s.step(1 / 60, false);
  s.refresh();
  near(s.draw.getY(0), g.attributes.position.getY(0));
  assert(s.draw.getY(3) < -0.1);
  s.step(1 / 60, true);
  s.refresh();
  for (let i = 0; i < 4; i++)
    near(s.draw.getY(i), g.attributes.position.getY(i));
  s.dispose();
});
test('seeded water varies spatially and temporally; visual mesh and physical height match on the grid', () => {
  const c = { ...WATER_DEFAULTS, resolution: 16, rainRate: 0 },
    a = new WaterSolver(c),
    b = new WaterSolver(c),
    other = new WaterSolver({ ...c, seed: c.seed + 1 });
  assert.deepEqual(a.positions, b.positions);
  assert.notDeepEqual(a.positions, other.positions);
  a.ripple(0.1, 0.2, 0.3);
  for (let i = 0; i < 17; i++) a.step(1 / 60);
  a.updatePositions();
  for (let i = 0; i < a.count; i++)
    near(
      a.sample(a.positions[i * 3], a.positions[i * 3 + 2]),
      a.positions[i * 3 + 1],
    );
  assert(
    Math.abs(a.baseWave(0.3, 0.2) - a.baseWave(0.3 + c.wavelength, 0.2)) >
      0.001,
  );
  a.reset();
  assert.deepEqual(a.positions, b.positions);
});
test('particle delay, cycle, seed and capacity bound are applied at runtime', () => {
  const c = {
      ...structuredClone(vfx),
      capacity: 20,
      burst: 2,
      rate: 0,
      delay: 0.1,
      duration: 0.2,
      loop: true,
      lifeMin: 10,
      lifeMax: 10,
    },
    o = new T.Group(),
    a = new Emitter(c, new T.Scene()),
    b = new Emitter(c, new T.Scene());
  a.start(o);
  b.start(o);
  assert.equal(a.count, 0);
  a.step(0.11, o);
  b.step(0.11, o);
  assert.equal(a.count, 2);
  assert.deepEqual(a.p, b.p);
  a.step(0.2, o);
  assert.equal(a.count, 4);
  a.emit(100, o);
  assert.equal(a.count, 20);
  assert(a.dropped > 0);
  a.dispose();
  b.dispose();
  const once = new Emitter({ ...c, loop: false }, new T.Scene());
  once.start(o);
  once.step(0.8, o);
  assert.equal(once.count, 2);
  once.dispose();
});
test('sprite frame, local coordinates and lifetime curves independently affect each particle', () => {
  const o = new T.Group(),
    s = new Emitter(
      {
        ...structuredClone(vfx),
        space: 'local',
        shape: 'box',
        boxX: 0.5,
        boxY: 0.5,
        boxZ: 0.5,
        capacity: 4,
        speedMin: 0,
        speedMax: 0,
        gravity: 0,
        rate: 0,
        lifeMin: 2,
        lifeMax: 2,
        columns: 2,
        rows: 2,
        flipbookFPS: 4,
        rotationMin: 30,
        rotationMax: 30,
        curves: {
          size: [
            [0, 0],
            [0.5, 2],
            [1, 0],
          ],
          opacity: [
            [0, 0],
            [0.5, 1],
            [1, 0],
          ],
          speed: [
            [0, 1],
            [1, 1],
          ],
        },
      },
      new T.Scene(),
    );
  o.position.x = 10;
  s.emit(1, o);
  const pos = s.p[0];
  o.position.x = 20;
  o.updateMatrixWorld();
  s.step(0.25, o);
  s.draw(new T.PerspectiveCamera());
  near(s.mesh.instanceMatrix.array[12], 20 + pos);
  near(s.frames.getX(0), 0.5);
  near(s.frames.getY(0), 0.5);
  near(s.alpha.getX(0), s.c.opacity * 0.25);
  assert(s.rotation[0] > 0);
  near(
    curve(
      [
        [0, 0],
        [0.5, 2],
        [1, 0],
      ],
      0.75,
    ),
    1,
  );
  assert.throws(() =>
    checkCurve([
      [0, 1],
      [0, 1],
      [1, 1],
    ]),
  );
  s.dispose();
});
test('old scenes migrate and direct sounds survive duplication, serialization and prefab asset remapping', () => {
  const d = createDocument(),
    a = {
      id: 'wav',
      type: 'audio',
      name: 'tone.wav',
      mime: 'audio/wav',
      data: 'AAAA',
    },
    e = createEntity('box');
  d.entities.push(e);
  d.assets.push(a);
  d.sounds.push(soundTrack(a));
  e.sounds = [soundTrack(a, true)];
  assert.deepEqual(validateDocument(d), d);
  duplicateEntities(d, e.id);
  assert.notEqual(d.entities[1].sounds[0].id, e.sounds[0].id);
  const prefab = createPrefab(d, e.id);
  assert.equal(prefab.scene.sounds.length, 0);
  assert.equal(prefab.scene.assets.length, 1);
  const target = createDocument();
  instantiatePrefab(target, prefab);
  assert.doesNotThrow(() => validateDocument(target));
  assert.equal(target.entities[0].sounds[0].asset, target.assets[0].id);
  const old = structuredClone(d);
  old.version = 8;
  delete old.sounds;
  assert.deepEqual(validateDocument(old).sounds, []);
});
test('shared clips decode once and an asynchronous resume cannot restart stopped audio', async () => {
  const pending = [],
    param = () => ({
      value: 0,
      setTargetAtTime(v) {
        this.value = v;
      },
      setValueAtTime(v) {
        this.value = v;
      },
      linearRampToValueAtTime() {},
    }),
    node = () => ({
      connect() {},
      disconnect() {},
      gain: param(),
      playbackRate: param(),
      detune: param(),
      start() {},
      stop() {},
    });
  let decodes = 0;
  T.AudioContext.setContext({
    currentTime: 0,
    destination: {},
    createGain: node,
    createBufferSource: node,
    createPanner: node,
    decodeAudioData: async () => {
      decodes++;
      return { duration: 1 };
    },
    resume: () => new Promise((r) => pending.push(r)),
    suspend: async () => {},
  });
  const d = createDocument(),
    e = createEntity('group'),
    h = createEntity('group'),
    a = {
      id: 'a',
      name: 'A.wav',
      mime: 'audio/wav',
      type: 'audio',
      data: 'AAAA',
    },
    o = new T.Group(),
    invisible = new T.Group(),
    child = new T.Group();
  invisible.visible = false;
  invisible.add(child);
  d.entities.push(e, h);
  d.assets.push(a);
  d.sounds.push(soundTrack(a));
  e.sounds = [soundTrack(a, true)];
  h.sounds = [soundTrack(a, true)];
  const sound = new AudioRuntime(new T.PerspectiveCamera());
  await sound.load(
    d,
    new Map([
      [e.id, o],
      [h.id, child],
    ]),
  );
  assert.equal(decodes, 1);
  const first = sound.start();
  sound.stop();
  const second = sound.start();
  pending.shift()();
  await first;
  assert([...sound.sounds.values()].every((s) => !s.isPlaying));
  pending.shift()();
  await second;
  assert.equal([...sound.sounds.values()].filter((s) => s.isPlaying).length, 2);
  sound.dispose();
});
test('invalid cloth and particle controls cannot silently enter an exported project', () => {
  const d = createDocument(),
    e = createEntity('box');
  d.entities.push(e);
  e.behaviors.garment = { ...garment, subdivisions: 99, regions: [] };
  assert.throws(() => validateDocument(d), /refinement/);
  delete e.behaviors.garment;
  e.behaviors.emitter = structuredClone(vfx);
  e.behaviors.emitter.texture = 'missing';
  assert.throws(() => validateDocument(d), /sprite/);
  e.behaviors.emitter.texture = null;
  e.behaviors.emitter.curves.opacity = [
    [0, 0],
    [1, 2],
  ];
  assert.throws(() => validateDocument(d), /range/);
});
test('Play uses the visible player, respects hidden parents and keeps camera-only Studio views unchanged', () => {
  const a = createEntity('player'),
    c = createEntity('camera'),
    g = new T.Group(),
    o = new T.Group();
  g.add(o);
  const world = {
      doc: { entities: [a, c] },
      objects: new Map([
        [a.id, o],
        [c.id, new T.Group()],
      ]),
    },
    can = WorldRenderer.prototype.canPlayView.bind(world);
  assert(can(true));
  g.visible = false;
  assert(!can(true));
  assert(can(false));
});
test('static cloth reuses the posed base until the host actually moves', () => {
  const { g, m, mask } = fixture();
  let reads = 0;
  const old = m.getVertexPosition.bind(m);
  m.getVertexPosition = (...a) => {
    reads++;
    return old(...a);
  };
  const s = new Cloth(m, mask, garment),
    initial = reads;
  for (let i = 0; i < 20; i++) s.step(1 / 60, false);
  assert.equal(reads, initial);
  m.position.x++;
  s.step(1 / 60, false);
  assert.equal(reads, initial + g.attributes.position.count);
  s.dispose();
});
